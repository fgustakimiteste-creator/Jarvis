from __future__ import annotations

import argparse
import ipaddress
import secrets
import socket
from pathlib import Path


def _parse_env(lines: list[str]) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def prepare_env(env_path: Path) -> tuple[str, int, str]:
    """Configure a LAN-only host and make sure API access has a strong token.

    Existing Gemini keys, database settings and user preferences are preserved.
    A non-empty token already present in the .env file is never replaced.
    """
    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8").splitlines()
    else:
        lines = []

    values = _parse_env(lines)
    host = "0.0.0.0"
    try:
        port = int(values.get("JARVIS_PORT", "8787"))
    except ValueError:
        port = 8787
    if not 1 <= port <= 65535:
        port = 8787

    token = values.get("JARVIS_TOKEN", "").strip()
    if not token:
        token = secrets.token_urlsafe(36)

    replacements = {
        "JARVIS_HOST": host,
        "JARVIS_PORT": str(port),
        "JARVIS_TOKEN": token,
    }
    seen: set[str] = set()
    output: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            output.append(line)
            continue
        key, _ = stripped.split("=", 1)
        key = key.strip()
        if key not in replacements:
            output.append(line)
            continue
        if key in seen:
            continue
        output.append(f"{key}={replacements[key]}")
        seen.add(key)

    for key, value in replacements.items():
        if key not in seen:
            output.append(f"{key}={value}")

    env_path.parent.mkdir(parents=True, exist_ok=True)
    env_path.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    return host, port, token


def detect_lan_ip() -> str:
    """Return the preferred private IPv4 address without sending app data."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # UDP connect selects the outbound interface; it does not establish a TCP session.
        sock.connect(("192.0.2.1", 80))
        candidate = sock.getsockname()[0]
        address = ipaddress.ip_address(candidate)
        if address.version == 4 and address.is_private and not address.is_loopback:
            return candidate
    except OSError:
        pass
    finally:
        sock.close()

    try:
        candidates = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET, socket.SOCK_DGRAM)
    except OSError:
        candidates = []
    for item in candidates:
        candidate = item[4][0]
        try:
            address = ipaddress.ip_address(candidate)
        except ValueError:
            continue
        if address.is_private and not address.is_loopback and not address.is_link_local:
            return candidate
    return "IP_NAO_DETECTADO"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=Path, default=Path(__file__).resolve().parents[1] / ".env")
    parser.add_argument("--machine", action="store_true", help="Print key=value lines for the Windows launcher")
    args = parser.parse_args()

    _, port, token = prepare_env(args.env)
    lan_ip = detect_lan_ip()
    if args.machine:
        print(f"LAN_IP={lan_ip}")
        print(f"LAN_PORT={port}")
        print(f"JARVIS_TOKEN={token}")
    else:
        print("JARVIS configurado para acesso na rede local.")
        print(f"PC:      http://127.0.0.1:{port}")
        if lan_ip != "IP_NAO_DETECTADO":
            print(f"Android: http://{lan_ip}:{port}")
        else:
            print("Android: não consegui detectar o IP. Consulte ipconfig no Windows.")
        print(f"Token:   {token}")
        print("O token também foi salvo no arquivo .env.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
