# Status da licença

O arquivo de origem JARVIS v4.2 fornecido para esta alteração não continha um arquivo `LICENSE` nem uma declaração explícita de licença. Por isso, esta entrega não inventa uma licença (MIT, Apache, GPL ou outra). Antes de autorizar terceiros a copiar, modificar ou redistribuir o código, o titular dos direitos deve confirmar a autoria e escolher uma licença apropriada.

O projeto separado `G0DM0D3-main.zip` foi fornecido com GNU Affero General Public License v3.0 (AGPL-3.0). Nenhum arquivo-fonte desse projeto foi incorporado a este repositório; apenas ideias gerais de automação/multimodelo e uma nota explicativa foram consideradas. Qualquer integração futura do código AGPL precisa seguir suas obrigações.
