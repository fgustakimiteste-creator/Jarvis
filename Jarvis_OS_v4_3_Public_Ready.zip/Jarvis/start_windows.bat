@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  where py >nul 2>nul
  if not errorlevel 1 (
    for %%V in (3.14 3.13 3.12 3.11 3.10) do (
      if not exist .venv py -%%V -m venv .venv 2>nul
    )
  ) else (
    python -c "import sys; assert sys.version_info >= (3,10), 'Use Python 3.10 ou superior'" >nul 2>nul
    if errorlevel 1 (
      echo Instale Python 3.10 ou superior.
      pause
      exit /b 1
    )
    python -m venv .venv
  )
  if errorlevel 1 (
    echo Nao foi possivel criar o ambiente Python recomendado.
    echo Instale Python 3.10 ou superior e tente novamente.
    pause
    exit /b 1
  )
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
python -m app.main
pause
