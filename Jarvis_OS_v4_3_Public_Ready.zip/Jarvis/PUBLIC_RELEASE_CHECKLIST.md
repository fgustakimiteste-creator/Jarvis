# Checklist antes de abrir o JARVIS OS ao público

- [x] Segregar histórico, memória e workspace por sessão de navegador.
- [x] Cookie de sessão aleatório, HttpOnly, SameSite=Lax e Secure atrás de HTTPS.
- [x] Bloquear ações de rede/desktop sobre o servidor em modo público.
- [x] Nunca expor segredos no endpoint de configuração pública.
- [x] Limite de requisições geral e limite reforçado para operações caras.
- [x] Cabeçalhos de segurança e CSP inicial.
- [x] `robots.txt`, `sitemap.xml`, canonical, meta description e Open Graph.
- [x] Banner de consentimento; Google Analytics e Meta Pixel só iniciam após aceite.
- [x] Alt em imagens estáticas e geradas; foco visível; skip link; prefers-reduced-motion.
- [x] Rascunhos de privacidade, termos, cookies, reembolso e formulário de direitos.
- [ ] Preencher identificação e canal de contato reais do controlador.
- [ ] Revisão jurídica e auditoria LGPD (bases legais, retenção, operadores e incidentes).
- [ ] Auditoria de contraste e leitor de tela em todas as telas.
- [ ] Configurar banco/armazenamento persistente, backups testados e monitoramento.
- [ ] Criar e verificar repositório GitHub `Jarvis`; conectar Render.
- [ ] Configurar chaves dos provedores em variáveis privadas do host.
- [ ] Validar Search Console e IDs reais de Analytics/Meta, se aplicável.
- [ ] Revisar licenciamento/autoria dos fontes antes da distribuição pública.

Este checklist diferencia ajustes feitos no código dos passos de operação, jurídicos e de conta que exigem dados ou credenciais do responsável.
