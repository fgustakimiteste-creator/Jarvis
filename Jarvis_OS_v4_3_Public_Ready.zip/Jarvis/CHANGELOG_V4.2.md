# JARVIS OS 4.2 — alterações

- Mantidos os módulos e recursos da versão 4.1; acrescentados módulos independentes.
- Adicionado OpenAI Responses API ao lado do Gemini e de modelos locais compatíveis.
- Adicionado AutoTune leve, seleção de provedor e ULTRAPLINIAN opcional (até 3 provedores; 2 em paralelo).
- Adicionada pesquisa aprofundada multifonte (3 buscas, até 12 resultados, tentativa de leitura de até 6 páginas).
- Adicionada automação visual via computer use, com confirmação, captura/recaptura, logs, botão de parada, 32 ações e 5 minutos.
- Adicionados geração de imagem, transcrição de áudio, fala MP3 e montagem de vídeo a partir de imagens/áudio.
- Adicionada geração por IA de projetos web, Python, Pygame, Godot e Android/Kotlin.
- Adicionada geração por IA de documentos DOCX e apresentações PPTX.
- Reforçada validação de caminhos/arquivos e proteção contra sobrescrita; corrigida a criação de subpastas em templates de projeto. Downloads do workspace agora também exigem token quando a API está protegida.
- Melhorada seleção de voz pt-BR do navegador e corrigido estado da tarefa visual quando a criação do cliente OpenAI falha; corrigida a gravação de áudio para usar streaming e menor uso de RAM.
- Testes: 43 passaram no ambiente de desenvolvimento; JavaScript passou em `node --check`.

## Limitações verificadas nesta entrega

- Não foi possível testar chamadas OpenAI reais porque o SDK não estava instalado no ambiente de desenvolvimento; a dependência está listada em `requirements.txt`.
- O ambiente não possui sessão gráfica (`DISPLAY`), então PyAutoGUI não pode controlar uma área de trabalho real aqui.
- Gradle e Android SDK não estavam configurados; nenhum APK foi compilado neste ambiente.
- O vídeo é uma montagem FFmpeg de imagens e áudio, não vídeo generativo por prompt.
- O mini JARVIS é um widget arrastável dentro do navegador, não uma janela always-on-top do sistema operacional.

## Correção do inicializador Termux
- Removida a tentativa de instalar `iputils`, pacote não disponível com esse nome nos repositórios padrão do Termux.
- Mantido `iproute2` para fornecer o comando `ip` usado na identificação da rede local.
- FFmpeg passou a ser uma dependência opcional para que sua falha não impeça a inicialização do núcleo do JARVIS.
- Adicionadas mensagens de erro específicas para falhas de atualização ou instalação de Python/iproute2.
