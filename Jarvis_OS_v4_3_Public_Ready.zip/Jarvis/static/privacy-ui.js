(() => {
  const CONSENT_KEY = 'jarvisAnalyticsConsentV1';
  const loadScript = (src, id) => {
    if (document.getElementById(id)) return;
    const script = document.createElement('script');
    script.async = true;
    script.src = src;
    script.id = id;
    document.head.appendChild(script);
  };
  const enableAnalytics = async () => {
    try {
      const response = await fetch('/api/public-config', { credentials: 'same-origin' });
      if (!response.ok) return;
      const config = await response.json();
      if (config.ga_measurement_id) {
        window.dataLayer = window.dataLayer || [];
        window.gtag = function () { window.dataLayer.push(arguments); };
        window.gtag('js', new Date());
        window.gtag('config', config.ga_measurement_id, { anonymize_ip: true });
        loadScript(`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(config.ga_measurement_id)}`, 'jarvis-ga');
      }
      if (config.meta_pixel_id) {
        // Meta Pixel is initialized only after an explicit analytics opt-in.
        !(function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)})(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
        window.fbq('init', config.meta_pixel_id);
        window.fbq('track', 'PageView');
      }
    } catch (error) {
      console.warn('Analytics could not be initialized:', error?.name || 'error');
    }
  };
  const disableAnalytics = () => {
    if (typeof window.gtag === 'function') {
      window.gtag('consent', 'update', {
        analytics_storage: 'denied', ad_storage: 'denied',
        ad_user_data: 'denied', ad_personalization: 'denied'
      });
    }
    if (typeof window.fbq === 'function') window.fbq('consent', 'revoke');
    // Remove common first-party measurement cookies after consent withdrawal.
    document.cookie.split(';').forEach(cookie => {
      const name = cookie.split('=', 1)[0].trim();
      if (/^(?:_ga(?:_|$)|_gid$|_gat(?:_|$)|_fbp$|_fbc$)/.test(name)) {
        document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
      }
    });
  };

  const saved = localStorage.getItem(CONSENT_KEY);
  if (saved === 'accepted') enableAnalytics();

  const showBanner = () => {
    document.querySelector('.cookie-consent')?.remove();
    const banner = document.createElement('section');
    banner.className = 'cookie-consent';
    banner.setAttribute('role', 'region');
    banner.setAttribute('aria-label', 'Preferências de cookies');
    banner.setAttribute('aria-labelledby', 'cookie-title');
    banner.innerHTML = `
    <div class="cookie-copy">
      <strong id="cookie-title">Privacidade e cookies</strong>
      <p>Usamos um cookie essencial para separar sua sessão. Analytics e publicidade ficam desligados até você permitir. <a href="/legal#cookies">Leia o aviso de cookies</a>.</p>
    </div>
    <div class="cookie-actions">
      <button type="button" data-consent="accepted">Aceitar opcionais</button>
      <button type="button" class="secondary" data-consent="rejected">Recusar opcionais</button>
    </div>`;
    document.body.appendChild(banner);
    banner.addEventListener('click', async event => {
    const choice = event.target.closest('[data-consent]')?.dataset.consent;
      if (!choice) return;
      localStorage.setItem(CONSENT_KEY, choice);
      banner.remove();
      if (choice === 'accepted') await enableAnalytics();
      else disableAnalytics();
    });
  };
  window.jarvisCookiePreferences = () => {
    localStorage.removeItem(CONSENT_KEY);
    showBanner();
  };
  document.getElementById('legal-cookie-config')?.addEventListener('click', window.jarvisCookiePreferences);
  if (saved !== 'accepted' && saved !== 'rejected') showBanner();
})();
