(() => {
  const set = (key, value) => {
    document.querySelectorAll(`[data-legal="${key}"]`).forEach(node => {
      node.textContent = value || 'Não informado';
    });
  };
  fetch('/api/public-config', { credentials: 'same-origin' })
    .then(response => response.ok ? response.json() : Promise.reject(new Error('config unavailable')))
    .then(config => {
      ['legal_name', 'legal_cnpj', 'legal_address', 'privacy_contact_email', 'dpo_contact'].forEach(key => set(key, config[key]));
      const readiness = document.getElementById('legal-readiness');
      const missing = ['legal_name', 'legal_address', 'privacy_contact_email'].filter(key => !config[key]);
      readiness.textContent = missing.length
        ? `Configuração institucional pendente: ${missing.join(', ')}. O responsável precisa preencher esses dados antes de oferecer o serviço comercialmente.`
        : 'Os dados institucionais foram configurados. O texto ainda deve ser revisado pelo responsável jurídico e de privacidade.';
      const form = document.getElementById('lgpd-form');
      form.addEventListener('submit', event => {
        event.preventDefault();
        const feedback = document.getElementById('lgpd-feedback');
        if (!config.privacy_contact_email) {
          feedback.textContent = 'O canal de privacidade ainda não foi configurado. Não foi enviado nenhum dado.';
          return;
        }
        const request = document.getElementById('lgpd-request').value;
        const email = document.getElementById('lgpd-email').value.trim();
        const detail = document.getElementById('lgpd-detail').value.trim();
        const subject = encodeURIComponent(`Solicitação LGPD: ${request}`);
        const body = encodeURIComponent(`Tipo: ${request}\nE-mail para resposta: ${email}\n\nDetalhes: ${detail}\n\nEnviado pelo formulário local do JARVIS OS.`);
        window.location.href = `mailto:${encodeURIComponent(config.privacy_contact_email)}?subject=${subject}&body=${body}`;
        feedback.textContent = 'Seu aplicativo de e-mail foi solicitado. Confira, complete se necessário e envie a mensagem por lá.';
      }, { once: true });
    })
    .catch(() => {
      document.getElementById('legal-readiness').textContent = 'Não foi possível carregar os dados institucionais. Nenhum contato foi presumido.';
    });
})();
