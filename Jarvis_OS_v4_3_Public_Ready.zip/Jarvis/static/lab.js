(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const token = () => sessionStorage.getItem('jarvisToken') || '';
  let polling = null;
  let workspaceItems = [];

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (token()) headers.set('X-Jarvis-Token', token());
    if (options.body && !(options.body instanceof FormData) && !(options.body instanceof Blob)) headers.set('Content-Type', 'application/json');
    const response = await fetch(path, { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || `Erro HTTP ${response.status}`);
    return data;
  }

  function toast(message) {
    const el = $('toast'); if (!el) return;
    el.textContent = message; el.classList.add('show');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 3300);
  }

  function setResult(id, text, isError = false) {
    const el = $(id); if (!el) return;
    el.textContent = text;
    el.style.color = isError ? '#ffaaaa' : '';
  }

  function protectedFileLink(url, filename, label = 'Abrir arquivo ↗') {
    const link = document.createElement('a');
    link.href = url; link.textContent = label; link.rel = 'noopener';
    link.addEventListener('click', async event => {
      event.preventDefault();
      const popup = window.open('about:blank', '_blank');
      if (popup) popup.opener = null;
      try {
        const headers = new Headers();
        if (token()) headers.set('X-Jarvis-Token', token());
        const response = await fetch(url, { headers });
        if (!response.ok) throw new Error(response.status === 401 ? 'Token inválido ou expirado.' : `Erro HTTP ${response.status}`);
        const blobUrl = URL.createObjectURL(await response.blob());
        if (popup) popup.location.href = blobUrl;
        else {
          const download = document.createElement('a'); download.href = blobUrl; download.download = filename; download.click();
        }
        setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
      } catch (error) {
        if (popup) popup.close();
        toast(`Não foi possível abrir o arquivo: ${error.message}`);
      }
    });
    return link;
  }

  function resultLink(id, item, prefix = 'Criado') {
    const el = $(id); if (!el) return;
    el.replaceChildren();
    const text = document.createElement('span'); text.textContent = `${prefix}: ${item.name} · ${(item.size || 0).toLocaleString('pt-BR')} bytes `;
    const link = protectedFileLink(item.url, item.name);
    el.append(text, link);
  }

  async function refreshDesktopStatus() {
    try {
      const data = await api('/api/desktop/status');
      const enabled = data.available;
      $('desktopState').textContent = enabled ? 'PC PRONTO' : (data.enabled ? 'DEPENDÊNCIA / TELA INDISPONÍVEL' : 'DESATIVADO NO SERVIDOR');
      $('desktopPill').innerHTML = `<i></i> ${enabled ? 'Disponível' : 'Indisponível'}`;
      $('desktopPill').style.color = enabled ? 'var(--mint)' : 'var(--amber)';
      if (!enabled) setResult('desktopAnalysis', `${data.note || ''}\n${data.detail || ''}\nAtive JARVIS_DESKTOP_CONTROL=true no .env do PC e instale PyAutoGUI, Pillow e pyperclip.`.trim());
      return data;
    } catch (error) {
      $('desktopState').textContent = 'SEM CONEXÃO';
      setResult('desktopAnalysis', error.message, true);
      return null;
    }
  }

  async function refreshScreen() {
    try {
      const data = await api('/api/desktop/screenshot');
      $('desktopPreview').src = data.image;
      $('desktopPreview').hidden = false;
      $('desktopPlaceholder').hidden = true;
      return true;
    } catch (error) {
      if (!error.message.includes('desativado') && !error.message.includes('Ative')) setResult('desktopAnalysis', error.message, true);
      return false;
    }
  }

  async function analyzeScreen() {
    setResult('desktopAnalysis', 'Analisando a captura da tela...');
    try {
      const data = await api('/api/desktop/analyze', { method: 'POST', body: '{}' });
      await refreshScreen();
      setResult('desktopAnalysis', data.analysis);
    } catch (error) { setResult('desktopAnalysis', error.message, true); }
  }

  async function pollTaskStatus() {
    try {
      const data = await api('/api/desktop/task-status');
      const lines = (data.logs || []).join('\n');
      const status = data.running ? 'Automação em andamento' : (data.last_error ? `Falha: ${data.last_error}` : 'Automação parada');
      setResult('desktopAnalysis', `${status}\nAções: ${data.actions || 0}\n\n${lines || 'Aguardando ações...'}`, !!data.last_error);
      if (data.running) await refreshScreen();
      else if (polling) { clearInterval(polling); polling = null; await refreshScreen(); }
    } catch (error) { setResult('desktopAnalysis', error.message, true); }
  }

  async function runDesktopTask(event) {
    event.preventDefault();
    const task = $('desktopTask').value.trim();
    if (!task) return toast('Descreva a tarefa primeiro.');
    if (!$('desktopConfirm').checked) return toast('Marque a confirmação para autorizar o controle da tela.');
    $('runDesktopBtn').disabled = true;
    $('runDesktopBtn').textContent = 'Executando...';
    setResult('desktopAnalysis', 'Preparando a captura e iniciando o agente visual...');
    if (polling) clearInterval(polling);
    polling = setInterval(pollTaskStatus, 1800);
    try {
      const data = await api('/api/desktop/automate', { method: 'POST', body: JSON.stringify({ task, confirm: true }) });
      setResult('desktopAnalysis', `${data.reply}\nAções executadas: ${data.actions}\n\n${(data.log || []).join('\n')}`);
      await refreshScreen();
      toast(data.stopped ? 'Automação interrompida.' : 'Automação concluída. Confira a tela.');
    } catch (error) {
      setResult('desktopAnalysis', error.message, true);
      toast(error.message);
    } finally {
      if (polling) { clearInterval(polling); polling = null; }
      $('runDesktopBtn').disabled = false;
      $('runDesktopBtn').innerHTML = 'Executar tarefa visual <b>↗</b>';
      $('desktopConfirm').checked = false;
    }
  }

  async function stopDesktopTask() {
    try { await api('/api/desktop/stop', { method: 'POST', body: '{}' }); toast('Pedido de interrupção enviado.'); await pollTaskStatus(); }
    catch (error) { toast(error.message); }
  }

  async function refreshWorkspace() {
    try {
      const data = await api('/api/workspace');
      workspaceItems = data.items || [];
      const list = $('workspaceList'); list.replaceChildren();
      if (!workspaceItems.length) list.textContent = 'Nenhum arquivo criado ainda.';
      for (const item of workspaceItems) {
        const row = document.createElement('div'); row.className = 'workspace-item';
        const name = document.createElement('span'); name.textContent = `${item.type === 'folder' ? '▰' : '▤'} ${item.name}`;
        const size = document.createElement('small'); size.textContent = item.type === 'folder' ? 'Pasta' : `${((item.size || 0) / 1024).toFixed(1)} KB`;
        if (item.type === 'file') { const link = protectedFileLink(`/workspace/${encodeURIComponent(item.name)}`, item.name, 'Abrir'); row.append(name, size, link); }
        else row.append(name, size);
        list.append(row);
      }
      const images = workspaceItems.filter(x => x.type === 'file' && /\.(png|jpe?g|webp)$/i.test(x.name));
      const audios = workspaceItems.filter(x => x.type === 'file' && /\.(mp3|wav|aac|m4a|ogg)$/i.test(x.name));
      const imgSelect = $('videoImages'); const selected = new Set([...imgSelect.selectedOptions].map(o => o.value)); imgSelect.replaceChildren();
      images.forEach(item => { const opt = document.createElement('option'); opt.value = item.name; opt.textContent = item.name; opt.selected = selected.has(item.name); imgSelect.append(opt); });
      const audioSelect = $('videoAudio'); const audioValue = audioSelect.value; audioSelect.replaceChildren();
      const none = document.createElement('option'); none.value = ''; none.textContent = 'Sem áudio'; audioSelect.append(none);
      audios.forEach(item => { const opt = document.createElement('option'); opt.value = item.name; opt.textContent = item.name; audioSelect.append(opt); });
      if ([...audioSelect.options].some(o => o.value === audioValue)) audioSelect.value = audioValue;
    } catch (error) { setResult('projectResult', error.message, true); }
  }

  async function generateImage(event) {
    event.preventDefault();
    const prompt = $('imagePrompt').value.trim();
    if (!prompt) return;
    setResult('imageResult', 'Gerando imagem com a API OpenAI...');
    try {
      const data = await api('/api/media/image', { method: 'POST', body: JSON.stringify({ prompt, size: $('imageSize').value }) });
      const box = $('imageResult'); box.replaceChildren();
      const line = document.createElement('div'); line.textContent = `Imagem salva: ${data.name} · ${data.size.toLocaleString('pt-BR')} bytes`;
      const link = document.createElement('a'); link.href = data.url; link.target = '_blank'; link.rel = 'noopener'; link.textContent = 'Abrir imagem ↗';
      const image = document.createElement('img'); image.src = data.url; image.alt = 'Imagem gerada pelo JARVIS';
      box.append(line, document.createTextNode(' · '), link, image); await refreshWorkspace(); toast('Imagem criada.');
    } catch (error) { setResult('imageResult', error.message, true); }
  }

  async function generateSpeech(event) {
    event.preventDefault();
    const text = $('speechText').value.trim();
    if (!text) return;
    setResult('speechResult', 'Gerando áudio MP3...');
    try {
      const data = await api('/api/media/speech', { method: 'POST', body: JSON.stringify({ text, voice: $('speechVoice').value }) });
      const box = $('speechResult'); box.replaceChildren();
      const link = document.createElement('a'); link.href = data.url; link.download = data.name; link.textContent = `Baixar ${data.name}`;
      const audio = document.createElement('audio'); audio.controls = true; audio.src = data.url;
      const notice = document.createElement('small'); notice.textContent = data.notice || 'Áudio gerado por IA.';
      box.append(link, audio, notice); await refreshWorkspace(); toast('Áudio criado.');
    } catch (error) { setResult('speechResult', error.message, true); }
  }

  async function transcribeAudio(event) {
    event.preventDefault();
    const file = $('audioFile').files?.[0];
    if (!file) return toast('Selecione um arquivo de áudio.');
    if (file.size > 25 * 1024 * 1024) return toast('O arquivo excede 25 MB.');
    const body = new FormData(); body.append('file', file);
    setResult('transcriptResult', 'Transcrevendo áudio...');
    try {
      const data = await api('/api/media/transcribe', { method: 'POST', body });
      setResult('transcriptResult', data.text || 'Nenhuma fala identificada.');
    } catch (error) { setResult('transcriptResult', error.message, true); }
  }

  async function createDocument(event) {
    event.preventDefault();
    try {
      const data = await api('/api/workspace/document', { method: 'POST', body: JSON.stringify({ filename: $('documentFilename').value, title: $('documentTitle').value, text: $('documentText').value }) });
      resultLink('documentResult', data, 'Documento criado'); await refreshWorkspace(); toast('Documento Word criado.');
    } catch (error) { setResult('documentResult', error.message, true); }
  }

  async function createPresentation(event) {
    event.preventDefault();
    const blocks = $('presentationContent').value.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
    const slides = blocks.map(block => { const lines = block.split('\n').map(x => x.trim()).filter(Boolean); return { title: (lines.shift() || 'Slide').replace(/^#+\s*/, ''), bullets: lines.map(x => x.replace(/^[-•]\s*/, '')) }; });
    if (!slides.length) return toast('Adicione pelo menos um bloco de slide.');
    try {
      const data = await api('/api/workspace/presentation', { method: 'POST', body: JSON.stringify({ filename: $('presentationFilename').value, title: $('presentationTitle').value, slides }) });
      resultLink('presentationResult', data, 'Apresentação criada'); await refreshWorkspace(); toast('PowerPoint criado.');
    } catch (error) { setResult('presentationResult', error.message, true); }
  }


  async function generateDocumentWithAI() {
    const prompt = $('documentPrompt').value.trim();
    const title = $('documentTitle').value.trim() || 'Documento JARVIS';
    if (prompt.length < 10) return toast('Descreva o documento em pelo menos 10 caracteres.');
    setResult('documentResult', 'Redigindo o conteúdo e montando o DOCX...');
    try {
      const data = await api('/api/workspace/document/generate', { method: 'POST', body: JSON.stringify({ filename: $('documentFilename').value, title, prompt, provider: $('providerSelect')?.value || 'auto' }) });
      resultLink('documentResult', data, `Documento criado com ${data.provider || 'IA'}`); await refreshWorkspace(); toast('Documento gerado.');
    } catch (error) { setResult('documentResult', error.message, true); }
  }

  async function generatePresentationWithAI() {
    const prompt = $('presentationPrompt').value.trim();
    const title = $('presentationTitle').value.trim() || 'Apresentação JARVIS';
    if (prompt.length < 10) return toast('Descreva a apresentação em pelo menos 10 caracteres.');
    setResult('presentationResult', 'Organizando a narrativa e gerando os slides...');
    try {
      const data = await api('/api/workspace/presentation/generate', { method: 'POST', body: JSON.stringify({ filename: $('presentationFilename').value, title, prompt, provider: $('providerSelect')?.value || 'auto' }) });
      resultLink('presentationResult', data, `Apresentação criada (${data.slides} slides) com ${data.provider || 'IA'}`); await refreshWorkspace(); toast('Apresentação criada.');
    } catch (error) { setResult('presentationResult', error.message, true); }
  }

  async function createProject(event) {
    event.preventDefault();
    try {
      const data = await api('/api/workspace/project', { method: 'POST', body: JSON.stringify({ name: $('projectName').value, project_type: $('projectType').value }) });
      setResult('projectResult', `Projeto ${data.project} criado. Arquivos: ${(data.files || []).join(', ')}. ${data.build_ready === false && $('projectType').value === 'android' ? 'Instale Gradle e Android SDK no PC para compilar o APK.' : ''}`);
      $('checkProjectName').value = data.project; await refreshWorkspace(); toast('Estrutura de projeto criada.');
    } catch (error) { setResult('projectResult', error.message, true); }
  }


  async function generateProjectWithAI() {
    const name = $('projectName').value.trim();
    const prompt = $('projectPrompt').value.trim();
    const type = $('projectType').value;
    if (!name || !prompt) return toast('Informe o nome e descreva o projeto com detalhes.');
    const button = $('generateProjectBtn');
    button.disabled = true; button.textContent = 'Planejando e escrevendo arquivos...';
    setResult('projectResult', 'A IA está planejando a estrutura e escrevendo os arquivos. O código não será executado automaticamente.');
    try {
      const data = await api('/api/workspace/project/generate', { method: 'POST', body: JSON.stringify({ name, project_type: type, prompt, provider: $('providerSelect')?.value || 'auto' }) });
      $('checkProjectName').value = data.project;
      const check = data.check || {};
      setResult('projectResult', `Projeto ${data.project} criado com ${data.provider?.toUpperCase() || 'IA'}.\n${data.summary || ''}\nArquivos: ${(data.files || []).join(', ')}\nVerificação: ${check.ok ? 'aprovada' : 'revisar'} · ${check.message || ''}\n${check.stderr || ''}\n${data.notice || ''}`.trim(), !check.ok);
      await refreshWorkspace(); toast('Projeto criado e verificado.');
    } catch (error) { setResult('projectResult', error.message, true); toast(error.message); }
    finally { button.disabled = false; button.textContent = 'Criar projeto completo com IA ↗'; }
  }

  async function checkProject() {
    const name = $('checkProjectName').value.trim(); if (!name) return toast('Digite o nome do projeto.');
    try { const data = await api('/api/workspace/project/check', { method: 'POST', body: JSON.stringify({ name }) }); setResult('projectResult', `${data.ok ? 'Verificação concluída.' : 'A verificação encontrou problemas.'}\n${data.message || ''}\n${data.stdout || ''}\n${data.stderr || ''}`.trim(), !data.ok); }
    catch (error) { setResult('projectResult', error.message, true); }
  }

  async function buildAndroid() {
    const name = $('checkProjectName').value.trim(); if (!name) return toast('Digite o nome do projeto Android.');
    if (!window.confirm('Compilar executa o Gradle e os scripts de build do projeto no PC. Faça isso apenas em um projeto que você revisou. Continuar?')) return;
    setResult('projectResult', 'Compilando APK de debug...');
    try { const data = await api('/api/workspace/project/build-android', { method: 'POST', body: JSON.stringify({ name, confirm: true }) }); resultLink('projectResult', data, 'APK gerado'); await refreshWorkspace(); toast('APK compilado.'); }
    catch (error) { setResult('projectResult', error.message, true); }
  }

  async function createVideo(event) {
    event.preventDefault();
    const images = [...$('videoImages').selectedOptions].map(o => o.value);
    if (images.length < 2) return toast('Selecione pelo menos duas imagens.');
    setResult('videoResult', 'Montando vídeo MP4 com FFmpeg...');
    try {
      const data = await api('/api/media/video', { method: 'POST', body: JSON.stringify({ images, seconds_per_image: Number($('secondsPerImage').value), audio: $('videoAudio').value || null }) });
      const box = $('videoResult'); box.replaceChildren();
      const link = document.createElement('a'); link.href = data.url; link.download = data.name; link.textContent = `Baixar ${data.name}`;
      const video = document.createElement('video'); video.src = data.url; video.controls = true; video.playsInline = true; video.style.width = '100%'; video.style.marginTop = '10px';
      box.append(link, video); await refreshWorkspace(); toast('Vídeo montado.');
    } catch (error) { setResult('videoResult', error.message, true); }
  }

  async function compareProviders() {
    const message = $('messageInput').value.trim();
    if (!message) return toast('Digite a pergunta no chat antes de comparar.');
    const box = $('compareResults'); box.textContent = 'Consultando os provedores em paralelo (máximo de 2 ao mesmo tempo)...';
    try {
      const data = await api('/api/chat/compare', { method: 'POST', body: JSON.stringify({ message }) });
      box.replaceChildren();
      const winner = document.createElement('div'); winner.className = 'compare-winner'; winner.textContent = `Melhor pontuação heurística: ${String(data.winner).toUpperCase()}`;
      box.append(winner);
      (data.results || []).forEach(item => {
        const card = document.createElement('article'); card.className = 'compare-result-card';
        const head = document.createElement('b'); head.textContent = `${item.provider.toUpperCase()} · ${item.ok ? item.score : 'falhou'}`;
        const body = document.createElement('p'); body.textContent = item.ok ? item.answer : `Erro: ${item.error}`;
        card.append(head, body); box.append(card);
      });
      const note = document.createElement('small'); note.textContent = data.scoring_note || 'A classificação é heurística, não uma verificação factual.'; box.append(note);
      toast('Comparação finalizada.');
    } catch (error) { box.textContent = error.message; }
  }

  // The floating JARVIS orb is a draggable web widget; it does not create a Windows always-on-top process.
  function setupFloatingOrb() {
    const orb = $('miniJarvis'); if (!orb) return;
    try { const pos = JSON.parse(localStorage.getItem('jarvisMiniPos') || 'null'); if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.y)) { orb.style.left = `${pos.x}px`; orb.style.top = `${pos.y}px`; orb.style.right = 'auto'; orb.style.bottom = 'auto'; } } catch {}
    let start = null; let moved = false;
    orb.addEventListener('pointerdown', event => { start = { x: event.clientX, y: event.clientY, left: orb.getBoundingClientRect().left, top: orb.getBoundingClientRect().top }; moved = false; orb.classList.add('dragging'); orb.setPointerCapture(event.pointerId); });
    orb.addEventListener('pointermove', event => {
      if (!start) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      if (Math.abs(dx) + Math.abs(dy) > 7) moved = true;
      if (!moved) return;
      const x = Math.max(0, Math.min(window.innerWidth - orb.offsetWidth, start.left + dx));
      const y = Math.max(0, Math.min(window.innerHeight - orb.offsetHeight, start.top + dy));
      orb.style.left = `${x}px`; orb.style.top = `${y}px`; orb.style.right = 'auto'; orb.style.bottom = 'auto';
    });
    const release = () => {
      if (!start) return;
      orb.classList.remove('dragging');
      if (moved) { const rect = orb.getBoundingClientRect(); localStorage.setItem('jarvisMiniPos', JSON.stringify({ x: rect.left, y: rect.top })); }
      else { document.querySelector('[data-page="assistant"]')?.click(); setTimeout(() => $('messageInput')?.focus(), 80); }
      start = null;
    };
    orb.addEventListener('pointerup', release); orb.addEventListener('pointercancel', release);
  }

  $('refreshScreenBtn').addEventListener('click', refreshScreen);
  $('analyzeScreenBtn').addEventListener('click', analyzeScreen);
  $('desktopTaskForm').addEventListener('submit', runDesktopTask);
  $('stopDesktopBtn').addEventListener('click', stopDesktopTask);
  $('refreshWorkspaceBtn').addEventListener('click', refreshWorkspace);
  $('imageForm').addEventListener('submit', generateImage);
  $('speechForm').addEventListener('submit', generateSpeech);
  $('transcribeForm').addEventListener('submit', transcribeAudio);
  $('documentForm').addEventListener('submit', createDocument);
  $('generateDocumentBtn').addEventListener('click', generateDocumentWithAI);
  $('presentationForm').addEventListener('submit', createPresentation);
  $('generatePresentationBtn').addEventListener('click', generatePresentationWithAI);
  $('projectForm').addEventListener('submit', createProject);
  $('generateProjectBtn').addEventListener('click', generateProjectWithAI);
  $('checkProjectBtn').addEventListener('click', checkProject);
  $('buildAndroidBtn').addEventListener('click', buildAndroid);
  $('videoForm').addEventListener('submit', createVideo);
  $('compareButton').addEventListener('click', compareProviders);
  setupFloatingOrb();

  window.jarvisLabRefresh = async () => { await refreshDesktopStatus(); await refreshWorkspace(); await refreshScreen(); await pollTaskStatus(); };
  if ($('page-automation')) { refreshDesktopStatus(); refreshWorkspace(); }
})();
