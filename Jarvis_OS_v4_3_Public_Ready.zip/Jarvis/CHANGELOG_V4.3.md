# JARVIS OS v4.3 — mudanças desta entrega

## Segurança para acesso público

- Histórico, memória e arquivos passaram a ser separados por sessão de navegador.
- O cookie de sessão é aleatório, HttpOnly, SameSite=Lax e Secure quando HTTPS é detectado.
- Rotas que atuam no computador ou na rede local do servidor ficam bloqueadas no modo público compartilhado.
- Endpoints públicos não recebem nem retornam chaves de provedores; chaves devem existir somente como variáveis privadas do servidor.
- Foram adicionados limites de requisição, proteção básica contra CSRF por origem/Fetch Metadata e cabeçalhos de segurança.
- Sessões inativas são removidas segundo a retenção configurada (90 dias por padrão), com limpeza diária durante a execução.

## Interface, privacidade e descoberta

- Criadas políticas iniciais de privacidade, termos, cookies, reembolso e formulário de direitos da LGPD.
- Analytics e Meta Pixel são opcionais e só carregam após consentimento; há opção para retirar consentimento.
- Removidas fontes externas para evitar uma chamada desnecessária de terceiros na abertura do site.
- Melhorados contraste de texto, foco por teclado, skip link, landmarks, movimento reduzido e textos alternativos.
- Adicionados `robots.txt`, `sitemap.xml`, canonical, meta description, keywords e Open Graph; a verificação do Search Console depende de inserir o código real do domínio.

## Operação e implantação

- Adicionados `render.yaml`, Dockerfile, health check e guia de publicação.
- Separados os requisitos de teste (`requirements-dev.txt`) dos requisitos do runtime.
- Atualizados modelos padrão no arquivo de configuração. A disponibilidade depende da conta e do SDK.

## Limitações conhecidas

- O plano gratuito do Render é apenas demonstração: pode suspender por inatividade e perde arquivos locais em suspensão/reinicialização/redeploy.
- Não há banco/objeto persistente, backup, monitoramento externo, SLA ou escala horizontal nesta configuração.
- Dados institucionais, IDs de Analytics/Pixel e verificação do Google não foram inventados; precisam ser fornecidos pelo responsável.
- Textos legais são modelos técnicos, não certificação LGPD ou parecer jurídico. Acessibilidade precisa de auditoria manual final.
- O arquivo original JARVIS não declarava licença. A entrega não inventa licença. Nenhum fonte AGPL do G0DM0D3 foi incorporado.
