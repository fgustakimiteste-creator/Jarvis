# Publicar o JARVIS OS v4.3

## O que já está preparado

- Aplicação FastAPI e interface web responsiva.
- Modo público com sessão anônima isolada por visitante.
- Histórico, memórias e arquivos separados por sessão.
- Cookie HttpOnly; nenhuma chave de provedor é enviada ao navegador.
- Limites de uso e bloqueio de automações locais no servidor compartilhado.
- `render.yaml`, `/healthz`, `/robots.txt` e `/sitemap.xml`.
- Páginas legais iniciais, formulário LGPD, consentimento de analytics e ajustes de acessibilidade.

## Criar o repositório

1. Abra [GitHub — criar repositório](https://github.com/new).
2. Nome: `Jarvis`.
3. Visibilidade: `Public`.
4. Não marque criação automática de README, `.gitignore` ou licença (os arquivos já estão no pacote).
5. Crie o repositório e envie **o conteúdo desta pasta**, não a pasta ZIP, para a branch `main`.

A conexão GitHub disponível para esta sessão permite trabalhar em repositórios existentes, mas não oferece a ação de criar repositórios. Por isso, essa etapa precisa ser feita na página oficial acima. Não foi usado outro repositório com nome diferente como substituto.

## Conectar no Render

1. Entre no [Render](https://dashboard.render.com/).
2. Crie um Blueprint e selecione o repositório `fgustakimiteste-creator/Jarvis`.
3. Revise os serviços e confirme a criação. O arquivo `render.yaml` configura uma instância gratuita para demonstração.
4. Depois que o serviço for criado, abra **Environment** e configure `OPENAI_API_KEY` e/ou `GEMINI_API_KEY` como variáveis secretas. Não cole essas chaves no GitHub, no navegador ou no código.
5. Configure os dados verdadeiros do responsável: `JARVIS_LEGAL_NAME`, `JARVIS_LEGAL_ADDRESS`, `JARVIS_PRIVACY_EMAIL` e, quando aplicável, `JARVIS_CNPJ` e `JARVIS_DPO_CONTACT`.
6. Só depois de conhecer o endereço real do serviço, ajuste `JARVIS_PUBLIC_URL` para esse endereço e faça novo deploy.

## Limitações do plano gratuito

O plano gratuito do Render pode suspender o serviço após inatividade e o sistema de arquivos é efêmero. SQLite, memórias e arquivos podem desaparecer em suspensão, reinicialização ou novo deploy. Não use essa configuração como promessa de disponibilidade 24/7 nem para dados de produção. Para uso contínuo, planeje banco gerenciado, armazenamento de objetos, backups, monitoramento e um plano de hospedagem que não suspenda por inatividade.

## Google, SEO e Analytics

- Confirme o domínio/URL no Google Search Console e insira o código de verificação em `GOOGLE_SITE_VERIFICATION`.
- Envie `https://SEU-ENDERECO/sitemap.xml` no Search Console.
- `robots.txt`, canonical, meta description, keywords e Open Graph já estão no código.
- `GA_MEASUREMENT_ID` e `META_PIXEL_ID` são opcionais. Os scripts só são carregados após aceite expresso; recusar não bloqueia o chat.

## Situação jurídica e licença

Os textos legais são modelos técnicos iniciais, não uma certificação de conformidade nem parecer jurídico. Preencha os dados reais e revise as bases legais, operadores, transferências internacionais, prazos e medidas de segurança antes de abrir comercialmente. A origem JARVIS não incluía licença declarada; não foi inventada uma licença para este pacote. O código-fonte AGPL do G0DM0D3 não foi incorporado.
