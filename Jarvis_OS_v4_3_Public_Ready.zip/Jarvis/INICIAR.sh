#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

bold() { printf '\n\033[1m%s\033[0m\n' "$1"; }
fail() { printf '\nERRO: %s\n' "$1" >&2; exit 1; }

IS_TERMUX=0
if [[ "${PREFIX:-}" == *com.termux* ]] || [[ -d /data/data/com.termux ]]; then
  IS_TERMUX=1
fi

bold "JARVIS OS 4.2 — instalador e inicializador"

# Termux pode instalar as dependências de sistema necessárias para os recursos Android.
if (( IS_TERMUX )); then
  if ! command -v pkg >/dev/null 2>&1; then
    fail "Termux/pkg não encontrado. Execute este arquivo dentro do aplicativo Termux oficial."
  fi
  NEED_SYSTEM=0
  command -v python >/dev/null 2>&1 || NEED_SYSTEM=1
  command -v ffmpeg >/dev/null 2>&1 || NEED_SYSTEM=1
  command -v ip >/dev/null 2>&1 || NEED_SYSTEM=1
  if (( NEED_SYSTEM )); then
    bold "[1/6] Atualizando pacotes do Termux e instalando componentes de sistema..."
    pkg update -y || fail "Não foi possível atualizar a lista de pacotes do Termux. Confira o mirror e a conexão e tente novamente."

    # iproute2 fornece o comando 'ip' usado para identificar a rede local.
    # Não instalar 'iputils': esse nome de pacote não está disponível no repositório
    # Termux padrão. A descoberta por ping é opcional; a tabela de vizinhos ARP
    # continua sendo consultada quando o Android disponibiliza essa informação.
    pkg install -y python iproute2 python-cryptography || fail "Falha ao instalar Python/iproute2/python-cryptography. Confira os repositórios do Termux e tente novamente."

    # FFmpeg é necessário apenas para recursos de mídia, portanto sua falha não
    # deve impedir o JARVIS básico de iniciar.
    if ! command -v ffmpeg >/dev/null 2>&1; then
      if ! pkg install -y ffmpeg; then
        printf 'AVISO: FFmpeg não foi instalado. O JARVIS inicia normalmente, mas recursos de mídia que dependem dele ficarão indisponíveis.\n' >&2
      fi
    fi
  else
    printf '[1/6] Componentes de sistema encontrados.\n'
  fi

  command -v python >/dev/null 2>&1 || fail "Python não foi encontrado após a instalação. Execute: pkg install python"
  command -v ip >/dev/null 2>&1 || fail "O comando 'ip' não foi encontrado após a instalação. Execute: pkg install iproute2"

  # cryptography depende de código nativo/Rust. No Termux, use o pacote binário
  # mantido pelo próprio repositório, em vez de tentar compilá-lo pelo pip.
  if ! python -c 'import cryptography' >/dev/null 2>&1; then
    bold "Instalando cryptography pré-compilado do Termux..."
    pkg install -y python-cryptography || fail "Não foi possível instalar python-cryptography. Execute: pkg update && pkg install python-cryptography"
  fi
  python -c 'import cryptography' >/dev/null 2>&1 || fail "O módulo cryptography não ficou disponível no Python do Termux. Confira: pkg reinstall python-cryptography"

  # Maturin exige o nível de API Android explicitamente em alguns builds.
  # A variável não substitui pacotes binários; evita apenas a falha de detecção.
  if command -v getprop >/dev/null 2>&1; then
    DETECTED_ANDROID_API="$(getprop ro.build.version.sdk 2>/dev/null || true)"
  else
    DETECTED_ANDROID_API=""
  fi
  if [[ "${ANDROID_API_LEVEL:-}" =~ ^[0-9]+$ ]]; then
    : # valor já definido pelo usuário
  elif [[ "$DETECTED_ANDROID_API" =~ ^[0-9]+$ ]]; then
    export ANDROID_API_LEVEL="$DETECTED_ANDROID_API"
  else
    export ANDROID_API_LEVEL=24
  fi
  printf 'Android API level: %s\n' "$ANDROID_API_LEVEL"
  if ! command -v ffmpeg >/dev/null 2>&1; then
    printf 'AVISO: FFmpeg não está instalado; recursos de mídia podem ficar indisponíveis. Instale com: pkg install ffmpeg\n' >&2
  fi
  PYTHON_BIN="$(command -v python)"
else
  # Procura a versão mais nova disponível, mas aceita Python 3.10 ou superior.
  PYTHON_BIN=""
  for candidate in python3.14 python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
      if "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then
        PYTHON_BIN="$(command -v "$candidate")"
        break
      fi
    fi
  done
  [[ -n "$PYTHON_BIN" ]] || fail "Python 3.10 ou superior não encontrado. Instale Python 3.10+ e execute novamente."
fi

PY_VER="$("$PYTHON_BIN" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
"$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' \
  || fail "Python 3.10 ou superior é necessário. Versão encontrada: $PY_VER"

VENV=".venv"
if (( IS_TERMUX )); then
  # Ambiente próprio do Termux: precisa enxergar os pacotes binários do pkg.
  VENV=".venv-termux-$PY_VER"
  if [[ -f "$VENV/pyvenv.cfg" ]] && ! grep -Eiq '^include-system-site-packages[[:space:]]*=[[:space:]]*true' "$VENV/pyvenv.cfg"; then
    printf 'Recriando o ambiente Termux para habilitar os pacotes Python do sistema...\n'
    rm -rf "$VENV"
  fi
fi
if [[ -x "$VENV/bin/python" ]]; then
  VENV_VER="$("$VENV/bin/python" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  if [[ "$VENV_VER" != "$PY_VER" ]]; then
    VENV=".venv-jarvis-$PY_VER"
  fi
fi

if [[ ! -x "$VENV/bin/python" ]]; then
  bold "[2/6] Criando ambiente Python isolado..."
  if (( IS_TERMUX )); then
    "$PYTHON_BIN" -m venv --system-site-packages "$VENV" || fail "Não foi possível criar o ambiente virtual do Termux."
  else
    "$PYTHON_BIN" -m venv "$VENV" || fail "Não foi possível criar o ambiente virtual."
  fi
else
  printf '[2/6] Ambiente Python encontrado (%s).\n' "$VENV"
fi

# shellcheck disable=SC1091
source "$VENV/bin/activate"

bold "[3/6] Atualizando pip..."
python -m pip install --disable-pip-version-check --upgrade pip

bold "[4/6] Baixando e instalando as dependências principais..."
if (( IS_TERMUX )); then
  # Confirma que o venv realmente herdou o cryptography instalado pelo pkg.
  python -c 'import cryptography' >/dev/null 2>&1 || fail "O ambiente virtual não está enxergando python-cryptography do Termux. Remova apenas $VENV e execute novamente."
fi
if (( IS_TERMUX )); then
  python -m pip install --disable-pip-version-check -r requirements-termux.txt
else
  python -m pip install --disable-pip-version-check -r requirements.txt
fi

if (( ! IS_TERMUX )); then
  bold "[5/6] Instalando recursos opcionais de automação visual para desktop..."
  if ! python -m pip install --disable-pip-version-check -r requirements-desktop.txt; then
    printf 'AVISO: os recursos opcionais de automação visual não foram instalados.\n' >&2
  fi
else
  printf '[5/6] Recursos de desktop ignorados no Android; o Termux não é um desktop gráfico.\n'
fi

if (( IS_TERMUX )); then
  python -c 'import cryptography; print("cryptography disponível:", cryptography.__version__)' || fail "Falha ao validar cryptography no ambiente virtual."
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  printf 'Arquivo .env criado. Suas futuras configurações não serão sobrescritas.\n'
fi

PORT="$(python -c 'from app.config import settings; print(settings.port)')"

bold "[6/6] Iniciando o JARVIS..."
printf 'Endereço local: http://127.0.0.1:%s\n' "$PORT"
printf 'Depois que aparecer a mensagem de servidor iniciado, abra esse endereço no navegador.\n'
printf 'Mantenha este terminal aberto. Para encerrar, pressione Ctrl+C.\n\n'
exec python -m app.main
