# JARVIS OS v4.3 — agente pessoal multimodelo

O JARVIS OS v4.3 preserva o núcleo do v4.1 e acrescenta arquitetura adaptativa inspirada no G0DM0D3: seleção multimodelo, AutoTune, comparação ULTRAPLINIAN, pesquisa aprofundada, criação assistida por IA e automação visual do computador. O backend é Python/FastAPI; a interface é HTML/CSS/JavaScript responsiva. O PC pode hospedar o núcleo e o Android pode acessá-lo pelo Chrome na mesma rede. Também permanece disponível a execução direta no Android via Termux. **O projeto web não é, por si só, um APK Android independente.**

## Principais recursos

### Assistente, memória e provedores
- OpenAI pela Responses API, Gemini e modelos locais compatíveis com a API OpenAI (por exemplo, Ollama ou LM Studio).
- Preferência de provedor configurável no chat: automático, OpenAI, Gemini ou local.
- AutoTune baseado em regras locais: classifica conversa, análise, criação e programação, ajustando parâmetros sem uma chamada extra de IA.
- Memória persistente SQLite: listar, salvar, excluir uma memória ou apagar todas; histórico de conversas salvo e opção de reiniciar a conversa preservando memórias.
- Modo somente local (`JARVIS_LOCAL_ONLY=true`), que desativa OpenAI e Gemini. O endpoint local, por padrão, é limitado a `localhost`/`127.0.0.1`/`::1`.
- ULTRAPLINIAN opcional: compara até três provedores, com no máximo duas requisições simultâneas. A pontuação compara cobertura, diversidade, estrutura e tamanho; **não é um verificador factual nem garante que a resposta vencedora seja verdadeira**.

### Pesquisa e leitura da web
- Pesquisa pública pelo DuckDuckGo HTML e leitura de páginas públicas HTTP/HTTPS.
- Pesquisa aprofundada: faz três buscas com ângulos diferentes, deduplica até 12 resultados, tenta ler até seis páginas e pede uma síntese com referências clicáveis.
- Proteções contra acesso a localhost, IPs privados, endereços reservados, credenciais embutidas e redirecionamentos para redes internas.
- Resultados e textos de páginas são tratados como conteúdo externo não confiável. O JARVIS não faz login, não envia formulários, não compra, não publica nem executa transações automaticamente.
- A pesquisa depende da disponibilidade do DuckDuckGo e dos sites consultados. Sites com bloqueios, paywall, CAPTCHA ou conteúdo dinâmico podem não ser lidos; o JARVIS deve sinalizar essa limitação.

Exemplo de comando: `Jarvis, pesquise profundamente sobre baterias de sódio e compare estudos recentes`.

### Controle e diagnóstico da rede local
- Detecta interfaces IPv4 privadas no dispositivo que hospeda o JARVIS.
- Varre somente a sub-rede privada local detectada (limitada a 256 endereços por execução).
- Usa respostas de ping e tabela ARP para encontrar dispositivos; mostra IP, MAC quando disponível, status e interface.
- Verifica uma lista fixa de portas TCP comuns somente para um dispositivo que apareceu na última varredura e pertence à mesma sub-rede.
- Identifica o gateway quando o sistema operacional disponibiliza essa informação e permite abrir seu painel administrativo no navegador.
- Monitoramento manual em intervalos de 60 segundos enquanto a interface permanece aberta, com aviso de possíveis entradas/saídas; exportação do inventário em CSV.

**Limitações do scanner:** a descoberta não é infalível. Alguns equipamentos bloqueiam ping, isolam clientes Wi-Fi ou não aparecem na tabela ARP. Entradas antigas da tabela ARP não garantem que um dispositivo ainda esteja online. Android/Termux pode expor menos informações que Windows/Linux.

### Automação visual do computador
- O modelo visual pode observar a tela, clicar, mover o mouse, rolar, digitar e usar combinações de teclas permitidas, verificando a tela entre etapas.
- A automação funciona no computador que hospeda o backend, não na tela do celular cliente.
- Requer `JARVIS_DESKTOP_CONTROL=true`, `OPENAI_API_KEY`, PyAutoGUI, Pillow e `pyperclip` no PC com sessão gráfica ativa.
- Cada tarefa exige confirmação explícita; existe botão de parada, limite de 32 ações e limite de cinco minutos. O fail-safe do PyAutoGUI permanece ativo.
- O agente visual não abre terminal/shell, não executa comandos arbitrários, não instala programas, não altera configurações de segurança e não confirma operações irreversíveis.
- As capturas de tela são enviadas ao provedor OpenAI para interpretação. Não use a automação em telas contendo senhas, dados financeiros ou conteúdo privado que não deseja enviar ao provedor.
- O mini JARVIS é arrastável **dentro da janela do navegador**. Esta versão não cria uma janela flutuante sempre-no-topo do Windows.

### Criação com IA
- Criação de projetos por descrição livre: web, Python, Pygame, Godot 4.x e Android/Kotlin.
- Geração de conteúdo para documentos Word (`.docx`) e apresentações PowerPoint (`.pptx`), além de criação manual por texto.
- O gerador limita o número e o tamanho dos arquivos, valida caminhos e extensões e não sobrescreve projetos existentes. Os arquivos do workspace também exigem o token de acesso quando a API está protegida.
- O código gerado não é executado automaticamente. O verificador atual faz checagens estáticas de sintaxe Python/JavaScript e reconhece a estrutura base Godot/Android; isso não substitui testes funcionais no ambiente alvo.
- O botão Compilar APK executa Gradle. Ele pede confirmação explícita e exige JDK, Gradle e Android SDK configurados no PC. O ambiente desta entrega não possui Gradle/Android SDK, portanto não foi possível gerar ou testar um APK aqui.
- Para jogos maiores, Godot é a base mais adequada do que Pygame para projetos 2D/3D com cenas e recursos de engine. O desempenho real depende do código, dos assets e do hardware alvo; não há garantia automática de “alta performance”.

### Imagem, áudio e vídeo
- Geração de imagem via OpenAI Images API com `gpt-image-2.5-flare` (configurável).
- Transcrição de arquivo de áudio via `gpt-transcribe`, com limite de upload de 25 MB.
- Geração de áudio MP3 via Speech API com `gpt-4o-mini-tts`, com vozes selecionáveis e instrução de dicção em português brasileiro.
- Montagem de vídeo MP4 com FFmpeg a partir de 2–30 imagens do workspace e faixa de áudio opcional. **É uma montagem/edição de imagens com áudio, não geração de vídeo original a partir de texto.**
- O microfone e a fala imediata do chat usam as APIs de voz do navegador (SpeechRecognition/SpeechSynthesis) e dependem de suporte/permissão do Chrome/Edge. A seleção de voz pt-BR usa a voz local disponível no navegador quando encontrada.

**Aviso sobre voz gerada por IA:** no momento, o endpoint Speech usado pelo recurso MP3 aceita `gpt-4o-mini-tts`, mas esse modelo está marcado pela OpenAI como deprecated e tem desligamento anunciado para **6 de janeiro de 2027**. Antes dessa data, será necessário migrar o recurso MP3 para o fluxo Realtime recomendado pela OpenAI ou alterar a implementação. A transcrição `gpt-transcribe` é o modelo recomendado atualmente para arquivos de áudio. Consulte os links oficiais em [Text-to-Speech](https://developers.openai.com/api/docs/guides/text-to-speech), [Speech-to-Text](https://developers.openai.com/api/docs/guides/speech-to-text) e [Deprecations](https://developers.openai.com/api/docs/deprecations).

## Adaptação do G0DM0D3 e do segundo APK

O documento `docs/G0DM0D3-ADAPTACAO.md` descreve a adaptação conceitual. O JARVIS implementa sua própria versão de AutoTune, seleção multimodelo, comparação opcional e modos de privacidade. Não copia prompts de jailbreak, payloads ou código ofensivo do repositório. A cópia enviada do G0DM0D3 indicava licença AGPL-3.0; esta adaptação usa conceitos e implementação própria, sem incorporar os arquivos-fonte do repositório. Qualquer futura incorporação de código AGPL deve cumprir essa licença.

O APK anexado foi identificado como uma suíte de terminal/pentest Android Stryker. Seus módulos de ataque (como desautenticação Wi-Fi ou payloads HID) não foram transplantados para o JARVIS. Permanecem apenas os diagnósticos defensivos e de rede local já apropriados ao projeto.

## Inicialização automática (recomendado)

Depois de extrair o ZIP, use o arquivo **INICIAR** correspondente ao seu sistema:

- **Windows:** dê dois cliques em `INICIAR.bat`. Ele prepara o ambiente Python, instala as dependências principais e os módulos opcionais de desktop, configura um token para o acesso local e inicia o JARVIS. Também mostra o endereço para abrir pelo Android no mesmo Wi-Fi.
- **Android (Termux):** execute `bash INICIAR.sh` dentro da pasta `JARVIS`. O script instala os pacotes de sistema necessários, instala as bibliotecas Python e inicia o painel local.
- **Linux/macOS:** execute `chmod +x INICIAR.sh && ./INICIAR.sh`.

O inicializador cria `.env` apenas quando esse arquivo ainda não existe; não substitui suas chaves ou preferências. As chaves OpenAI/Gemini continuam precisando ser adicionadas manualmente ao `.env`. O controle visual do PC permanece desativado até você ativar `JARVIS_DESKTOP_CONTROL=true` explicitamente.

Consulte `INICIAR.txt` para o passo a passo completo e para os requisitos externos, como FFmpeg e Android SDK.

## Requisitos

- Python 3.10 ou superior (o instalador detecta a versão e o pip resolve dependências compatíveis; consulte `PYTHON_COMPATIBILIDADE.txt`).
- Windows 10/11, Linux ou macOS. Android pode funcionar como cliente web sem Termux, ou executar o backend diretamente via Termux.
- `pip install -r requirements.txt` para o núcleo.
- `ffmpeg` no PATH para montar vídeos.
- `ping` e utilitário de rede do sistema (`ip`/`ipconfig`) para descoberta LAN.
- `psutil` é opcional para métricas de CPU/RAM.
- Para controlar o desktop no PC: `pip install -r requirements-desktop.txt` e uma sessão gráfica ativa.
- Para compilar APK: JDK 17, Gradle e Android SDK; `ANDROID_HOME` ou `ANDROID_SDK_ROOT` deve apontar para o SDK.

## Instalação no Windows

1. Instale Python 3.10 ou superior e marque **Add Python to PATH**.
2. Extraia o ZIP.
3. Para uso somente no PC, execute `start_windows.bat`.
4. Para usar o PC como servidor e controlar pelo Android sem Termux, execute `start_windows_pc_android.bat`. O launcher cria um token forte se necessário, configura `JARVIS_HOST=0.0.0.0`, instala as dependências e exibe os endereços e o token.
5. No Android conectado ao mesmo Wi-Fi, abra no Chrome o endereço LAN exibido pelo launcher e informe o token.
6. Para habilitar automação visual no PC, instale `requirements-desktop.txt`, configure as chaves OpenAI e defina `JARVIS_DESKTOP_CONTROL=true` no `.env`. Reinicie o servidor.

O Windows Firewall pode pedir permissão. Permita o Python apenas em redes privadas. Se necessário, crie regra de entrada para a porta configurada (padrão 8787), limitada ao perfil **Privado**.

### Usar no Android sem Termux

O Android funciona como cliente web; não precisa instalar Python, Termux ou dependências no celular. O backend, a memória SQLite, a IA e o scanner rodam no PC. O PC precisa permanecer ligado e os dois dispositivos devem estar na mesma rede. O atalho “Adicionar à tela inicial” não é um APK independente e não permite usar o JARVIS quando o PC estiver desligado.

## Instalação no Android (Termux)

```bash
pkg update && pkg upgrade
pkg install python git termux-api iproute2 python-cryptography
```

Copie a pasta `JARVIS` para o diretório privado do Termux (por exemplo, `~/JARVIS`; evite executar em `/storage/emulated/0/Download`, que não suporta todos os links usados por ambientes virtuais). Entre na pasta e execute:

```bash
bash INICIAR.sh
```

No Termux, o instalador usa `python-cryptography` do repositório do Termux e cria `.venv-termux-*` com `--system-site-packages`, para evitar uma compilação Rust incompatível pelo pip. Também usa `requirements-termux.txt`, que instala o Uvicorn sem extras nativos opcionais que não são necessários para iniciar o servidor Android.

Acesse `http://127.0.0.1:8787` no Chrome. Microfone e voz dependem do navegador e de suas permissões. O scanner pode ter menos visibilidade dependendo da versão do Android.

## Configuração da IA

Copie `.env.example` para `.env` e configure apenas os provedores que deseja usar. As chaves ficam no backend; nunca as coloque em `static/app.js`.

```env
JARVIS_HOST=127.0.0.1
JARVIS_PORT=8787
JARVIS_TOKEN=
JARVIS_AI_PROVIDER=auto
JARVIS_LOCAL_ONLY=false

OPENAI_API_KEY=sua_chave_openai
OPENAI_MODEL=gpt-6.1-sol
OPENAI_COMPUTER_MODEL=gpt-6.1-sol
OPENAI_IMAGE_MODEL=gpt-image-2.5-flare
OPENAI_TRANSCRIPTION_MODEL=gpt-transcribe
OPENAI_TTS_MODEL=gpt-4o-mini-tts

GEMINI_API_KEY=sua_chave_gemini
GEMINI_MODEL=gemini-3.8-flash

JARVIS_LOCAL_BASE_URL=http://127.0.0.1:11434/v1
JARVIS_LOCAL_MODEL=
JARVIS_LOCAL_API_KEY=local
JARVIS_DESKTOP_CONTROL=false
JARVIS_VOICE_REPLY=false
```

O modelo padrão de chat foi ajustado para GPT-6.1 Sol, documentado pela OpenAI como modelo de uso geral compatível com a Responses API. A disponibilidade depende da conta/projeto API e do SDK instalado; consulte [modelos oficiais](https://developers.openai.com/api/docs/models/gpt-6.1-sol). Para custo menor e privacidade, configure um servidor local compatível e `JARVIS_LOCAL_MODEL`. Em `JARVIS_LOCAL_ONLY=true`, não são chamadas APIs em nuvem.

## Exemplos de uso

- `Jarvis, abra o YouTube`
- `Jarvis, pesquise na internet segurança de roteadores domésticos`
- `Jarvis, pesquise profundamente sobre baterias de sódio`
- `Jarvis, leia esta página https://example.com/artigo`
- `Jarvis, escaneie minha rede e mostre quem está conectado`
- `Jarvis, status do sistema`
- `Jarvis, lembre que prefiro respostas diretas`
- `Jarvis, o que você lembra?`

Na página Automação, descreva a tarefa do computador e marque a confirmação. Na área de Criação, descreva um app/jogo, documento ou apresentação para gerar arquivos com a IA. Revise o código antes de executá-lo ou compilá-lo.

## Verificações

```bash
python -m compileall -q app tests tools
python -m pytest -q
node --check static/app.js
node --check static/lab.js
```

Os 43 testes automatizados desta entrega exercitam roteamento, rede, segurança, memória, AutoTune, ULTRAPLINIAN, validação de arquivos/projetos, pesquisa e estado de automação. Eles não substituem um teste real com chaves de API, uma sessão gráfica ativa ou toolchain Android.

## Estrutura

```text
JARVIS/
├── app/
│   ├── agent.py             # roteamento do assistente
│   ├── assistant.py         # OpenAI, Gemini, local e contexto
│   ├── autotune.py          # classificação adaptativa leve
│   ├── ultraplinian.py      # comparação multimodelo
│   ├── research_tools.py    # pesquisa multifonte
│   ├── desktop_agent.py     # loop visual computer-use
│   ├── desktop_tools.py     # captura e ações de mouse/teclado
│   ├── media_tools.py       # imagem, áudio e vídeo
│   ├── workspace_tools.py   # documentos, slides e projetos
│   ├── main.py              # API FastAPI
│   ├── network_tools.py     # descoberta LAN e diagnóstico TCP restrito
│   ├── platform_tools.py    # atalhos locais permitidos
│   ├── database.py          # histórico e memória SQLite
│   └── web_tools.py         # busca e leitor público com proteção SSRF
├── static/
│   ├── index.html           # painel multiplataforma
│   ├── style.css            # tema, animações e responsividade
│   ├── app.js               # chat, voz, rede e memórias
│   └── lab.js               # automação, geração e workspace
├── tests/
├── tools/prepare_lan.py
├── docs/G0DM0D3-ADAPTACAO.md
├── requirements.txt
├── requirements-desktop.txt
├── .env.example
└── start_*.sh / *.bat
```


## Publicação em hospedagem (modo público)

O arquivo `render.yaml` prepara uma implantação inicial de demonstração no Render com `JARVIS_PUBLIC_MODE=true`. O modo público emite uma sessão HttpOnly aleatória por navegador e separa conversas, memórias e workspaces. As ferramentas que atuam na rede local ou no computador hospedeiro ficam desabilitadas na instância compartilhada; pesquisa web, chat e geração de conteúdo permanecem disponíveis quando os provedores estão configurados.

**Antes de publicar:**

1. Crie um repositório público chamado `Jarvis` no GitHub e envie estes arquivos para a branch `main`. A conexão GitHub disponível neste ambiente não concede permissão para criar repositórios novos; ela pode atualizar apenas repositórios já existentes.
2. No Render, crie um Blueprint a partir desse repositório e revise o plano e a região antes de aplicar. O plano `free` no `render.yaml` é apenas para teste: pode suspender por inatividade e o disco local é efêmero. O SQLite e os arquivos do workspace podem se perder em reinicializações/novas implantações. Para uso contínuo, configure armazenamento persistente e backup, ou migre para um banco gerenciado e armazenamento de objetos antes de atender usuários reais.
3. Configure `OPENAI_API_KEY` e/ou `GEMINI_API_KEY` no painel privado **Environment** do Render. Nunca inclua chaves nos arquivos do GitHub, no navegador ou nas mensagens. Este projeto não inclui valores reais de chave.
4. Preencha `JARVIS_LEGAL_NAME`, `JARVIS_LEGAL_ADDRESS`, `JARVIS_PRIVACY_EMAIL` e, quando aplicável, `JARVIS_CNPJ` e `JARVIS_DPO_CONTACT` com dados verdadeiros. O site deixa explícito quando esses dados estão pendentes; não abra comercialmente sem completar a identificação do responsável e revisar os textos com assessoria adequada.
5. Para Google Search Console, cadastre a URL pública, copie o valor da verificação HTML/meta em `GOOGLE_SITE_VERIFICATION`, faça novo deploy e solicite a indexação de `/`. Envie `https://SEU-DOMINIO/sitemap.xml` no Search Console. O sitemap e `robots.txt` já são servidos pelo aplicativo.
6. Para mensuração, configure `GA_MEASUREMENT_ID` e `META_PIXEL_ID` somente se realmente usar esses serviços. Os scripts só são carregados após consentimento explícito de analytics; recusa não impede o uso do chat.

### Disponibilidade e limites do plano gratuito

Uma instância gratuita não é serviço de disponibilidade contínua: pode entrar em suspensão e não oferece armazenamento local persistente. Esta configuração não declara SLA, backup ou disponibilidade 24/7. Consulte os limites atuais da plataforma antes de ativar uma instância paga.

### Dados legais e direitos autorais

A interface inclui rascunhos iniciais de privacidade, termos, cookies, reembolso, formulário de direitos LGPD e acessibilidade. Eles não constituem certificação jurídica nem comprovam conformidade total. O responsável deve revisar bases legais, retenção, contratos de operadores, transferência internacional, procedimento de incidentes, direitos de titulares, acessibilidade e propriedade intelectual. Não são geradas avaliações fictícias ou promessas de resultado.

### Modelos de IA e manutenção

Os padrões atuais do pacote foram ajustados para `gpt-6.1-sol`, `gpt-image-2.5-flare`, `gpt-transcribe` e `gemini-3.8-flash`. O endpoint Speech ainda usa `gpt-4o-mini-tts`, que possui desligamento anunciado para **6 de janeiro de 2027**; antes dessa data, o fluxo precisa ser migrado para Realtime API, não basta trocar o ID no endpoint atual.

### Licença

O ZIP JARVIS v4.2 fornecido não continha arquivo `LICENSE`. Portanto, esta entrega não atribui uma licença permissiva nem declara o código como open source. O repositório G0DM0D3 recebido é AGPL-3.0 e seu código-fonte não foi incorporado a esta base; a documentação incluída registra apenas a referência conceitual.
