@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title JARVIS OS 4.2 - Instalador e Inicializador

 echo.
 echo  ==========================================================
 echo                 J A R V I S   O S   4.2
 echo             Instalacao automatica + inicializacao
 echo  ==========================================================
 echo.

set "PY_CMD="
set "PY_ARGS="
set "VENV=.venv"
set "PY_MINOR="

rem Reutiliza primeiro um ambiente existente se ele tiver Python compativel.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
  if not errorlevel 1 set "PY_CMD=.venv\Scripts\python.exe"
)

rem Procura a versao Python mais nova disponivel (3.10 ou superior).
if not defined PY_CMD (
  where py >nul 2>nul
  if not errorlevel 1 (
    for %%V in (3.14 3.13 3.12 3.11 3.10) do (
      if not defined PY_CMD (
        py -%%V -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
        if not errorlevel 1 (set "PY_CMD=py" & set "PY_ARGS=-%%V")
      )
    )
  )
)

rem Tenta o comando python se for Python 3.10 ou superior.
if not defined PY_CMD (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
    if not errorlevel 1 set "PY_CMD=python"
  )
)

rem Opcional: instala Python 3.12 pelo WinGet quando nenhum Python compativel existe.
if not defined PY_CMD (
  where winget >nul 2>nul
  if not errorlevel 1 (
    echo Python 3.10+ nao encontrado. Tentando instalar Python 3.12 pelo WinGet...
    winget install --id Python.Python.3.12 --exact --scope user --silent --accept-package-agreements --accept-source-agreements
    where py >nul 2>nul
    if not errorlevel 1 (
      py -3.12 -c "import sys" >nul 2>nul
      if not errorlevel 1 (set "PY_CMD=py" & set "PY_ARGS=-3.12")
    )
  )
)

if not defined PY_CMD (
  echo ERRO: Python 3.10 ou superior nao foi encontrado.
  echo Instale em https://www.python.org/downloads/ e marque "Add Python to PATH".
  echo Depois execute este arquivo novamente.
  pause
  exit /b 1
)

rem Identifica a versao selecionada para nomear ambientes alternativos sem apagar nada.
for /f %%V in ('%PY_CMD% %PY_ARGS% -c "import sys; print(str(sys.version_info.minor))"') do set "PY_MINOR=%%V"

rem Se o .venv existente for de outra versao, cria um ambiente separado sem apaga-lo.
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
  if errorlevel 1 set "VENV=.venv-3.%PY_MINOR%"
)

if exist "%VENV%\Scripts\python.exe" (
  "%VENV%\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul
  if errorlevel 1 (
    echo ERRO: o ambiente %VENV% existe, mas usa uma versao Python incompatível.
    echo Renomeie essa pasta para preservar seus arquivos e execute novamente.
    pause
    exit /b 1
  )
)

if not exist "%VENV%\Scripts\python.exe" (
  echo [1/6] Criando ambiente Python isolado...
  %PY_CMD% %PY_ARGS% -m venv "%VENV%"
  if errorlevel 1 (
    echo ERRO: nao foi possivel criar o ambiente virtual.
    pause
    exit /b 1
  )
) else (
  echo [1/6] Ambiente Python encontrado.
)

set "VENV_PY=%VENV%\Scripts\python.exe"
echo [2/6] Atualizando o instalador de pacotes...
"%VENV_PY%" -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 goto :install_error

echo [3/6] Baixando e instalando todas as dependencias principais...
"%VENV_PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto :install_error

echo [4/6] Instalando recursos opcionais de controle visual do PC...
"%VENV_PY%" -m pip install --disable-pip-version-check -r requirements-desktop.txt
if errorlevel 1 (
  echo AVISO: os recursos opcionais de controle visual nao foram instalados.
  echo O nucleo do JARVIS ainda pode iniciar. Verifique a mensagem acima.
)

if not exist ".env" (
  echo Criando configuracao inicial .env sem sobrescrever configuracoes existentes...
  copy /Y ".env.example" ".env" >nul
)

echo [5/6] Preparando acesso protegido pela rede local...
set "LAN_IP=IP_NAO_DETECTADO"
set "LAN_PORT=8787"
set "JARVIS_TOKEN="
for /f "tokens=1,* delims==" %%A in ('"%VENV_PY%" tools\prepare_lan.py --machine') do set "%%A=%%B"
if not defined JARVIS_TOKEN (
  echo ERRO: nao foi possivel gerar ou ler o token de acesso.
  pause
  exit /b 1
)

echo.
echo  ==========================================================
echo  [6/6] JARVIS pronto para iniciar!
echo.
echo  PC:       http://127.0.0.1:%LAN_PORT%
if /i not "%LAN_IP%"=="IP_NAO_DETECTADO" echo  Android:  http://%LAN_IP%:%LAN_PORT%
echo  TOKEN:    %JARVIS_TOKEN%
echo.
echo  Android e PC devem estar conectados ao mesmo Wi-Fi.
echo  Mantenha esta janela aberta enquanto usar o JARVIS.
echo  Para encerrar: pressione Ctrl+C.
echo  ==========================================================
echo.

"%VENV_PY%" -m app.main
if errorlevel 1 (
  echo.
  echo O JARVIS foi encerrado com erro. Copie a mensagem acima para diagnostico.
)
echo.
pause
exit /b 0

:install_error
echo.
echo ERRO: houve uma falha ao baixar/instalar dependencias.
echo Verifique sua internet e tente executar INICIAR.bat novamente.
pause
exit /b 1
