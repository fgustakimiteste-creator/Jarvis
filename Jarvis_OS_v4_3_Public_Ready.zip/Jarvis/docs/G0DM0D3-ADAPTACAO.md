# Adaptação conceitual do G0DM0D3

O JARVIS OS 4.3 adapta ideias de arquitetura do pacote G0DM0D3 enviado pelo usuário, sem transplantar seus prompts de jailbreak, payloads ou código ofensivo:

- AutoTune local baseado em regras para classificar a intenção e ajustar a estratégia sem chamar outro modelo.
- ULTRAPLINIAN opcional para comparar até três provedores, com no máximo duas requisições simultâneas.
- Seleção multimodelo OpenAI, Gemini ou endpoint local loopback compatível com a API OpenAI.
- Modo somente local e política de contexto local-first.
- Registro de execução e limites observáveis para tarefas visuais.

A pontuação do ULTRAPLINIAN é heurística e não constitui detector de verdade, verificador factual ou garantia de qualidade. Para reduzir o consumo de RAM, os modelos são chamados por API e não ficam todos carregados no processo do JARVIS.

O arquivo original G0DM0D3-main.zip indicava licença AGPL-3.0. Esta adaptação utiliza conceitos e uma implementação própria; não incorpora arquivos-fonte do repositório original. Qualquer incorporação futura de código AGPL deve preservar os avisos e cumprir a licença aplicável.
