from __future__ import annotations

import ipaddress
from pathlib import Path

from tools.prepare_lan import detect_lan_ip, prepare_env


def test_prepare_env_generates_token_and_preserves_existing_settings(tmp_path: Path) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text(
        "# Keep user configuration\nGEMINI_API_KEY=keep-this-key\nJARVIS_PORT=8999\nJARVIS_TOKEN=\n",
        encoding="utf-8",
    )

    host, port, token = prepare_env(env_path)
    content = env_path.read_text(encoding="utf-8")

    assert host == "0.0.0.0"
    assert port == 8999
    assert len(token) >= 40
    assert "GEMINI_API_KEY=keep-this-key" in content
    assert "JARVIS_HOST=0.0.0.0" in content
    assert f"JARVIS_TOKEN={token}" in content


def test_prepare_env_is_idempotent_and_keeps_existing_token(tmp_path: Path) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text("JARVIS_TOKEN=my-existing-token\nJARVIS_HOST=127.0.0.1\n", encoding="utf-8")

    first = prepare_env(env_path)
    second = prepare_env(env_path)

    assert first[2] == "my-existing-token"
    assert second[2] == "my-existing-token"
    assert env_path.read_text(encoding="utf-8").count("JARVIS_TOKEN=") == 1


def test_prepare_env_recovers_invalid_port(tmp_path: Path) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text("JARVIS_PORT=abc\n", encoding="utf-8")
    assert prepare_env(env_path)[1] == 8787


def test_detect_lan_ip_returns_private_ipv4_or_explicit_fallback() -> None:
    result = detect_lan_ip()
    if result != "IP_NAO_DETECTADO":
        address = ipaddress.ip_address(result)
        assert address.version == 4
        assert address.is_private
        assert not address.is_loopback
