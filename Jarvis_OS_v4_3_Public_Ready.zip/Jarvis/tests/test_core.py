from __future__ import annotations

import ipaddress
from pathlib import Path

import pytest

from app import platform_tools, network_tools, web_tools, agent


def test_open_website_rejects_non_http_schemes():
    with pytest.raises(ValueError):
        platform_tools.open_website("javascript:alert(1)")
    with pytest.raises(ValueError):
        platform_tools.open_website("file:///etc/passwd")


def test_open_website_rejects_embedded_credentials():
    with pytest.raises(ValueError):
        platform_tools.open_website("https://user:password@example.com")


def test_search_command_delegates_to_safe_search(monkeypatch):
    seen = {}
    monkeypatch.setattr(platform_tools, "search_web", lambda query: seen.setdefault("query", query) or "ok")
    result = platform_tools.handle_local_command("Jarvis, pesquise inteligência artificial")
    assert result == "inteligência artificial"
    assert seen["query"] == "inteligência artificial"


def test_unknown_text_is_not_executed_as_a_command():
    assert platform_tools.handle_local_command("execute rm -rf /") is None


def test_app_allowlist_rejects_arbitrary_program(monkeypatch):
    monkeypatch.setattr(platform_tools, "is_termux", lambda: False)
    result = platform_tools.open_application("powershell com parâmetros")
    assert "lista segura" in result


def test_known_site_command_accepts_article_and_does_not_shell(monkeypatch):
    seen = {}
    monkeypatch.setattr(platform_tools, "open_website", lambda url: seen.setdefault("url", url) or "ok")
    result = platform_tools.handle_local_command("Jarvis, abra o YouTube")
    assert result == "https://www.youtube.com"
    assert seen["url"] == "https://www.youtube.com"


def test_unknown_application_is_rejected_without_launching(monkeypatch):
    monkeypatch.setattr(platform_tools, "is_termux", lambda: False)
    result = platform_tools.handle_local_command("Jarvis, abra o PowerShell")
    assert result is None


def test_web_agent_detects_explicit_search_intent():
    assert agent._search_query("Jarvis, pesquise na internet segurança de roteadores") == "segurança de roteadores"
    assert agent._search_query("busque sobre astronomia") == "astronomia"
    assert agent._search_query("converse comigo") is None


def test_web_agent_detects_public_page_read_request():
    assert agent._page_url("Leia esta página https://example.com/artigo") == "https://example.com/artigo"
    assert agent._page_url("Abra o YouTube") is None


def test_web_reader_rejects_private_and_local_addresses(monkeypatch):
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://127.0.0.1:8787")
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://192.168.1.1")
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://router.local")


def test_search_url_unwrap_only_keeps_http_targets():
    assert web_tools._unwrap_search_url("https://example.com/path") == "https://example.com/path"
    assert web_tools._unwrap_search_url("javascript:alert(1)") == ""


def test_network_port_scan_requires_host_from_last_private_scan(monkeypatch):
    monkeypatch.setattr(network_tools, "_LAST_SCAN", {
        "cidr": "192.168.1.0/24",
        "devices": [{"ip": "192.168.1.25", "is_self": False}],
    })
    with pytest.raises(ValueError):
        network_tools.scan_device_ports("8.8.8.8")
    with pytest.raises(ValueError):
        network_tools.scan_device_ports("192.168.1.26")


def test_network_port_scan_checks_only_fixed_common_ports(monkeypatch):
    monkeypatch.setattr(network_tools, "_LAST_SCAN", {
        "cidr": "192.168.1.0/24",
        "devices": [{"ip": "192.168.1.25", "is_self": False}],
    })
    calls = []
    class FakeSocket:
        def settimeout(self, _): pass
        def connect_ex(self, target): calls.append(target); return 1
        def close(self): pass
    monkeypatch.setattr(network_tools.socket, "socket", lambda *_: FakeSocket())
    result = network_tools.scan_device_ports("192.168.1.25")
    assert calls
    assert set(port for _, port in calls) == set(network_tools.COMMON_PORTS)
    assert result["open_ports"] == []


def test_memory_crud_helpers(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import database
    monkeypatch.setattr(database, "settings", SimpleNamespace(database_path=tmp_path / "test.db"))
    database.init_db()
    memory_id = database.save_memory("Prefiro respostas diretas")
    assert database.delete_memory(memory_id) is True
    assert database.delete_memory(memory_id) is False
    database.save_memory("Outra memória")
    database.clear_memories()
    assert database.list_memories() == []


def test_local_network_scan_builds_inventory_from_lan_only(monkeypatch):
    async def fake_ping(ip, semaphore):
        return ip == "192.168.50.20"
    monkeypatch.setattr(network_tools, "get_network_context", lambda: {
        "interface": "wlan0", "ip": "192.168.50.10", "cidr": "192.168.50.0/24", "gateway": "192.168.50.1", "router_url": "http://192.168.50.1"
    })
    monkeypatch.setattr(network_tools, "_arp_table", lambda: {"192.168.50.30": "aa:bb:cc:dd:ee:ff"})
    monkeypatch.setattr(network_tools, "_ping", fake_ping)
    import asyncio
    result = asyncio.run(network_tools.scan_local_network())
    ips = {device["ip"] for device in result["devices"]}
    assert "192.168.50.10" in ips
    assert "192.168.50.20" in ips
    assert "192.168.50.30" in ips
    assert result["cidr"] == "192.168.50.0/24"


def test_search_parser_handles_relative_duckduckgo_result_links():
    from urllib.parse import quote
    target = "https://example.org/article"
    relative = "/l/?uddg=" + quote(target, safe="")
    assert web_tools._unwrap_search_url(relative) == target


def test_public_page_parser_removes_navigation_and_script_text():
    parser = web_tools._TextParser()
    parser.feed("<html><head><title>Title</title><script>secret_code()</script></head><body><nav>Menu</nav><h1>Heading</h1><p>Visible article text</p></body></html>")
    parsed = " ".join(parser.parts)
    assert "Visible article text" in parsed
    assert "secret_code" not in parsed
    assert "Menu" not in parsed


def test_explicit_disconnect_request_never_claims_device_was_blocked(monkeypatch):
    from app import agent
    monkeypatch.setattr(agent, "add_message", lambda *args: None)
    monkeypatch.setattr(agent, "get_network_context", lambda: {"gateway": "192.168.1.1"})
    reply, mode, payload = agent.process_user_message("Jarvis, desconecte o aparelho 192.168.1.25 do Wi-Fi")
    assert mode == "local"
    assert payload is None
    assert "Nenhum dispositivo foi desconectado" in reply
    assert "192.168.1.1" in reply


def test_autotune_separates_image_creation_from_software_development():
    from app.autotune import classify_context
    creative = classify_context("Crie uma imagem cinematográfica de uma cidade à noite")
    code = classify_context("Implemente uma API em Python e corrija esse bug")
    assert creative.context == "creative"
    assert code.context == "code"


def test_ultraplinian_score_is_bounded_and_transparent():
    from app.ultraplinian import score_candidate
    result = score_candidate("Explique memória RAM", "A memória RAM é usada pelo computador.\n\nEla guarda dados temporários.")
    assert 0 <= result["score"] <= 100
    assert result["word_count"] > 0


def test_local_model_endpoint_rejects_non_loopback_hosts():
    from app.assistant import _local_endpoint_allowed
    assert _local_endpoint_allowed("http://127.0.0.1:11434/v1")
    assert _local_endpoint_allowed("http://localhost:1234/v1")
    assert not _local_endpoint_allowed("http://192.168.1.50:11434/v1")
    assert not _local_endpoint_allowed("https://localhost:11434/v1")


def test_workspace_file_writer_refuses_overwrite_by_default(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    first = workspace_tools.write_text_file("notas.md", "primeira versão")
    root = workspace_tools.workspace_root()
    assert (root / "notas.md").read_text(encoding="utf-8") == "primeira versão"
    with pytest.raises(ValueError, match="já existe"):
        workspace_tools.write_text_file("notas.md", "segunda versão")
    workspace_tools.write_text_file("notas.md", "segunda versão", overwrite=True)
    assert (root / "notas.md").read_text(encoding="utf-8") == "segunda versão"
    assert first["name"] == "notas.md"


def test_workspace_writer_rejects_paths_and_unsupported_extensions(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    with pytest.raises(ValueError):
        workspace_tools.write_text_file("../outside.py", "print('x')")
    with pytest.raises(ValueError):
        workspace_tools.write_text_file("file.exe", "binary")


def test_workspace_project_creation_never_overwrites_existing_project(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    created = workspace_tools.create_project("meu-app", "web")
    sentinel = workspace_tools.workspace_root() / "meu-app" / "index.html"
    sentinel.write_text("conteúdo preservado", encoding="utf-8")
    with pytest.raises(ValueError, match="Já existe"):
        workspace_tools.create_project("meu-app", "web")
    assert sentinel.read_text(encoding="utf-8") == "conteúdo preservado"
    assert created["project"] == "meu-app"


def test_desktop_actions_require_enablement_and_confirmation(monkeypatch):
    from types import SimpleNamespace
    from app import desktop_tools
    monkeypatch.setattr(desktop_tools, "settings", SimpleNamespace(desktop_control_enabled=True))
    with pytest.raises(PermissionError):
        desktop_tools.execute_action({"type": "click", "x": 5, "y": 5}, confirmed=False)


def test_desktop_coordinate_bounds_are_enforced(monkeypatch):
    from app import desktop_tools
    class FakePyAutoGUI:
        FAILSAFE = False
        PAUSE = 0
        @staticmethod
        def size(): return (100, 80)
    monkeypatch.setattr(desktop_tools, "_pyautogui", lambda: FakePyAutoGUI())
    assert desktop_tools._coordinates(99, 79) == (99, 79)
    with pytest.raises(ValueError):
        desktop_tools._coordinates(100, 79)


def test_desktop_agent_rejects_unknown_action_type(monkeypatch):
    from app import desktop_agent
    class FakePyAutoGUI: pass
    monkeypatch.setattr(desktop_agent, "_pyautogui", lambda: FakePyAutoGUI())
    with pytest.raises(ValueError, match="não suportada"):
        desktop_agent._perform_ai_action({"type": "shell"})


def test_ai_project_builder_creates_only_validated_source_files(tmp_path, monkeypatch):
    from types import SimpleNamespace
    import json
    from app import workspace_tools, assistant, database
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    monkeypatch.setattr(database, "recent_messages", lambda _limit: [])
    response = {"summary": "Um painel simples", "files": {
        "index.html": "<!doctype html><html lang='pt-BR'><meta charset='utf-8'><title>Teste</title><body>Olá</body></html>",
        "README.md": "# Painel\n\nAbra index.html.",
        "assets/style.css": "body { font-family: sans-serif; }",
        "assets/app.js": "console.log('ready');"
    }}
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: (json.dumps(response), "openai"))
    result = workspace_tools.create_project_with_ai("painel-teste", "web", "Crie um painel simples", "auto")
    assert result["ok"] is True
    assert result["provider"] == "openai"
    assert (workspace_tools.workspace_root() / "painel-teste" / "assets" / "app.js").is_file()
    assert result["executed"] is False


def test_ai_project_builder_rejects_path_traversal_before_creating_folder(tmp_path, monkeypatch):
    from types import SimpleNamespace
    import json
    from app import workspace_tools, assistant, database
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    monkeypatch.setattr(database, "recent_messages", lambda _limit: [])
    response = {"summary": "Inválido", "files": {"index.html": "ok", "../outside.py": "print('bad')"}}
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: (json.dumps(response), "local"))
    with pytest.raises(RuntimeError, match="Caminho de arquivo inválido"):
        workspace_tools.create_project_with_ai("sem-risco", "web", "Crie um site seguro", "auto")
    root = workspace_tools.workspace_root()
    assert not (root / "sem-risco").exists()
    assert not (root / "outside.py").exists()


def test_ai_project_builder_does_not_overwrite_existing_project(tmp_path, monkeypatch):
    from types import SimpleNamespace
    import json
    from app import workspace_tools, assistant, database
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    monkeypatch.setattr(database, "recent_messages", lambda _limit: [])
    existing = workspace_tools.workspace_root() / "already-there"
    existing.mkdir()
    sentinel = existing / "index.html"
    sentinel.write_text("preservar", encoding="utf-8")
    response = {"summary": "Site", "files": {"index.html": "novo", "README.md": "readme"}}
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: (json.dumps(response), "openai"))
    with pytest.raises(ValueError, match="Já existe"):
        workspace_tools.create_project_with_ai("already-there", "web", "Crie um site", "auto")
    assert sentinel.read_text(encoding="utf-8") == "preservar"


def test_desktop_automation_constructor_failure_resets_running_state(monkeypatch):
    import sys
    from types import ModuleType, SimpleNamespace
    from app import desktop_agent
    class FakeOpenAI:
        def __init__(self, **_kwargs):
            raise RuntimeError("falha ao criar cliente")
    fake_module = ModuleType("openai")
    fake_module.OpenAI = FakeOpenAI
    monkeypatch.setitem(sys.modules, "openai", fake_module)
    monkeypatch.setattr(desktop_agent, "settings", SimpleNamespace(desktop_control_enabled=True, openai_api_key="sk-test"))
    desktop_agent._update_task(running=False)
    with pytest.raises(RuntimeError, match="falha ao criar cliente"):
        desktop_agent.run_computer_task("Abra o navegador")
    assert desktop_agent.desktop_task_status()["running"] is False


def test_agent_detects_deep_research_intent():
    assert agent._deep_research_query("Jarvis, pesquise profundamente sobre baterias de sódio") == "baterias de sódio"
    assert agent._deep_research_query("Faça uma pesquisa aprofundada sobre energia solar") == "energia solar"
    assert agent._deep_research_query("Converse comigo sobre energia solar") is None


def test_deep_research_searches_multiple_angles_and_cites_read_sources(monkeypatch):
    from app import research_tools
    seen_queries = []
    def fake_search(query, limit=7):
        seen_queries.append(query)
        return {"results": [
            {"title": "Fonte A", "url": "https://example.org/a", "snippet": "Resumo A"},
            {"title": "Fonte B", "url": "https://example.org/b", "snippet": "Resumo B"},
        ]}
    def fake_read(url):
        return {"title": "Página " + url[-1], "url": url, "text": "Conteúdo verificado para síntese."}
    monkeypatch.setattr(research_tools, "search_public_web", fake_search)
    monkeypatch.setattr(research_tools, "read_public_page", fake_read)
    monkeypatch.setattr(research_tools, "ask_ai", lambda prompt, extra_context, provider: ("Relatório com referências [1] e [2].", {"provider": "local"}))
    result = research_tools.deep_research_public("tema de pesquisa", "local")
    assert len(set(seen_queries)) == 3
    assert result["search_result_count"] == 2
    assert result["pages_read"] == 2
    assert "https://example.org/a" in result["reply"]
    assert "https://example.org/b" in result["reply"]


def test_godot_starter_template_is_created_without_overwrite(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    result = workspace_tools.create_project("jogo-3d", "godot")
    root = workspace_tools.workspace_root()
    assert (root / "jogo-3d" / "project.godot").is_file()
    assert (root / "jogo-3d" / "Main.tscn").is_file()
    assert result["project"] == "jogo-3d"


def test_document_can_be_drafted_by_ai_and_saved_as_docx(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools, assistant, database
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    monkeypatch.setattr(database, "recent_messages", lambda _limit: [])
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: ("# Introdução\n\nConteúdo completo do relatório.", "gemini"))
    result = workspace_tools.create_document_with_ai("relatorio.docx", "Relatório", "Crie um relatório sobre um tema de teste", "auto")
    assert result["generated_by_ai"] is True
    assert result["provider"] == "gemini"
    assert (workspace_tools.workspace_root() / "relatorio.docx").is_file()


def test_presentation_can_be_generated_and_invalid_json_is_rejected(tmp_path, monkeypatch):
    from types import SimpleNamespace
    import json
    from app import workspace_tools, assistant, database
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path))
    monkeypatch.setattr(database, "recent_messages", lambda _limit: [])
    payload = {"title": "Ciência", "slides": [{"title": f"Slide {i}", "bullets": ["Ponto A", "Ponto B"]} for i in range(1, 5)]}
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: (json.dumps(payload), "openai"))
    result = workspace_tools.create_presentation_with_ai("ciencia.pptx", "Ciência", "Crie uma apresentação sobre um tema de ciência", "auto")
    assert result["generated_by_ai"] is True
    assert result["slides"] == 4
    assert (workspace_tools.workspace_root() / "ciencia.pptx").is_file()
    monkeypatch.setattr(assistant, "ask_provider_with_name", lambda *args, **kwargs: ("não é json", "openai"))
    with pytest.raises(RuntimeError, match="JSON válido"):
        workspace_tools.create_presentation_with_ai("invalida.pptx", "Inválida", "Crie uma apresentação de teste", "auto")
    assert not (workspace_tools.workspace_root() / "invalida.pptx").exists()


def test_new_generation_endpoint_is_wired_and_protected(monkeypatch):
    from fastapi.testclient import TestClient
    from app import main
    monkeypatch.setattr(main, "create_project_with_ai", lambda name, project_type, prompt, provider: {
        "ok": True, "project": name, "provider": provider, "files": ["index.html"], "executed": False
    })
    client = TestClient(main.app)
    response = client.post("/api/workspace/project/generate", json={
        "name": "route-test", "project_type": "web", "prompt": "Crie um projeto web de teste", "provider": "local"
    })
    assert response.status_code == 200
    assert response.json()["provider"] == "local"


def test_tts_uses_streaming_response_and_saves_nonempty_mp3(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from contextlib import contextmanager
    from app import media_tools
    monkeypatch.setattr(media_tools, "settings", SimpleNamespace(openai_api_key="sk-test", openai_tts_model="gpt-4o-mini-tts"))
    monkeypatch.setattr(media_tools, "workspace_root", lambda: tmp_path)
    seen = {}
    class Stream:
        def stream_to_file(self, path):
            Path(path).write_bytes(b"ID3-test-audio")
    @contextmanager
    def fake_create(**kwargs):
        seen.update(kwargs)
        yield Stream()
    fake_client = SimpleNamespace(audio=SimpleNamespace(speech=SimpleNamespace(with_streaming_response=SimpleNamespace(create=fake_create))), close=lambda: None)
    monkeypatch.setattr(media_tools, "_client", lambda: fake_client)
    result = media_tools.generate_speech("Olá, JARVIS", "marin")
    assert result["size"] > 0
    assert seen["voice"] == "marin"
    assert seen["response_format"] == "mp3"


def test_workspace_download_requires_token_and_serves_only_workspace_files(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from fastapi.testclient import TestClient
    from app import main
    monkeypatch.setattr(main, "settings", SimpleNamespace(api_token="test-secret", workspace_dir=tmp_path, public_mode=False))
    from app.session_context import session_workspace_dir, set_session_id, reset_session_id
    session_id = "visitor-test-0123456789abcdefghijklmnopqrstuvwxyz"
    context_token = set_session_id(session_id)
    try:
        private_root = session_workspace_dir(tmp_path)
        (private_root / "private.txt").write_text("conteúdo privado", encoding="utf-8")
    finally:
        reset_session_id(context_token)
    client = TestClient(main.app)
    client.cookies.set("jarvis_session", session_id)
    denied = client.get("/workspace/private.txt")
    assert denied.status_code == 401
    allowed = client.get("/workspace/private.txt", headers={"X-Jarvis-Token": "test-secret"})
    assert allowed.status_code == 200
    assert allowed.content == "conteúdo privado".encode("utf-8")


def test_database_messages_and_memories_are_session_scoped(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import database, session_context
    monkeypatch.setattr(database, "settings", SimpleNamespace(database_path=tmp_path / "sessions.db"))
    database.init_db()
    a = session_context.set_session_id("visitor-A-0123456789abcdefghijklmnopqrstuvwxyz")
    try:
        database.add_message("user", "conversa privada A")
        memory_a = database.save_memory("memória exclusiva A")
    finally:
        session_context.reset_session_id(a)
    b = session_context.set_session_id("visitor-B-0123456789abcdefghijklmnopqrstuvwxyz")
    try:
        database.add_message("user", "conversa privada B")
        assert [row["content"] for row in database.recent_messages()] == ["conversa privada B"]
        assert database.list_memories() == []
        assert database.delete_memory(memory_a) is False
    finally:
        session_context.reset_session_id(b)
    a = session_context.set_session_id("visitor-A-0123456789abcdefghijklmnopqrstuvwxyz")
    try:
        assert [row["content"] for row in database.recent_messages()] == ["conversa privada A"]
        assert database.list_memories()[0]["content"] == "memória exclusiva A"
    finally:
        session_context.reset_session_id(a)


def test_workspace_files_are_isolated_between_sessions(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import workspace_tools, session_context
    monkeypatch.setattr(workspace_tools, "settings", SimpleNamespace(workspace_dir=tmp_path / "workspaces"))
    token = session_context.set_session_id("visitor-A-0123456789abcdefghijklmnopqrstuvwxyz")
    try:
        workspace_tools.write_text_file("privado.txt", "conteúdo A")
        first_root = workspace_tools.workspace_root()
    finally:
        session_context.reset_session_id(token)
    token = session_context.set_session_id("visitor-B-0123456789abcdefghijklmnopqrstuvwxyz")
    try:
        second_root = workspace_tools.workspace_root()
        assert first_root != second_root
        assert not (second_root / "privado.txt").exists()
        assert workspace_tools.list_workspace() == []
    finally:
        session_context.reset_session_id(token)


def test_public_agent_refuses_host_network_tools(monkeypatch):
    from types import SimpleNamespace
    from app import agent
    monkeypatch.setattr(agent, "settings", SimpleNamespace(public_mode=True))
    monkeypatch.setattr(agent, "add_message", lambda *args: None)
    def forbidden():
        raise AssertionError("public mode must not inspect the host network")
    monkeypatch.setattr(agent, "get_network_context", forbidden)
    monkeypatch.setattr(agent, "scan_local_network", forbidden)
    reply, mode, payload = agent.process_user_message("Jarvis, escaneie minha rede e mostre quem está conectado")
    assert mode == "local"
    assert payload is None
    assert "instalação privada" in reply


def test_public_local_command_does_not_open_host_browser(monkeypatch):
    from types import SimpleNamespace
    from app import agent
    monkeypatch.setattr(agent, "settings", SimpleNamespace(public_mode=True))
    monkeypatch.setattr(agent, "add_message", lambda *args: None)
    monkeypatch.setattr(agent, "ask_ai", lambda *args, **kwargs: ("resposta", {}))
    def forbidden(_text):
        raise AssertionError("public mode must not open host applications")
    monkeypatch.setattr(agent, "handle_local_command", forbidden)
    reply, mode, _ = agent.process_user_message("Jarvis, abra o YouTube")
    assert mode == "ai"
    assert reply == "resposta"


def test_public_browser_sessions_are_isolated_and_cookie_is_http_only(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from fastapi.testclient import TestClient
    from app import database, main, workspace_tools

    public_settings = SimpleNamespace(
        public_mode=True, rate_limit_per_minute=60, data_retention_days=90,
        database_path=tmp_path / "public.db", workspace_dir=tmp_path / "workspaces",
        public_url="https://jarvis.example", google_site_verification="",
        privacy_contact_email="", legal_name="", legal_cnpj="", legal_address="",
        dpo_contact="", ga_measurement_id="", meta_pixel_id="", api_token="",
    )
    monkeypatch.setattr(main, "settings", public_settings)
    monkeypatch.setattr(database, "settings", public_settings)
    monkeypatch.setattr(workspace_tools, "settings", public_settings)
    database.init_db()

    first = TestClient(main.app, base_url="https://jarvis.example")
    second = TestClient(main.app, base_url="https://jarvis.example")
    first_cookie = first.get("/healthz")
    assert "jarvis_session=" in first_cookie.headers["set-cookie"]
    assert "httponly" in first_cookie.headers["set-cookie"].lower()
    assert "secure" in first_cookie.headers["set-cookie"].lower()

    headers = {"Origin": "https://jarvis.example", "Sec-Fetch-Site": "same-origin"}
    created = first.post("/api/memories", json={"content": "Memória privada do visitante A"}, headers=headers)
    assert created.status_code == 200
    same_origin = {"Sec-Fetch-Site": "same-origin"}
    assert "Memória privada" in str(first.get("/api/memories", headers=same_origin).json())
    assert second.get("/api/memories", headers=same_origin).json()["memories"] == []

    # The public service must not allow a visitor to inspect the host's LAN.
    blocked = first.get("/api/network/overview", headers=same_origin)
    assert blocked.status_code == 403

    public_config = first.get("/api/public-config").json()
    assert "openai_api_key" not in public_config
    assert "gemini_api_key" not in public_config


def test_expired_public_session_data_is_purged(tmp_path, monkeypatch):
    from datetime import datetime, timedelta, timezone
    from types import SimpleNamespace
    from app import database
    from app.session_context import reset_session_id, set_session_id

    monkeypatch.setattr(database, "settings", SimpleNamespace(database_path=tmp_path / "retention.db"))
    database.init_db()
    token = set_session_id("retention-test-session")
    try:
        database.touch_session("retention-test-session")
        database.add_message("user", "mensagem expirada")
        database.save_memory("memória expirada")
        stale = (datetime.now(timezone.utc) - timedelta(days=100)).isoformat()
        with database._connect() as conn:
            conn.execute("UPDATE sessions SET last_seen = ? WHERE session_id = ?", (stale, "retention-test-session"))
        assert database.purge_expired_sessions(90) == ["retention-test-session"]
        assert database.recent_messages() == []
        assert database.list_memories() == []
    finally:
        reset_session_id(token)
