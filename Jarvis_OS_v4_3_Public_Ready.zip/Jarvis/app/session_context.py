"""Per-browser anonymous session context for a shared JARVIS deployment."""
from __future__ import annotations

from contextvars import ContextVar, Token
from pathlib import Path
import hashlib

_session_id: ContextVar[str] = ContextVar("jarvis_session_id", default="local-default")


def current_session_id() -> str:
    return _session_id.get()


def set_session_id(session_id: str) -> Token[str]:
    return _session_id.set(session_id)


def reset_session_id(token: Token[str]) -> None:
    _session_id.reset(token)


def workspace_dir_for_session(base_dir: Path, session_id: str) -> Path:
    """Build a deterministic, traversal-safe workspace path for a session."""
    digest = hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:32]
    base = (base_dir / "sessions").resolve()
    root = (base / digest).resolve()
    root.relative_to(base)
    return root


def session_workspace_dir(base_dir: Path) -> Path:
    """Return a private workspace path without putting the raw cookie in a path."""
    root = workspace_dir_for_session(base_dir, current_session_id())
    root.mkdir(parents=True, exist_ok=True)
    return root
