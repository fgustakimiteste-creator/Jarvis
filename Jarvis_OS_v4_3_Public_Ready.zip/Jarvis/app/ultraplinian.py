from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from .assistant import ask_provider, configured_providers
from .autotune import classify_context
from .database import recent_messages


def _words(text: str) -> list[str]:
    return re.findall(r"[\wÀ-ÿ]{3,}", text.lower())


def score_candidate(prompt: str, answer: str) -> dict[str, Any]:
    """A transparent low-cost heuristic, not a factuality or truth detector."""
    words = _words(answer)
    unique = set(words)
    prompt_words = set(_words(prompt))
    overlap = len(prompt_words & unique) / max(1, len(prompt_words))
    diversity = len(unique) / max(1, len(words))
    structure = min(1.0, (answer.count("\n") + answer.count("•") + answer.count("1.")) / 5)
    useful_length = min(1.0, len(words) / 180)
    repetition = 1.0 - diversity
    score = round(35 * overlap + 25 * diversity + 20 * useful_length + 20 * structure - 10 * repetition, 1)
    score = max(0.0, min(100.0, score))
    return {"score": score, "word_count": len(words), "coverage": round(overlap, 3), "diversity": round(diversity, 3)}


def compare_providers(prompt: str, providers: list[str] | None = None) -> dict[str, Any]:
    available = configured_providers()
    selected = [p for p in (providers or available) if p in available]
    # Keep API usage and RAM bounded: max three configured providers, two concurrent requests.
    selected = list(dict.fromkeys(selected))[:3]
    if not selected:
        raise RuntimeError("Configure pelo menos um provedor para executar o ULTRAPLINIAN.")
    profile = classify_context(prompt, recent_messages(8))
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(2, len(selected))) as pool:
        futures = {pool.submit(ask_provider, provider, prompt, "", profile): provider for provider in selected}
        for future in as_completed(futures):
            provider = futures[future]
            try:
                answer = future.result()
                results.append({"provider": provider, "answer": answer, **score_candidate(prompt, answer), "ok": True})
            except Exception as exc:
                results.append({"provider": provider, "answer": "", "score": 0, "ok": False, "error": type(exc).__name__})
    successful = [item for item in results if item["ok"]]
    if not successful:
        raise RuntimeError("Nenhum provedor conseguiu responder no ULTRAPLINIAN.")
    winner = max(successful, key=lambda item: item["score"])
    return {
        "winner": winner["provider"],
        "reply": winner["answer"],
        "results": sorted(results, key=lambda item: item["score"], reverse=True),
        "scoring_note": "Pontuação heurística de cobertura, diversidade, estrutura e tamanho. Não comprova verdade factual.",
        "autotune": {"context": profile.context, "confidence": profile.confidence},
    }
