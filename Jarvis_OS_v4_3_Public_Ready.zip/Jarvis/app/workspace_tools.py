from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import replace
from pathlib import Path, PurePosixPath
from typing import Any

from .config import settings
from .session_context import session_workspace_dir


def _slug(value: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9_-]+", "-", str(value).strip()).strip("-_").lower()
    if not text or text in {".", ".."}:
        raise ValueError("Nome de projeto inválido.")
    return text[:60]


def workspace_root() -> Path:
    root = session_workspace_dir(settings.workspace_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def list_workspace() -> list[dict[str, Any]]:
    root = workspace_root()
    result = []
    for path in sorted(root.iterdir(), key=lambda item: item.stat().st_mtime, reverse=True)[:100]:
        result.append({"name": path.name, "type": "folder" if path.is_dir() else "file", "size": path.stat().st_size if path.is_file() else None})
    return result


def write_text_file(name: str, content: str, *, overwrite: bool = False) -> dict[str, Any]:
    clean_name = Path(name).name
    if clean_name != name or clean_name in {"", ".", ".."} or len(clean_name) > 120:
        raise ValueError("Use apenas um nome de arquivo, sem caminhos ou diretórios.")
    if Path(clean_name).suffix.lower() not in {".txt", ".md", ".html", ".css", ".js", ".py", ".json", ".csv", ".xml", ".kt", ".kts", ".gradle", ".yml", ".yaml"}:
        raise ValueError("Extensão não permitida para escrita direta.")
    text = str(content)
    if len(text) > 500_000:
        raise ValueError("O arquivo excede 500 KB.")
    path = workspace_root() / clean_name
    if path.exists() and not overwrite:
        raise ValueError("O arquivo já existe. Confirme explicitamente a substituição para não perder conteúdo.")
    path.write_text(text, encoding="utf-8")
    return {"ok": True, "name": clean_name, "size": path.stat().st_size, "url": f"/workspace/{clean_name}"}


def create_document(filename: str, title: str, text: str) -> dict[str, Any]:
    root = workspace_root()
    stem = _slug(Path(filename).stem or "documento")
    try:
        from docx import Document
    except ImportError as exc:
        raise RuntimeError("Instale python-docx para criar documentos Word.") from exc
    doc = Document()
    if title.strip():
        doc.add_heading(title.strip()[:180], level=0)
    for paragraph in str(text).splitlines():
        clean = paragraph.strip()
        if clean.startswith("### "):
            doc.add_heading(clean[4:], level=3)
        elif clean.startswith("## "):
            doc.add_heading(clean[3:], level=2)
        elif clean.startswith("# "):
            doc.add_heading(clean[2:], level=1)
        elif clean.startswith("- "):
            doc.add_paragraph(clean[2:], style="List Bullet")
        elif clean:
            doc.add_paragraph(clean)
    path = root / f"{stem}.docx"
    if path.exists():
        raise ValueError("O documento já existe; renomeie a saída para preservar o arquivo anterior.")
    doc.save(path)
    return {"ok": True, "name": path.name, "size": path.stat().st_size, "url": f"/workspace/{path.name}"}


def create_presentation(filename: str, title: str, slides: list[dict[str, Any]]) -> dict[str, Any]:
    root = workspace_root()
    stem = _slug(Path(filename).stem or "apresentacao")
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt
    except ImportError as exc:
        raise RuntimeError("Instale python-pptx para criar apresentações PowerPoint.") from exc
    if not isinstance(slides, list) or not 1 <= len(slides) <= 40:
        raise ValueError("A apresentação precisa ter entre 1 e 40 slides.")
    prs = Presentation()
    cover = prs.slides.add_slide(prs.slide_layouts[0])
    cover.shapes.title.text = title[:180]
    cover.placeholders[1].text = "Criado pelo JARVIS OS"
    for item in slides:
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = str(item.get("title", "Slide"))[:180]
        body = slide.placeholders[1].text_frame
        body.clear()
        bullets = item.get("bullets") or []
        if isinstance(bullets, str):
            bullets = [line.strip("- • ") for line in bullets.splitlines() if line.strip()]
        for index, bullet in enumerate(bullets[:12]):
            paragraph = body.paragraphs[0] if index == 0 else body.add_paragraph()
            paragraph.text = str(bullet)[:500]
            paragraph.level = 0
            paragraph.font.size = Pt(20)
    path = root / f"{stem}.pptx"
    if path.exists():
        raise ValueError("A apresentação já existe; renomeie a saída para preservar o arquivo anterior.")
    prs.save(path)
    return {"ok": True, "name": path.name, "size": path.stat().st_size, "url": f"/workspace/{path.name}"}


def create_document_with_ai(filename: str, title: str, prompt: str, provider: str = "auto") -> dict[str, Any]:
    clean = " ".join(str(prompt or "").split())
    if len(clean) < 10 or len(clean) > 5000:
        raise ValueError("Descreva o documento em 10 a 5000 caracteres.")
    from .assistant import ask_provider_with_name
    from .autotune import classify_context
    from .database import recent_messages
    profile = replace(classify_context("Elabore um documento estruturado: " + clean, recent_messages(4)),
                      max_output_tokens=6500, reasoning_effort="high", temperature=0.25)
    request = (
        "Escreva o conteúdo integral de um documento em português brasileiro, com título, introdução, "
        "seções bem desenvolvidas, conclusão e referências quando forem necessárias. Use Markdown simples: "
        "# para título, ## para seções e - para listas. Não invente fontes ou dados. Se o tema exigir informação atual, "
        "declare que precisa de pesquisa. Entregue apenas o texto do documento.\n\n" + clean
    )
    text, used_provider = ask_provider_with_name(provider, request, profile=profile)
    if not text.strip():
        raise RuntimeError("A IA não retornou o conteúdo do documento.")
    result = create_document(filename, title, text)
    return {**result, "provider": used_provider, "words": len(text.split()), "generated_by_ai": True}


def create_presentation_with_ai(filename: str, title: str, prompt: str, provider: str = "auto") -> dict[str, Any]:
    clean = " ".join(str(prompt or "").split())
    if len(clean) < 10 or len(clean) > 5000:
        raise ValueError("Descreva a apresentação em 10 a 5000 caracteres.")
    from .assistant import ask_provider_with_name
    from .autotune import classify_context
    from .database import recent_messages
    profile = replace(classify_context("Crie uma apresentação de slides: " + clean, recent_messages(4)),
                      max_output_tokens=7000, reasoning_effort="high", temperature=0.3)
    request = (
        "Crie uma apresentação clara em português brasileiro, entre 5 e 12 slides. Responda SOMENTE JSON válido: "
        "{\"title\":\"...\",\"slides\":[{\"title\":\"...\",\"bullets\":[\"...\"]}]}. "
        "Cada slide deve ter 2 a 5 tópicos curtos, sem parágrafos longos. Inclua uma sequência lógica, "
        "exemplos concretos e conclusão. Não invente dados ou referências.\n\n" + clean
    )
    answer, used_provider = ask_provider_with_name(provider, request, profile=profile)
    raw = str(answer).strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError("A IA não retornou slides em JSON válido; nenhum arquivo foi criado.") from exc
    slides = data.get("slides") if isinstance(data, dict) else None
    if not isinstance(slides, list) or not 4 <= len(slides) <= 12:
        raise RuntimeError("A apresentação gerada precisa ter entre 4 e 12 slides; nenhum arquivo foi criado.")
    if any(not isinstance(item, dict) or not isinstance(item.get("title"), str) or not isinstance(item.get("bullets"), list) for item in slides):
        raise RuntimeError("Estrutura de slide inválida; nenhum arquivo foi criado.")
    result = create_presentation(filename, str(data.get("title") or title), slides)
    return {**result, "provider": used_provider, "slides": len(slides), "generated_by_ai": True}


def create_project(name: str, project_type: str) -> dict[str, Any]:
    root = workspace_root()
    folder = root / _slug(name)
    templates: dict[str, dict[str, str]] = {
        "web": {
            "index.html": "<!doctype html>\n<html lang='pt-BR'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Projeto JARVIS</title><link rel='stylesheet' href='style.css'><main><h1>Meu projeto</h1><p>Comece a construir aqui.</p></main><script src='app.js'></script></html>\n",
            "style.css": "*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#0b1220;color:#eef5ff;font:16px system-ui;display:grid;place-items:center}main{width:min(760px,92vw);padding:32px;border:1px solid #29384d;border-radius:18px;background:#111b2c}h1{color:#8ee7ed}\n",
            "app.js": "document.addEventListener('DOMContentLoaded',()=>console.info('Projeto pronto.'));\n",
            "README.md": "# Projeto Web\n\nAbra `index.html` em um navegador ou use um servidor estático local.\n",
        },
        "python": {
            "main.py": "def main() -> None:\n    print('Projeto criado pelo JARVIS OS')\n\nif __name__ == '__main__':\n    main()\n",
            "requirements.txt": "# Adicione apenas as dependências necessárias.\n",
            "README.md": "# Projeto Python\n\nExecute com `python main.py`. Revise o código antes de executar.\n",
        },
        "pygame": {
            "main.py": "import pygame\n\npygame.init()\nscreen = pygame.display.set_mode((960, 540))\npygame.display.set_caption('JARVIS Game')\nclock = pygame.time.Clock()\nrunning = True\nwhile running:\n    for event in pygame.event.get():\n        if event.type == pygame.QUIT:\n            running = False\n    screen.fill((10, 16, 28))\n    pygame.display.flip()\n    clock.tick(60)\npygame.quit()\n",
            "requirements.txt": "pygame>=2.5\n",
            "README.md": "# Jogo Python\n\nInstale com `pip install -r requirements.txt` e execute `python main.py`.\n",
        },
        "godot": {
            "project.godot": "config_version=5\n\n[application]\nconfig/name=\"JARVIS Godot Game\"\nrun/main_scene=\"res://Main.tscn\"\n\n[display]\nwindow/size/viewport_width=1280\nwindow/size/viewport_height=720\nwindow/stretch/mode=\"canvas_items\"\n\n[rendering]\nrenderer/rendering_method=\"gl_compatibility\"\nrenderer/rendering_method.mobile=\"gl_compatibility\"\n",
            "Main.tscn": "[gd_scene load_steps=2 format=3]\n\n[ext_resource type=\"Script\" path=\"res://scripts/main.gd\" id=\"1_main\"]\n\n[node name=\"Main\" type=\"Node2D\"]\nscript = ExtResource(\"1_main\")\n",
            "scripts/main.gd": "extends Node2D\n\nfunc _ready() -> void:\n    print(\"JARVIS Godot project initialized\")\n",
            "README.md": "# JARVIS Godot Game\n\nProjeto inicial para Godot 4.x. Abra a pasta `godot-game` no Godot. Para um jogo 3D exigente, configure o renderer Forward+ e ajuste os assets conforme o alvo de hardware.\n",
        },
    }
    files = templates.get(project_type)
    if not files:
        raise ValueError("Tipos disponíveis: web, python, pygame e godot. Android tem um gerador próprio.")
    if folder.exists():
        raise ValueError("Já existe um projeto com esse nome. Escolha outro nome para não sobrescrever arquivos.")
    folder.mkdir(parents=True, exist_ok=False)
    try:
        for filename, content in files.items():
            target = folder / filename
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    return {"ok": True, "project": folder.name, "path": str(folder), "files": list(files)}



_PROJECT_EXTENSIONS = {
    "web": {".html", ".css", ".js", ".json", ".md", ".txt", ".svg"},
    "python": {".py", ".toml", ".txt", ".md", ".json", ".yml", ".yaml"},
    "pygame": {".py", ".toml", ".txt", ".md", ".json", ".yml", ".yaml"},
    "godot": {".gd", ".tscn", ".tres", ".godot", ".cfg", ".json", ".md", ".txt"},
    "android": {".kt", ".kts", ".gradle", ".xml", ".properties", ".md", ".txt", ".json"},
}


def _parse_project_json(answer: str) -> dict[str, Any]:
    raw = str(answer or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        start, end = raw.find("{"), raw.rfind("}")
        if start < 0 or end <= start:
            raise RuntimeError("A IA não retornou um projeto em JSON válido. Tente novamente com uma descrição mais específica.")
        try:
            data = json.loads(raw[start:end + 1])
        except json.JSONDecodeError as exc:
            raise RuntimeError("A estrutura gerada pela IA não é JSON válido; nenhum arquivo foi criado.") from exc
    if not isinstance(data, dict) or not isinstance(data.get("files"), dict):
        raise RuntimeError("A resposta da IA precisa conter um objeto 'files'. Nenhum arquivo foi criado.")
    return data


def create_project_with_ai(name: str, project_type: str, prompt: str, provider: str = "auto") -> dict[str, Any]:
    """Generate a small, reviewable source project without executing generated code."""
    clean_prompt = " ".join(str(prompt or "").split())
    if not clean_prompt or len(clean_prompt) > 5000:
        raise ValueError("Descreva o aplicativo ou jogo em até 5000 caracteres.")
    if project_type not in _PROJECT_EXTENSIONS:
        raise ValueError("Tipo de projeto inválido.")

    from .assistant import ask_provider_with_name
    from .autotune import classify_context
    from .database import recent_messages

    profile = replace(classify_context("Implemente um projeto de software: " + clean_prompt, recent_messages(4)),
                      max_output_tokens=12000, reasoning_effort="high", temperature=0.15)
    type_guidance = {
        "web": "Crie um projeto web estático HTML/CSS/JavaScript que funcione sem build obrigatório.",
        "python": "Crie um projeto Python organizado, com main.py e requirements.txt apenas se houver dependências.",
        "pygame": "Crie um jogo Python Pygame completo, com loop de jogo, controles, estados e encerramento limpo.",
        "godot": "Crie um projeto Godot 4.x com GDScript, cenas .tscn e configuração project.godot; prefira arquitetura eficiente e recursos nativos.",
        "android": "Crie um app Android nativo Kotlin com Gradle Kotlin DSL, Manifest e Activity funcional.",
    }[project_type]
    instruction = (
        "Gere um projeto pequeno, completo e executável. Responda SOMENTE JSON válido, sem Markdown. "
        "Formato exato: {\"summary\":\"...\",\"files\":{\"caminho/arquivo.ext\":\"conteúdo integral do arquivo\"}}. "
        "Não use placeholders, reticências ou arquivos binários/base64. Inclua README.md com instalação, uso e limitações. "
        "Inclua comentários úteis, tratamento de erros, validação de entrada e interface responsiva quando houver UI. "
        "Não inclua segredos, .env, scripts de shell/PowerShell/batch, executáveis ou comandos pós-instalação. "
        "Não dependa de serviços pagos sem documentar claramente a configuração. Mantenha o projeto enxuto e evite dependências desnecessárias. "
        f"TIPO: {project_type}. {type_guidance}\nREQUISITOS DO USUÁRIO: {clean_prompt}"
    )
    answer, used_provider = ask_provider_with_name(provider, instruction, profile=profile)
    data = _parse_project_json(answer)
    raw_files = data["files"]
    if not 1 <= len(raw_files) <= 40:
        raise RuntimeError("A IA deve gerar entre 1 e 40 arquivos; nenhum arquivo foi criado.")

    validated: dict[str, str] = {}
    total_bytes = 0
    for raw_name, raw_content in raw_files.items():
        if not isinstance(raw_name, str) or not isinstance(raw_content, str):
            raise RuntimeError("Cada arquivo precisa ter caminho e conteúdo em texto.")
        name_path = PurePosixPath(raw_name)
        if (name_path.is_absolute() or not name_path.parts or any(part in {"", ".", ".."} for part in name_path.parts)
                or "\\" in raw_name or ":" in raw_name or len(raw_name) > 180):
            raise RuntimeError(f"Caminho de arquivo inválido: {raw_name[:80]}")
        if raw_name.lower() in {".env", ".env.local", "local.properties", "gradlew", "gradlew.bat"}:
            raise RuntimeError(f"Arquivo sensível ou de execução não permitido: {raw_name}")
        suffix = Path(raw_name).suffix.lower()
        if raw_name not in {".gitignore", ".editorconfig"} and suffix not in _PROJECT_EXTENSIONS[project_type]:
            raise RuntimeError(f"Extensão não permitida para projeto {project_type}: {raw_name}")
        if len(raw_content.encode("utf-8")) > 180_000:
            raise RuntimeError(f"Arquivo muito grande: {raw_name}")
        total_bytes += len(raw_content.encode("utf-8"))
        validated[raw_name] = raw_content
    if total_bytes > 1_200_000:
        raise RuntimeError("Projeto excede o limite de 1,2 MB de código-fonte.")

    required = {"web": {"index.html"}, "python": {"main.py"}, "pygame": {"main.py"},
                "godot": {"project.godot", "Main.tscn"},
                "android": {"settings.gradle.kts", "build.gradle.kts", "app/build.gradle.kts",
                            "app/src/main/AndroidManifest.xml"}}[project_type]
    has_android_activity = any(path.endswith(".kt") and "/src/main/" in path for path in validated)
    if not required.issubset(validated) or (project_type == "android" and not has_android_activity):
        raise RuntimeError("A IA não incluiu todos os arquivos de entrada obrigatórios. Nenhum arquivo foi criado.")

    root = workspace_root()
    folder = root / _slug(name)
    if folder.exists():
        raise ValueError("Já existe um projeto com esse nome. Escolha outro nome para não sobrescrever arquivos.")
    folder.mkdir(parents=True, exist_ok=False)
    try:
        for relative_name, content in validated.items():
            target = folder.joinpath(*PurePosixPath(relative_name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8", newline="\n")
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise

    check = run_project_check(folder.name)
    return {"ok": True, "project": folder.name, "path": str(folder), "files": list(validated),
            "summary": str(data.get("summary", "Projeto gerado pela IA."))[:1200],
            "provider": used_provider, "check": check, "executed": False,
            "notice": "Os arquivos foram criados e verificados estaticamente; nenhum código gerado foi executado."}

def run_project_check(project_name: str) -> dict[str, Any]:
    root = workspace_root()
    folder = (root / _slug(project_name)).resolve()
    if folder.parent != root or not folder.is_dir():
        raise ValueError("Projeto não encontrado no workspace.")
    checked = 0
    errors: list[str] = []
    py_files = list(folder.rglob("*.py"))[:80]
    if py_files:
        import sys
        for source in py_files:
            result = subprocess.run([sys.executable, "-m", "py_compile", str(source)], cwd=folder, capture_output=True, text=True, timeout=30)
            checked += 1
            if result.returncode != 0:
                errors.append(f"{source.relative_to(folder)}: {result.stderr[-1000:]}")
    js_files = list(folder.rglob("*.js"))[:80]
    node = shutil.which("node")
    if js_files and node:
        for source in js_files:
            result = subprocess.run([node, "--check", str(source)], cwd=folder, capture_output=True, text=True, timeout=30)
            checked += 1
            if result.returncode != 0:
                errors.append(f"{source.relative_to(folder)}: {result.stderr[-1000:]}")
    elif js_files and not node:
        errors.append("Node.js não está instalado; a sintaxe JavaScript não foi verificada.")
    if (folder / "index.html").exists():
        checked += 1
    if (folder / "settings.gradle.kts").exists():
        checked += 1
    if (folder / "project.godot").exists() and (folder / "Main.tscn").exists():
        checked += 2
    if checked == 0:
        return {"ok": False, "checked": 0, "message": "Não há verificações estáticas disponíveis para este tipo de projeto."}
    return {"ok": not errors, "checked": checked,
            "message": "Verificações estáticas concluídas; nenhum código foi executado.",
            "stderr": "\n".join(errors)[:4000]}


def create_android_project(name: str) -> dict[str, Any]:
    root = workspace_root()
    folder = root / _slug(name)
    if folder.exists():
        raise ValueError("Já existe um projeto com esse nome. Escolha outro nome para não sobrescrever arquivos.")
    folder.mkdir(parents=True, exist_ok=False)
    files = {
        "settings.gradle.kts": '''pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name = "JarvisAndroidApp"\ninclude(":app")\n''',
        "build.gradle.kts": '''plugins { id("com.android.application") version "8.7.3" apply false; id("org.jetbrains.kotlin.android") version "2.0.21" apply false }\n''',
        "gradle.properties": "org.gradle.jvmargs=-Xmx1536m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nkotlin.code.style=official\n",
        "app/build.gradle.kts": '''plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }\n\nandroid { namespace = "com.jarvis.generated"; compileSdk = 35; defaultConfig { applicationId = "com.jarvis.generated"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" } }\n''',
        "app/src/main/AndroidManifest.xml": '''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:theme="@android:style/Theme.Material.Light.NoActionBar" android:label="JARVIS App"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>\n''',
        "app/src/main/java/com/jarvis/generated/MainActivity.kt": '''package com.jarvis.generated\n\nimport android.app.Activity\nimport android.os.Bundle\nimport android.graphics.Color\nimport android.view.Gravity\nimport android.widget.TextView\nimport android.widget.LinearLayout\n\nclass MainActivity : Activity() {\n  override fun onCreate(savedInstanceState: Bundle?) {\n    super.onCreate(savedInstanceState)\n    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32, 32, 32, 32); setBackgroundColor(Color.rgb(10, 16, 28)) }\n    val title = TextView(this).apply { text = "Meu aplicativo"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }\n    val subtitle = TextView(this).apply { text = "Projeto inicial criado pelo JARVIS OS"; textSize = 16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 18, 0, 0) }\n    root.addView(title); root.addView(subtitle); setContentView(root)\n  }\n}\n''',
        "README.md": "# Aplicativo Android Kotlin\n\nRequisitos: JDK 17, Gradle 8.9 ou compatível, Android SDK 35.\n\nPara gerar o APK de debug, execute no PC: `gradle assembleDebug`. O JARVIS também oferece um botão de compilação; a compilação só funciona quando o SDK e o Gradle estão instalados.\n",
    }
    for filename, content in files.items():
        path = folder / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    return {"ok": True, "project": folder.name, "path": str(folder), "files": list(files), "build_ready": bool(shutil.which("gradle") and ("ANDROID_HOME" in __import__('os').environ or "ANDROID_SDK_ROOT" in __import__('os').environ))}


def build_android_project(project_name: str, *, confirmed: bool = False) -> dict[str, Any]:
    if not confirmed:
        raise PermissionError("A compilação executa scripts Gradle do projeto. Confirme explicitamente antes de continuar.")
    root = workspace_root()
    folder = (root / _slug(project_name)).resolve()
    if folder.parent != root or not (folder / "settings.gradle.kts").is_file():
        raise ValueError("Projeto Android não encontrado no workspace.")
    gradle = shutil.which("gradle")
    if not gradle:
        raise RuntimeError("Gradle não está instalado no computador servidor.")
    if not (__import__('os').environ.get("ANDROID_HOME") or __import__('os').environ.get("ANDROID_SDK_ROOT")):
        raise RuntimeError("Android SDK não configurado. Defina ANDROID_HOME ou ANDROID_SDK_ROOT.")
    result = subprocess.run([gradle, "assembleDebug", "--no-daemon", "--stacktrace"], cwd=folder, capture_output=True, text=True, timeout=900)
    apk = folder / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk"
    if result.returncode != 0 or not apk.is_file():
        raise RuntimeError("Compilação Android falhou. Veja o log resumido: " + (result.stderr or result.stdout)[-4000:])
    target = root / f"{folder.name}-debug.apk"
    suffix = 2
    while target.exists():
        target = root / f"{folder.name}-debug-{suffix}.apk"
        suffix += 1
    shutil.copy2(apk, target)
    return {"ok": True, "name": target.name, "size": target.stat().st_size, "url": f"/workspace/{target.name}", "log": result.stdout[-1500:]}
