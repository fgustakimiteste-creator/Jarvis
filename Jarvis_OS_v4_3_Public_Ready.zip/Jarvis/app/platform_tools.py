from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import sys
import webbrowser
from urllib.parse import quote_plus, urlparse


SITE_SHORTCUTS = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "gmail": "https://mail.google.com",
    "github": "https://github.com",
    "instagram": "https://www.instagram.com",
    "whatsapp": "https://web.whatsapp.com",
    "spotify": "https://open.spotify.com",
    "chatgpt": "https://chatgpt.com",
}

APP_SHORTCUTS = {
    "calculadora": {
        "windows": [["calc.exe"]],
        "darwin": [["open", "-a", "Calculator"]],
        "linux": [["gnome-calculator"], ["kcalc"], ["xcalc"]],
    },
    "bloco de notas": {
        "windows": [["notepad.exe"]],
        "darwin": [["open", "-a", "TextEdit"]],
        "linux": [["gedit"], ["mousepad"], ["leafpad"]],
    },
    "explorador de arquivos": {
        "windows": [["explorer.exe"]],
        "darwin": [["open", "."]],
        "linux": [["xdg-open", "."]],
    },
}


def is_termux() -> bool:
    return "com.termux" in os.environ.get("PREFIX", "") or "TERMUX_VERSION" in os.environ


def open_website(url: str) -> str:
    raw = url.strip()
    if not raw:
        raise ValueError("Informe um endereço de site.")
    scheme_match = re.match(r"^([a-z][a-z0-9+.-]*):", raw, flags=re.I)
    host_port_match = re.match(r"^[a-z0-9.-]+:\d+(?:/|$)", raw, flags=re.I)
    if scheme_match and not host_port_match and scheme_match.group(1).lower() not in {"http", "https"}:
        raise ValueError("Endereço não permitido. Use um endereço público HTTP ou HTTPS.")
    if not re.match(r"^https?://", raw, flags=re.I):
        raw = "https://" + raw
    parsed = urlparse(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Endereço não permitido. Use um endereço público HTTP ou HTTPS.")
    if is_termux():
        opener = shutil.which("termux-open-url")
        if opener:
            subprocess.Popen([opener, raw], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"Abri {parsed.hostname} no Android."
    opened = webbrowser.open(raw, new=2)
    if not opened:
        return f"Enviei o pedido para abrir {parsed.hostname}. Confira o navegador do dispositivo."
    return f"Abrindo {parsed.hostname}."


def search_web(query: str) -> str:
    clean = " ".join(query.split()).strip()
    if not clean:
        raise ValueError("Diga o que devo pesquisar.")
    return open_website("https://www.google.com/search?q=" + quote_plus(clean))


def open_application(name: str) -> str:
    key = " ".join(name.lower().strip().split())
    if is_termux():
        if key in {"navegador", "browser"}:
            return open_website("https://www.google.com")
        return "No Android/Termux, só posso abrir aplicativos Android específicos quando a integração estiver configurada. Posso abrir sites e usar recursos do Termux:API."

    system = "windows" if sys.platform.startswith("win") else "darwin" if sys.platform == "darwin" else "linux"
    options = APP_SHORTCUTS.get(key)
    if not options:
        return "Esse aplicativo não está na lista segura. Por enquanto, posso abrir calculadora, bloco de notas ou explorador de arquivos."
    candidates = options.get(system, [])
    for command in candidates:
        executable = command[0]
        if system == "windows" or executable == "open" or shutil.which(executable):
            try:
                subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return f"Solicitei a abertura de {key}."
            except OSError:
                continue
    return f"Não encontrei um aplicativo compatível para abrir {key} neste sistema."


def speak_on_termux(text: str) -> str:
    if not is_termux():
        return "A fala será reproduzida pelo navegador."
    command = shutil.which("termux-tts-speak")
    if not command:
        return "Instale o Termux:API e o pacote termux-api para ativar a fala nativa."
    subprocess.Popen([command, text[:500]], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return "Fala enviada ao Termux:API."


def system_status() -> str:
    system_name = platform.platform()
    python_version = platform.python_version()
    device = "Android via Termux" if is_termux() else platform.system()
    details = [f"Dispositivo: {device}", f"Sistema: {system_name}", f"Python: {python_version}"]
    try:
        import psutil  # Optional dependency
        memory = psutil.virtual_memory()
        details.append(f"Memória RAM: {memory.percent}% em uso")
        details.append(f"CPU: {psutil.cpu_percent(interval=0.15)}% em uso")
    except Exception:
        details.append("CPU/RAM: instale psutil para exibir métricas detalhadas")
    return "\n".join(details)


def handle_local_command(text: str) -> str | None:
    """Execute only explicit, allow-listed commands; never runs arbitrary shell text."""
    raw = text.strip()
    lower = raw.lower().strip()

    remember_match = re.match(r"^(?:jarvis,?\s*)?(?:lembre(?:-se)?|memorize|anote)\s+(?:que\s+)?(.+)$", lower, re.I)
    if remember_match:
        from .database import save_memory
        original_content = raw[remember_match.start(1):].strip()
        # Remove only the optional opening "que" from the original text.
        original_content = re.sub(r"^que\s+", "", original_content, flags=re.I)
        save_memory(original_content)
        return "Memória salva. Vou considerar essa informação nas próximas conversas."

    if re.search(r"\b(o que você lembra|que você lembra|minhas memórias|minha memória)\b", lower):
        from .database import list_memories
        items = list_memories(12)
        if not items:
            return "Ainda não tenho memórias salvas. Você pode dizer: 'Jarvis, lembre que ...'."
        return "Estas são as memórias salvas:\n" + "\n".join(f"• {item['content']}" for item in items)

    if re.search(r"\b(status do sistema|informações do sistema|informacoes do sistema)\b", lower):
        return system_status()

    search_match = re.match(r"^(?:jarvis,?\s*)?(?:pesquise|pesquisar|busque|procure)\s+(.+)$", raw, re.I)
    if search_match:
        return search_web(search_match.group(1))

    url_match = re.match(r"^(?:jarvis,?\s*)?(?:abra|abrir|abre|acesse|acessa)\s+(https?://\S+)$", raw, re.I)
    if url_match:
        return open_website(url_match.group(1))

    site_match = re.match(r"^(?:jarvis,?\s*)?(?:abra|abrir|abre|acesse|acessa)\s+(?:(?:o|a)\s+)?(youtube|google|gmail|github|instagram|whatsapp|spotify|chatgpt)$", lower, re.I)
    if site_match:
        site = site_match.group(1).lower()
        return open_website(SITE_SHORTCUTS[site])

    app_match = re.match(r"^(?:jarvis,?\s*)?(?:abra|abrir|abre|inicie|iniciar)\s+(calculadora|bloco de notas|explorador de arquivos)$", lower, re.I)
    if app_match:
        return open_application(app_match.group(1))

    if re.search(r"\b(que horas são|que horas sao|horário agora|horario agora)\b", lower):
        from datetime import datetime
        return "Agora são " + datetime.now().astimezone().strftime("%H:%M") + "."

    return None
