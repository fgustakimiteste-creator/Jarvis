from __future__ import annotations

import base64
import io
import platform
from typing import Any

from .config import settings


_KEY_MAP = {
    "enter": "enter", "esc": "esc", "escape": "esc", "tab": "tab", "space": "space",
    "backspace": "backspace", "delete": "delete", "home": "home", "end": "end",
    "up": "up", "down": "down", "left": "left", "right": "right",
    "pageup": "pageup", "pagedown": "pagedown", "f5": "f5", "ctrl+l": "ctrl+l",
    "ctrl+s": "ctrl+s", "ctrl+a": "ctrl+a", "ctrl+c": "ctrl+c", "ctrl+v": "ctrl+v",
    "ctrl+w": "ctrl+w", "ctrl+t": "ctrl+t", "alt+tab": "alt+tab",
}


def _pyautogui():
    try:
        import pyautogui
    except Exception as exc:
        raise RuntimeError("Controle da tela indisponível. Instale PyAutoGUI e Pillow no computador servidor; em Linux, configure uma sessão gráfica.") from exc
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.08
    return pyautogui


def desktop_status() -> dict[str, Any]:
    try:
        import pyautogui  # noqa: F401
        installed = True
        detail = "PyAutoGUI instalado"
    except Exception as exc:
        installed = False
        detail = type(exc).__name__
    return {
        "enabled": bool(settings.desktop_control_enabled),
        "available": bool(settings.desktop_control_enabled and installed),
        "pyautogui_installed": installed,
        "platform": platform.system(),
        "detail": detail,
        "fail_safe": True,
        "note": "O controle da área de trabalho só funciona no PC que hospeda o JARVIS. Mova o mouse para o canto superior esquerdo para acionar o fail-safe do PyAutoGUI.",
    }


def screenshot_data_url() -> tuple[str, int, int]:
    if not settings.desktop_control_enabled:
        raise RuntimeError("Ative JARVIS_DESKTOP_CONTROL=true no .env e reinicie o JARVIS.")
    pg = _pyautogui()
    image = pg.screenshot()
    buffer = io.BytesIO()
    image.save(buffer, format="PNG", optimize=True)
    width, height = image.size
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return "data:image/png;base64," + encoded, width, height


def _coordinates(x: Any, y: Any) -> tuple[int, int]:
    pg = _pyautogui()
    try:
        px, py = int(x), int(y)
    except (TypeError, ValueError) as exc:
        raise ValueError("Informe coordenadas inteiras.") from exc
    width, height = pg.size()
    if not (0 <= px < width and 0 <= py < height):
        raise ValueError("Coordenadas fora dos limites da tela.")
    return px, py


def execute_action(action: dict[str, Any], *, confirmed: bool = False) -> dict[str, Any]:
    if not settings.desktop_control_enabled:
        raise RuntimeError("Controle de tela desativado. Ative JARVIS_DESKTOP_CONTROL=true no .env.")
    if not confirmed:
        raise PermissionError("A ação precisa ser confirmada pelo usuário na interface.")
    if not isinstance(action, dict):
        raise ValueError("Ação inválida.")
    pg = _pyautogui()
    kind = str(action.get("type", "")).lower()
    if kind == "click":
        x, y = _coordinates(action.get("x"), action.get("y"))
        pg.click(x, y, button="left")
    elif kind == "double_click":
        x, y = _coordinates(action.get("x"), action.get("y"))
        pg.doubleClick(x, y, button="left")
    elif kind == "move":
        x, y = _coordinates(action.get("x"), action.get("y"))
        pg.moveTo(x, y, duration=0.15)
    elif kind == "scroll":
        amount = max(-8, min(8, int(action.get("amount", 0))))
        pg.scroll(amount)
    elif kind == "type":
        value = str(action.get("text", ""))
        if not value or len(value) > 1500:
            raise ValueError("O texto deve conter entre 1 e 1500 caracteres.")
        try:
            import pyperclip
            pyperclip.copy(value)
            pg.hotkey("ctrl", "v")
        except ImportError:
            if not value.isascii():
                raise RuntimeError("Para digitar caracteres especiais, instale pyperclip junto ao PyAutoGUI.")
            pg.write(value, interval=0.01)
    elif kind == "keypress":
        key = str(action.get("key", "")).lower()
        if key not in _KEY_MAP:
            raise ValueError("Atalho não permitido nesta interface.")
        pg.hotkey(*_KEY_MAP[key].split("+")) if "+" in key else pg.press(_KEY_MAP[key])
    else:
        raise ValueError("Tipo de ação não reconhecido.")
    return {"ok": True, "action": kind, "message": "Ação enviada ao computador.", "screen": list(pg.size())}
