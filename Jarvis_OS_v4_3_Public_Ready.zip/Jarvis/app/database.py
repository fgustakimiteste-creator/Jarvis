from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings
from .session_context import current_session_id


def _connect() -> sqlite3.Connection:
    settings.database_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(settings.database_path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    with _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL DEFAULT 'legacy',
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL DEFAULT 'legacy',
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                last_seen TEXT NOT NULL
            );
            """
        )
        # Upgrade existing v4.2 databases in place without discarding old records.
        for table in ("messages", "memories"):
            columns = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            if "session_id" not in columns:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN session_id TEXT NOT NULL DEFAULT 'legacy'")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_messages_session_created ON messages(session_id, id DESC)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_session_created ON memories(session_id, id DESC)")


def add_message(role: str, content: str) -> None:
    if role not in {"user", "assistant"}:
        raise ValueError("Papel de mensagem inválido")
    with _connect() as conn:
        conn.execute(
            "INSERT INTO messages(session_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (current_session_id(), role, content[:12000], datetime.now(timezone.utc).isoformat()),
        )


def recent_messages(limit: int = 16) -> list[dict[str, str]]:
    limit = max(1, min(int(limit), 40))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT role, content, created_at FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?",
            (current_session_id(), limit),
        ).fetchall()
    return [dict(row) for row in reversed(rows)]


def save_memory(content: str) -> int:
    clean = " ".join(content.strip().split())
    if not clean:
        raise ValueError("A memória não pode ficar vazia")
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO memories(session_id, content, created_at) VALUES (?, ?, ?)",
            (current_session_id(), clean[:2000], datetime.now(timezone.utc).isoformat()),
        )
        return int(cursor.lastrowid)


def list_memories(limit: int = 30) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 100))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, content, created_at FROM memories WHERE session_id = ? ORDER BY id DESC LIMIT ?",
            (current_session_id(), limit),
        ).fetchall()
    return [dict(row) for row in rows]


def relevant_memories(query: str, limit: int = 6) -> list[str]:
    """Small, dependency-free memory retrieval using word overlap."""
    memories = list_memories(100)
    words = {w.lower() for w in query.split() if len(w) > 3}
    scored: list[tuple[int, int, str]] = []
    for item in memories:
        text = item["content"]
        content_words = {w.lower().strip(".,!?;:") for w in text.split() if len(w) > 3}
        score = len(words & content_words)
        if score:
            scored.append((score, item["id"], text))
    scored.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)
    if not scored:
        return [item["content"] for item in memories[: min(3, limit)]]
    return [entry[2] for entry in scored[:limit]]


def clear_conversation() -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM messages WHERE session_id = ?", (current_session_id(),))


def delete_memory(memory_id: int) -> bool:
    with _connect() as conn:
        cursor = conn.execute("DELETE FROM memories WHERE id = ? AND session_id = ?", (int(memory_id), current_session_id()))
        return cursor.rowcount > 0


def clear_memories() -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM memories WHERE session_id = ?", (current_session_id(),))


def touch_session(session_id: str) -> None:
    """Store only the opaque session ID and last-seen time for retention cleanup."""
    now = datetime.now(timezone.utc).isoformat()
    with _connect() as conn:
        conn.execute(
            "INSERT INTO sessions(session_id, last_seen) VALUES (?, ?) "
            "ON CONFLICT(session_id) DO UPDATE SET last_seen=excluded.last_seen "
            "WHERE julianday(excluded.last_seen) > julianday(sessions.last_seen) + (5.0 / 1440.0)",
            (session_id, now),
        )


def purge_expired_sessions(retention_days: int = 90) -> list[str]:
    """Delete messages and memories for inactive sessions beyond the retention window."""
    days = max(7, min(int(retention_days), 365))
    cutoff = (datetime.now(timezone.utc)).timestamp() - days * 86400
    with _connect() as conn:
        rows = conn.execute("SELECT session_id, last_seen FROM sessions").fetchall()
        expired = []
        for row in rows:
            try:
                last_seen = datetime.fromisoformat(row["last_seen"]).timestamp()
            except (TypeError, ValueError):
                last_seen = 0
            if last_seen < cutoff:
                expired.append(row["session_id"])
        if expired:
            marks = ",".join("?" for _ in expired)
            conn.execute(f"DELETE FROM messages WHERE session_id IN ({marks})", expired)
            conn.execute(f"DELETE FROM memories WHERE session_id IN ({marks})", expired)
            conn.execute(f"DELETE FROM sessions WHERE session_id IN ({marks})", expired)
        return expired
