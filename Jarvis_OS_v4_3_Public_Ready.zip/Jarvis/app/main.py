from __future__ import annotations

import hmac
import asyncio
import ipaddress
import logging
import re
import secrets
import shutil
import time
from collections import defaultdict, deque
from urllib.parse import urlparse
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, UploadFile, File, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .agent import process_user_message
from .assistant import configured_providers
from .desktop_tools import desktop_status, screenshot_data_url, execute_action
from .desktop_agent import run_computer_task, stop_desktop_task, desktop_task_status
from .media_tools import generate_image, transcribe_audio, generate_speech, create_video_from_images, analyze_desktop_image
from .ultraplinian import compare_providers
from .workspace_tools import (list_workspace, write_text_file, create_document, create_document_with_ai,
                              create_presentation, create_presentation_with_ai, create_project, create_project_with_ai,
                              create_android_project, run_project_check, build_android_project)
from .config import ROOT_DIR, settings
from .session_context import current_session_id, reset_session_id, set_session_id, session_workspace_dir, workspace_dir_for_session
from .database import add_message, clear_conversation, delete_memory, init_db, list_memories, recent_messages, save_memory, touch_session, purge_expired_sessions
from .network_tools import get_last_scan, get_network_context, scan_device_ports, scan_local_network
from .platform_tools import open_website
from .web_tools import read_public_page, search_public_web

logging.basicConfig(level=logging.INFO, format="%(asctime)s | JARVIS | %(levelname)s | %(message)s")
logger = logging.getLogger("jarvis")


def _purge_expired_workspace_data() -> int:
    expired_sessions = purge_expired_sessions(settings.data_retention_days)
    for expired_id in expired_sessions:
        stale_workspace = workspace_dir_for_session(settings.workspace_dir, expired_id)
        if stale_workspace.is_dir():
            shutil.rmtree(stale_workspace, ignore_errors=True)
    return len(expired_sessions)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    removed = _purge_expired_workspace_data()
    logger.info("Banco de dados inicializado em %s; sessões expiradas removidas: %s", settings.database_path, removed)

    async def retention_sweeper() -> None:
        while True:
            await asyncio.sleep(24 * 60 * 60)
            try:
                deleted = _purge_expired_workspace_data()
                logger.info("Limpeza diária de sessões concluída; sessões removidas: %s", deleted)
            except Exception as exc:
                logger.warning("Falha na limpeza diária de sessões: %s", type(exc).__name__)

    task = asyncio.create_task(retention_sweeper())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(
    title="JARVIS OS", version="4.3.0",
    docs_url=None if settings.public_mode else "/api/docs",
    redoc_url=None if settings.public_mode else "/api/redoc",
    openapi_url=None if settings.public_mode else "/api/openapi.json",
    lifespan=lifespan,
)
STATIC_DIR = ROOT_DIR / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
settings.workspace_dir.mkdir(parents=True, exist_ok=True)

_SESSION_COOKIE = "jarvis_session"
_SESSION_PATTERN = __import__("re").compile(r"^[A-Za-z0-9_-]{32,128}$")
_RATE_WINDOW_SECONDS = 60
_rate_events: dict[str, deque[float]] = defaultdict(deque)
_heavy_rate_events: dict[str, deque[float]] = defaultdict(deque)


@app.middleware("http")
async def session_security_middleware(request: Request, call_next):
    """Issue an opaque HttpOnly browser cookie and bind all server data to it."""
    supplied = request.cookies.get(_SESSION_COOKIE, "")
    session_id = supplied if _SESSION_PATTERN.fullmatch(supplied) else secrets.token_urlsafe(32)
    is_new = session_id != supplied
    request.state.session_id = session_id
    context_token = set_session_id(session_id)
    response = None
    try:
        if getattr(settings, "public_mode", False) and request.url.path.startswith("/api/"):
            touch_session(session_id)
        if getattr(settings, "public_mode", False) and request.url.path.startswith("/api/") and request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            now = time.monotonic()
            events = _rate_events[session_id]
            while events and now - events[0] > _RATE_WINDOW_SECONDS:
                events.popleft()
            heavy_path = (
                request.url.path.startswith("/api/media/")
                or request.url.path == "/api/chat/compare"
                or request.url.path.endswith("/generate")
                or request.url.path.endswith("/build-android")
            )
            heavy = _heavy_rate_events[session_id]
            while heavy and now - heavy[0] > _RATE_WINDOW_SECONDS:
                heavy.popleft()
            heavy_limit = max(2, int(__import__("os").getenv("JARVIS_HEAVY_RATE_LIMIT_PER_MINUTE", "8")))
            over_limit = len(events) >= settings.rate_limit_per_minute or (heavy_path and len(heavy) >= heavy_limit)
            if over_limit:
                from fastapi.responses import JSONResponse
                response = JSONResponse(
                    status_code=429,
                    content={"detail": "Limite temporário atingido nesta sessão. Aguarde um minuto e tente novamente."},
                    headers={"Retry-After": "60"},
                )
            else:
                events.append(now)
                if heavy_path:
                    heavy.append(now)
            if len(_rate_events) > 10000:
                stale = [key for key, queue in _rate_events.items() if not queue or now - queue[-1] > _RATE_WINDOW_SECONDS]
                for key in stale:
                    _rate_events.pop(key, None)
                    _heavy_rate_events.pop(key, None)
        if response is None:
            response = await call_next(request)
    finally:
        reset_session_id(context_token)

    forwarded_proto = request.headers.get("x-forwarded-proto", "").split(",", 1)[0].strip()
    secure = request.url.scheme == "https" or forwarded_proto == "https"
    if is_new:
        response.set_cookie(
            key=_SESSION_COOKIE, value=session_id, max_age=60 * 60 * 24 * 180,
            httponly=True, secure=secure, samesite="lax", path="/",
        )
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(self), geolocation=()")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self' https://www.googletagmanager.com https://connect.facebook.net; "
        "style-src 'self' 'unsafe-inline'; font-src 'self' data:; "
        "img-src 'self' data: blob: https:; media-src 'self' data: blob:; "
        "connect-src 'self' https://www.google-analytics.com https://region1.google-analytics.com https://www.facebook.com; "
        "object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    )
    if secure:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


def require_token(request: Request, x_jarvis_token: str | None = Header(default=None)) -> None:
    if getattr(settings, "public_mode", False):
        # No API token in the browser: the backend creates and validates an opaque,
        # HttpOnly session cookie. Reject cross-origin writes (basic CSRF defense).
        origin = request.headers.get("origin")
        if origin:
            origin_host = urlparse(origin).netloc.lower()
            request_host = request.headers.get("host", "").lower()
            if not origin_host or origin_host != request_host:
                raise HTTPException(status_code=403, detail="Origem da solicitação não permitida.")
        elif request.headers.get("sec-fetch-site", "").lower() not in {"same-origin", "same-site"}:
            raise HTTPException(status_code=403, detail="A origem da solicitação não pôde ser validada.")
        if request.headers.get("sec-fetch-site", "").lower() == "cross-site":
            raise HTTPException(status_code=403, detail="Solicitação entre sites bloqueada.")
        if not getattr(request.state, "session_id", None):
            raise HTTPException(status_code=401, detail="Sessão do JARVIS não inicializada. Recarregue a página.")
        return
    configured = settings.api_token
    if configured and not hmac.compare_digest(x_jarvis_token or "", configured):
        raise HTTPException(status_code=401, detail="Token do JARVIS ausente ou incorreto.")


def require_private_host_feature(feature_name: str) -> None:
    if getattr(settings, "public_mode", False):
        raise HTTPException(
            status_code=403,
            detail=f"{feature_name} está disponível apenas na instalação privada do JARVIS, não no servidor público compartilhado.",
        )


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    provider: str = Field(default="auto", pattern="^(auto|openai|gemini|local)$")


class CompareRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    providers: list[str] | None = None


class DesktopActionRequest(BaseModel):
    action: dict[str, Any]
    confirm: bool = False


class DesktopTaskRequest(BaseModel):
    task: str = Field(min_length=1, max_length=1200)
    confirm: bool = False


class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=2500)
    size: str = "1024x1024"


class SpeechRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)
    voice: str = "marin"


class FileWriteRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    content: str = Field(max_length=500000)
    overwrite: bool = False


class DocumentRequest(BaseModel):
    filename: str = Field(default="documento.docx", max_length=120)
    title: str = Field(default="", max_length=180)
    text: str = Field(min_length=1, max_length=100000)


class DocumentGenerateRequest(BaseModel):
    filename: str = Field(default="documento.docx", max_length=120)
    title: str = Field(default="Documento JARVIS", max_length=180)
    prompt: str = Field(min_length=10, max_length=5000)
    provider: str = Field(default="auto", pattern="^(auto|openai|gemini|local)$")


class PresentationRequest(BaseModel):
    filename: str = Field(default="apresentacao.pptx", max_length=120)
    title: str = Field(min_length=1, max_length=180)
    slides: list[dict[str, Any]]


class PresentationGenerateRequest(BaseModel):
    filename: str = Field(default="apresentacao.pptx", max_length=120)
    title: str = Field(min_length=1, max_length=180)
    prompt: str = Field(min_length=10, max_length=5000)
    provider: str = Field(default="auto", pattern="^(auto|openai|gemini|local)$")


class ProjectRequest(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    project_type: str = Field(pattern="^(web|python|pygame|godot|android)$")


class ProjectCheckRequest(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    confirm: bool = False


class ProjectGenerateRequest(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    project_type: str = Field(pattern="^(web|python|pygame|godot|android)$")
    prompt: str = Field(min_length=10, max_length=5000)
    provider: str = Field(default="auto", pattern="^(auto|openai|gemini|local)$")


class VideoRequest(BaseModel):
    images: list[str]
    seconds_per_image: int = 3
    audio: str | None = None


class MemoryRequest(BaseModel):
    content: str = Field(min_length=1, max_length=2000)


class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=400)


class ReadRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2000)


class PortScanRequest(BaseModel):
    ip: str = Field(min_length=7, max_length=45)


class RouterBlockRequest(BaseModel):
    ip: str = Field(min_length=7, max_length=45)
    confirm: bool = False


@app.get("/")
def index() -> HTMLResponse:
    html = (STATIC_DIR / "index.html").read_text(encoding="utf-8")
    verification = settings.google_site_verification.replace('"', "").replace("<", "").replace(">", "")
    html = html.replace("__GOOGLE_SITE_VERIFICATION__", verification)
    html = html.replace("__PUBLIC_URL__", settings.public_url)
    html = html.replace("https://jarvis-os.onrender.com", settings.public_url)
    return HTMLResponse(html)


@app.get("/legal")
def legal_page() -> HTMLResponse:
    html = (STATIC_DIR / "legal.html").read_text(encoding="utf-8")
    html = html.replace("__PUBLIC_URL__", settings.public_url)
    return HTMLResponse(html)


@app.get("/api/public-config")
def public_config() -> dict[str, Any]:
    # These are public identifiers/contact details only. Never return secret keys.
    return {
        "public_mode": getattr(settings, "public_mode", False),
        "privacy_contact_email": settings.privacy_contact_email,
        "legal_name": settings.legal_name,
        "legal_cnpj": settings.legal_cnpj,
        "legal_address": settings.legal_address,
        "dpo_contact": settings.dpo_contact,
        "ga_measurement_id": settings.ga_measurement_id,
        "meta_pixel_id": settings.meta_pixel_id,
        "public_url": settings.public_url,
    }


@app.get("/robots.txt")
def robots_txt():
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(
        "User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /workspace/\nSitemap: " + settings.public_url + "/sitemap.xml\n",
        media_type="text/plain",
    )


@app.get("/sitemap.xml")
def sitemap_xml():
    from fastapi.responses import Response
    base = settings.public_url
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        f'<url><loc>{base}/</loc></url>'
        f'<url><loc>{base}/legal</loc></url>'
        '</urlset>'
    )
    return Response(content=body, media_type="application/xml")


@app.get("/healthz")
def healthz() -> dict[str, bool]:
    return {"ok": True}


@app.get("/workspace/{file_path:path}")
def workspace_download(file_path: str, _: None = Depends(require_token)) -> FileResponse:
    # Workspace artifacts are isolated by the HttpOnly visitor session.
    root = session_workspace_dir(settings.workspace_dir).resolve()
    target = (root / file_path).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        raise HTTPException(status_code=404, detail="Arquivo não encontrado.")
    if not target.is_file():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado.")
    return FileResponse(target, filename=target.name)


@app.get("/api/status")
def status(_: None = Depends(require_token)) -> dict[str, Any]:
    if getattr(settings, "public_mode", False):
        context, network_available = {}, False
        desktop = {"available": False, "enabled": False, "reason": "Controle local indisponível no servidor público."}
    else:
        try:
            context = get_network_context()
            network_available = True
        except Exception:
            context, network_available = {}, False
        desktop = desktop_status()
    return {
        "ok": True, "name": "JARVIS", "version": app.version,
        "ai_configured": bool(configured_providers()),
        "providers": configured_providers(),
        "provider_preference": settings.ai_provider,
        "autotune": True,
        "ultraplinian_max_providers": min(3, len(configured_providers())),
        "local_only": settings.local_only,
        "model": settings.openai_model if "openai" in configured_providers() else (settings.gemini_model if "gemini" in configured_providers() else settings.local_model or None),
        "token_required": bool(settings.api_token) and not getattr(settings, "public_mode", False),
        "public_mode": getattr(settings, "public_mode", False), "session_isolated": True,
        "voice_reply_default": settings.voice_reply_default,
        "platform": "public" if getattr(settings, "public_mode", False) else __import__("platform").platform(),
        "network_available": network_available, "network": context,
        "router_control": False, "desktop": desktop,
        "workspace_items": len(list_workspace()),
        "features": {"chat": True, "memory": True, "voice_browser": True, "public_web_search": True,
                     "public_page_reader": True, "local_network_discovery": network_available and not getattr(settings, "public_mode", False),
                     "lan_port_diagnostics": network_available and not getattr(settings, "public_mode", False), "router_blocking": False,
                     "autotune": True, "ultraplinian": len(configured_providers()) >= 2,
                     "deep_research": True, "ai_project_generation": bool(configured_providers()),
                     "godot_project_builder": True, "desktop_control": desktop.get("available", False) and not getattr(settings, "public_mode", False),
                     "image_generation": bool(settings.openai_api_key), "audio_generation": bool(settings.openai_api_key),
                     "audio_transcription": bool(settings.openai_api_key), "workspace": True,
                     "documents": True, "ai_documents": bool(configured_providers()),
                     "slides": True, "ai_slides": bool(configured_providers()), "video_from_images": True}
    }


@app.get("/api/history")
def history(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"messages": recent_messages(80)}


@app.delete("/api/history")
def delete_history(_: None = Depends(require_token)) -> dict[str, bool]:
    clear_conversation()
    return {"ok": True}


@app.get("/api/memories")
def memories(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"memories": list_memories(100)}


@app.post("/api/memories")
def create_memory(payload: MemoryRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    memory_id = save_memory(payload.content)
    return {"ok": True, "id": memory_id, "message": "Memória salva."}


@app.delete("/api/memories/{memory_id}")
def remove_memory(memory_id: int, _: None = Depends(require_token)) -> dict[str, bool]:
    return {"ok": delete_memory(memory_id)}


@app.delete("/api/memories")
def remove_all_memories(_: None = Depends(require_token)) -> dict[str, bool]:
    from .database import clear_memories
    clear_memories()
    return {"ok": True}


@app.post("/api/chat")
def chat(payload: ChatRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    # Provider override is used for ordinary AI turns; explicit local commands remain local.
    from .database import add_message
    from .assistant import ask_ai
    from .platform_tools import handle_local_command
    text = payload.message.strip()
    # Never let public visitors operate the host machine or discover its environment.
    if getattr(settings, "public_mode", False):
        lowered = text.lower()
        safe_local = bool(re.match(r"^(?:jarvis[, ]*)?(?:lembre(?:-se)?|memorize|anote)\s+", text, re.I)) or bool(re.search(r"\b(o que você lembra|que você lembra|minhas memórias|minha memória|que horas são|que horas sao|horário agora|horario agora)\b", lowered))
        local_answer = handle_local_command(text) if safe_local else None
        if re.search(r"\b(status do sistema|informações do sistema|informacoes do sistema)\b", lowered):
            local_answer = "O serviço JARVIS está respondendo. Detalhes do sistema hospedeiro são privados e não são expostos a visitantes."
    else:
        local_answer = handle_local_command(text)
    if local_answer is not None:
        add_message("user", text)
        add_message("assistant", local_answer)
        return {"reply": local_answer, "mode": "local", "data": None}
    if payload.provider != "auto" and not any(keyword in text.lower() for keyword in ("pesquise", "pesquisar", "busque", "procure", "leia esta página", "analise https://")):
        add_message("user", text)
        answer, meta = ask_ai(text, provider=payload.provider)
        add_message("assistant", answer)
        return {"reply": answer, "mode": "ai", "data": {"ai": meta}}
    answer, mode, data = process_user_message(text, provider=payload.provider)
    return {"reply": answer, "mode": mode, "data": data}


@app.post("/api/chat/compare")
def chat_compare(payload: CompareRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        result = compare_providers(payload.message.strip(), payload.providers)
        return {"ok": True, **result}
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/network/overview")
def network_overview(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("ferramentas de rede local")
    try:
        context = get_network_context()
        return {"ok": True, **context, "last_scan": get_last_scan()}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/network/scan")
async def network_scan(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("ferramentas de rede local")
    try:
        return await scan_local_network()
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/network/ports")
def network_ports(payload: PortScanRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("ferramentas de rede local")
    try:
        return scan_device_ports(payload.ip)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/network/block")
def network_block(payload: RouterBlockRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("ferramentas de rede local")
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="A ação exige confirmação explícita.")
    # No universal router API exists. Never pretend that changing the PC's firewall blocks another LAN client.
    raise HTTPException(status_code=501, detail=(
        "Bloqueio real não está habilitado: cada roteador usa uma API diferente. "
        "O dispositivo não foi desconectado. Abra o painel do seu roteador e gerencie o acesso por lá."
    ))


@app.post("/api/network/router-panel")
def router_panel(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("ferramentas de rede local")
    try:
        context = get_network_context()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    gateway = context.get("gateway")
    if not gateway:
        raise HTTPException(status_code=404, detail="Não consegui identificar o gateway do roteador.")
    url = f"http://{gateway}"
    opened = open_website(url)
    return {"ok": True, "url": url, "message": opened}


@app.post("/api/web/search")
def web_search(payload: SearchRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return search_public_web(payload.query)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Pesquisa web falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="Não consegui consultar a pesquisa pública. Verifique a conexão.")


@app.post("/api/web/read")
def web_read(payload: ReadRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return read_public_page(payload.url)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Leitura de página falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="Não consegui abrir o conteúdo desse site.")


@app.post("/api/web/open")
def web_open(payload: ReadRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("abertura de navegador local")
    # Open only a URL explicitly supplied by the user from the server device.
    parsed = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(payload.url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Use um endereço público HTTP ou HTTPS.")
    return {"ok": True, "message": open_website(payload.url)}


@app.get("/api/desktop/status")
def desktop_state(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    return desktop_status()


@app.get("/api/desktop/screenshot")
def desktop_screenshot(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    try:
        image, width, height = screenshot_data_url()
        return {"ok": True, "image": image, "width": width, "height": height}
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/desktop/action")
def desktop_action(payload: DesktopActionRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    try:
        return execute_action(payload.action, confirmed=payload.confirm)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/desktop/automate")
async def desktop_automate(payload: DesktopTaskRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="Confirme explicitamente o início da automação visual.")
    try:
        return await asyncio.to_thread(run_computer_task, payload.task)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/desktop/task-status")
def desktop_task_state(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    return desktop_task_status()


@app.post("/api/desktop/stop")
def desktop_stop(_: None = Depends(require_token)) -> dict[str, bool]:
    require_private_host_feature("controle do computador")
    stop_desktop_task()
    return {"ok": True}


@app.post("/api/desktop/analyze")
def desktop_analyze(_: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("controle do computador")
    try:
        image, width, height = screenshot_data_url()
        analysis = analyze_desktop_image(image)
        return {"ok": True, "analysis": analysis, "width": width, "height": height}
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/media/image")
def media_image(payload: ImageRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return generate_image(payload.prompt, payload.size)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Geração de imagem falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="A geração de imagem falhou. Confira chave, modelo e créditos da API.")


@app.post("/api/media/speech")
def media_speech(payload: SpeechRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return generate_speech(payload.text, payload.voice)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Geração de áudio falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="A geração de áudio falhou. Confira chave, modelo e créditos da API.")


@app.post("/api/media/transcribe")
async def media_transcribe(file: UploadFile = File(...), _: None = Depends(require_token)) -> dict[str, Any]:
    data = await file.read(25 * 1024 * 1024 + 1)
    try:
        return transcribe_audio(file.filename or "audio.webm", data)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    finally:
        await file.close()


@app.post("/api/media/video")
def media_video(payload: VideoRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_video_from_images(payload.images, payload.seconds_per_image, payload.audio)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.get("/api/workspace")
def workspace(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"items": list_workspace()}


@app.post("/api/workspace/file")
def workspace_file(payload: FileWriteRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return write_text_file(payload.name, payload.content, overwrite=payload.overwrite)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/workspace/document")
def workspace_document(payload: DocumentRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_document(payload.filename, payload.title, payload.text)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/workspace/document/generate")
def workspace_document_generate(payload: DocumentGenerateRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_document_with_ai(payload.filename, payload.title, payload.prompt, payload.provider)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/api/workspace/presentation")
def workspace_presentation(payload: PresentationRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_presentation(payload.filename, payload.title, payload.slides)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/workspace/presentation/generate")
def workspace_presentation_generate(payload: PresentationGenerateRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_presentation_with_ai(payload.filename, payload.title, payload.prompt, payload.provider)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/api/workspace/project")
def workspace_project(payload: ProjectRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        if payload.project_type == "android":
            return create_android_project(payload.name)
        return create_project(payload.name, payload.project_type)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/workspace/project/generate")
def workspace_project_generate(payload: ProjectGenerateRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return create_project_with_ai(payload.name, payload.project_type, payload.prompt, payload.provider)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.post("/api/workspace/project/check")
def workspace_project_check(payload: ProjectCheckRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return run_project_check(payload.name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/workspace/project/build-android")
def workspace_android_build(payload: ProjectCheckRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    require_private_host_feature("compilação de APK no servidor")
    try:
        return build_android_project(payload.name, confirmed=payload.confirm)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


if __name__ == "__main__":
    import ipaddress
    import uvicorn
    host = settings.host
    try:
        is_loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = host.lower() == "localhost"
    if not is_loopback and not settings.api_token and not getattr(settings, "public_mode", False):
        raise SystemExit("SEGURANÇA: configure JARVIS_TOKEN ou ative JARVIS_PUBLIC_MODE para sessões públicas isoladas.")
    uvicorn.run("app.main:app", host=host, port=settings.port, reload=False)
