from __future__ import annotations

import os
import platform
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "sim", "on"}


@dataclass(frozen=True)
class Settings:
    host: str = os.getenv("JARVIS_HOST", "127.0.0.1")
    port: int = int(os.getenv("PORT", os.getenv("JARVIS_PORT", "8787")))
    api_token: str = os.getenv("JARVIS_TOKEN", "")
    public_mode: bool = _as_bool(os.getenv("JARVIS_PUBLIC_MODE"), False)
    public_url: str = os.getenv("JARVIS_PUBLIC_URL", "https://jarvis-os.onrender.com").rstrip("/")
    privacy_contact_email: str = os.getenv("JARVIS_PRIVACY_EMAIL", "").strip()
    legal_name: str = os.getenv("JARVIS_LEGAL_NAME", "").strip()
    legal_cnpj: str = os.getenv("JARVIS_CNPJ", "").strip()
    legal_address: str = os.getenv("JARVIS_LEGAL_ADDRESS", "").strip()
    dpo_contact: str = os.getenv("JARVIS_DPO_CONTACT", "").strip()
    google_site_verification: str = os.getenv("GOOGLE_SITE_VERIFICATION", "").strip()
    ga_measurement_id: str = os.getenv("GA_MEASUREMENT_ID", "").strip()
    meta_pixel_id: str = os.getenv("META_PIXEL_ID", "").strip()
    rate_limit_per_minute: int = max(10, int(os.getenv("JARVIS_RATE_LIMIT_PER_MINUTE", "60")))
    data_retention_days: int = max(7, min(365, int(os.getenv("JARVIS_DATA_RETENTION_DAYS", "90"))))
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-6.1-sol")
    openai_computer_model: str = os.getenv("OPENAI_COMPUTER_MODEL", "gpt-6.1-sol")
    openai_image_model: str = os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-2.5-flare")
    openai_transcription_model: str = os.getenv("OPENAI_TRANSCRIPTION_MODEL", "gpt-transcribe")
    openai_tts_model: str = os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts")
    ai_provider: str = os.getenv("JARVIS_AI_PROVIDER", "auto").strip().lower()
    local_base_url: str = os.getenv("JARVIS_LOCAL_BASE_URL", "http://127.0.0.1:11434/v1")
    local_model: str = os.getenv("JARVIS_LOCAL_MODEL", "")
    local_api_key: str = os.getenv("JARVIS_LOCAL_API_KEY", "")
    local_only: bool = _as_bool(os.getenv("JARVIS_LOCAL_ONLY"), False)
    desktop_control_enabled: bool = _as_bool(os.getenv("JARVIS_DESKTOP_CONTROL"), False)
    voice_reply_default: bool = _as_bool(os.getenv("JARVIS_VOICE_REPLY"), False)
    database_path: Path = Path(os.getenv("JARVIS_DB_PATH", str(ROOT_DIR / "data" / "jarvis.db")))
    workspace_dir: Path = Path(os.getenv("JARVIS_WORKSPACE_DIR", str(ROOT_DIR / "workspace")))
    platform_name: str = platform.system()


settings = Settings()
settings.workspace_dir.mkdir(parents=True, exist_ok=True)
