from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

from .assistant import ask_ai
from .config import settings
from .database import add_message
from .network_tools import scan_local_network, get_network_context
from .platform_tools import handle_local_command, open_website
from .web_tools import read_public_page, search_public_web
from .research_tools import deep_research_public


def _search_query(message: str) -> str | None:
    patterns = [
        r"^(?:jarvis[, ]*)?(?:pesquise|pesquisar|pesquisa|busque|procure)(?:\s+na\s+internet|\s+na\s+web)?\s+(?:sobre\s+)?(.+)$",
        r"^(?:jarvis[, ]*)?(?:encontre|localize)\s+(?:na\s+internet|na\s+web)\s+(.+)$",
    ]
    for pattern in patterns:
        match = re.match(pattern, message.strip(), re.I)
        if match:
            return match.group(1).strip()
    return None


def _deep_research_query(message: str) -> str | None:
    patterns = [
        r"^(?:jarvis[, ]*)?(?:pesquise profundamente|pesquise a fundo|faça uma pesquisa aprofundada|faca uma pesquisa aprofundada|pesquisa profunda|investigue a fundo|pesquise em várias fontes|pesquise em varias fontes)(?:\s+sobre)?\s+(.+)$",
    ]
    for pattern in patterns:
        match = re.match(pattern, message.strip(), re.I)
        if match:
            return match.group(1).strip()
    return None


def _page_url(message: str) -> str | None:
    match = re.search(r"https?://[^\s]+", message, re.I)
    if match and re.search(r"\b(leia|resuma|analise|analisa|explique|abra a página|leia a página)\b", message, re.I):
        return match.group(0).rstrip(".,);]")
    return None


def _network_requested(message: str) -> bool:
    lower = message.lower()
    return any(term in lower for term in (
        "escaneie minha rede", "escaneia minha rede", "varra minha rede", "verifique minha rede",
        "quem está conectado", "quem esta conectado", "quem está no wi-fi", "quem esta no wi-fi",
        "dispositivos conectados", "scan na rede", "scanner de rede", "escaneie o wi-fi", "escaneia o wi-fi"
    ))


def _format_scan(scan: dict[str, Any]) -> str:
    rows = [f"Encontrei {scan['device_count']} dispositivo(s) na rede {scan['cidr']}.", f"Interface: {scan['interface']} · IP deste dispositivo: {scan['ip']}"]
    if scan.get("gateway"):
        rows.append(f"Roteador/gateway: {scan['gateway']}")
    for device in scan["devices"][:40]:
        mac = f" · MAC {device['mac']}" if device.get("mac") else ""
        rows.append(f"• {device['ip']} — {device['name']} — {device['status']}{mac}")
    rows.append("A varredura é de descoberta local. Faça a gestão de acesso pelo painel do seu próprio roteador; o JARVIS não derruba dispositivos com ataques Wi-Fi.")
    return "\n".join(rows)


def process_user_message(message: str, provider: str = "auto") -> tuple[str, str, dict[str, Any] | None]:
    """Route clear tool intents first; fall back to local commands and the configured AI provider."""
    add_message("user", message)
    try:
        if _network_requested(message) and settings.public_mode:
            answer = "A descoberta da rede local atua no dispositivo servidor e, por segurança, só está disponível na instalação privada do JARVIS."
            mode, payload = "local", None
        elif _network_requested(message):
            scan = __import__("asyncio").run(scan_local_network())
            answer = _format_scan(scan)
            mode = "network"
            payload = {"network": scan}
        elif re.search(r"^(?:jarvis[, ]*)?(?:por favor[, ]*)?(?:desconecte|desconectar|bloqueie|bloquear|pause(?: a internet)?|tire do wi-?fi)\b", message.strip(), re.I):
            if settings.public_mode:
                gateway_note = ""
            else:
                try:
                    context = get_network_context()
                    gateway_note = f" O painel do roteador deve estar em http://{context['gateway']}." if context.get("gateway") else ""
                except Exception:
                    gateway_note = ""
            answer = ("Ainda não posso bloquear ou desconectar um aparelho diretamente: isso depende de uma integração compatível com a marca/modelo do seu roteador e da sua autorização administrativa. "
                      "Nenhum dispositivo foi desconectado. Abra o painel do roteador e use a função de controle de acesso." + gateway_note)
            mode, payload = "local", None
        else:
            deep_query = _deep_research_query(message)
            query = _search_query(message)
            page_url = _page_url(message)
            if deep_query:
                research = deep_research_public(deep_query, provider=provider)
                answer = research["reply"]
                mode, payload = "web", {"research": research}
            elif query:
                result = search_public_web(query)
                if result["results"]:
                    context = "\n".join(f"Título: {r['title']}\nURL: {r['url']}\nResumo: {r['snippet']}" for r in result["results"])
                    try:
                        answer, ai_meta = ask_ai(message, extra_context="RESULTADOS ATUAIS DA PESQUISA PÚBLICA:\n" + context, provider=provider)
                    except Exception:
                        ai_meta = {}
                        answer = "Encontrei estes resultados, mas a IA não conseguiu resumi-los nesta tentativa:\n\n" + "\n\n".join(f"{i+1}. {r['title']}\n{r['snippet']}\n{r['url']}" for i, r in enumerate(result["results"][:6]))
                    answer += "\n\nFontes encontradas:\n" + "\n".join(f"• {r['title']} — {r['url']}" for r in result["results"][:6])
                else:
                    answer = "Não encontrei resultados nessa pesquisa. Tente reformular os termos."
                mode, payload = "web", {"search": result}
            elif page_url:
                page = read_public_page(page_url)
                try:
                    answer, ai_meta = ask_ai(message, extra_context=f"CONTEÚDO DA PÁGINA PÚBLICA\nTítulo: {page['title']}\nURL: {page['url']}\nConteúdo:\n{page['text']}", provider=provider)
                except Exception:
                    ai_meta = {}
                    answer = f"Consegui extrair o texto de **{page['title']}**, mas nenhum provedor de IA respondeu.\n\n{page['text'][:1800]}"
                answer += f"\n\nPágina consultada: {page['url']}"
                mode, payload = "web", {"page": {"title": page["title"], "url": page["url"]}}
            else:
                # In public deployments only allow per-session memory and clock commands.
                if settings.public_mode:
                    lowered = message.lower()
                    safe_local = bool(re.match(r"^(?:jarvis[, ]*)?(?:lembre(?:-se)?|memorize|anote)\s+", message, re.I)) or bool(re.search(r"\b(o que você lembra|que você lembra|minhas memórias|minha memória|que horas são|que horas sao|horário agora|horario agora)\b", lowered))
                    answer = handle_local_command(message) if safe_local else None
                    if re.search(r"\b(status do sistema|informações do sistema|informacoes do sistema)\b", lowered):
                        answer = "O serviço JARVIS está respondendo. Detalhes do sistema hospedeiro são privados."
                else:
                    answer = handle_local_command(message)
                mode, payload = ("local", None) if answer is not None else ("ai", None)
                ai_meta = {}
                if answer is None:
                    answer, ai_meta = ask_ai(message, provider=provider)
        add_message("assistant", answer)
        if mode == "ai" and ai_meta:
            payload = {"ai": ai_meta}
        elif mode == "web" and ai_meta:
            payload = {**(payload or {}), "ai": ai_meta}
        return answer, mode, payload
    except (ValueError, RuntimeError) as exc:
        answer = str(exc)
        add_message("assistant", answer)
        return answer, "local", None
    except Exception as exc:
        answer = f"Não consegui concluir essa ação ({type(exc).__name__}). Verifique sua conexão e tente novamente."
        add_message("assistant", answer)
        return answer, "error", None
