from __future__ import annotations

import asyncio
import ipaddress
import platform
import re
import shutil
import socket
import subprocess
from concurrent.futures import ThreadPoolExecutor
from typing import Any
from urllib.parse import urlparse

COMMON_PORTS = [22, 23, 53, 80, 139, 443, 445, 554, 631, 1883, 3306, 3389, 5000, 8000, 8080, 8443, 9000, 9100]
_LAST_SCAN: dict[str, Any] | None = None


def _run(args: list[str], timeout: float = 2.0) -> str:
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout, check=False)
        return (result.stdout or "") + "\n" + (result.stderr or "")
    except (OSError, subprocess.TimeoutExpired):
        return ""


def get_network_context() -> dict[str, Any]:
    """Return only private IPv4 networks on active local interfaces."""
    candidates: list[dict[str, Any]] = []
    try:
        import psutil
        stats = psutil.net_if_stats()
        for ifname, addresses in psutil.net_if_addrs().items():
            if ifname in stats and not stats[ifname].isup:
                continue
            for item in addresses:
                if item.family != socket.AF_INET or not item.address or not item.netmask:
                    continue
                try:
                    ip = ipaddress.ip_address(item.address)
                    network = ipaddress.ip_network(f"{item.address}/{item.netmask}", strict=False)
                except ValueError:
                    continue
                _append_candidate(candidates, ifname, ip, network)
    except ImportError:
        candidates.extend(_fallback_interfaces())

    if not candidates:
        raise RuntimeError("Não encontrei uma interface IPv4 privada com uma rede de até 256 endereços. Verifique se está conectado ao Wi-Fi ou Ethernet.")

    candidates.sort(key=lambda x: (any(k in x["interface"].lower() for k in ("docker", "veth", "br-", "vmnet", "virtual")), -x["network"].prefixlen))
    selected = candidates[0]
    network = selected.pop("network")
    gateway = _default_gateway()
    selected["cidr"] = str(network)
    selected["gateway"] = gateway
    selected["router_url"] = f"http://{gateway}" if gateway else None
    return selected


def _append_candidate(candidates: list[dict[str, Any]], ifname: str, ip: ipaddress.IPv4Address, network: ipaddress.IPv4Network) -> None:
    if not ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_unspecified or network.num_addresses > 256:
        return
    candidates.append({"interface": ifname, "ip": str(ip), "cidr": str(network), "network": network})


def _fallback_interfaces() -> list[dict[str, Any]]:
    """Use native OS network tools when psutil is unavailable (notably Termux)."""
    system = platform.system().lower()
    candidates: list[dict[str, Any]] = []
    if system == "windows":
        output = _run(["ipconfig"], 3)
        blocks = re.split(r"\r?\n(?=[^ \t].*:)", output)
        for block in blocks:
            name = re.match(r"([^\r\n:]+):", block)
            address = re.search(r"IPv4[^:]*:\s*([0-9.]+)", block, re.I)
            mask = re.search(r"Subnet Mask[^:]*:\s*([0-9.]+)", block, re.I)
            if not (name and address and mask):
                continue
            try:
                ip = ipaddress.ip_address(address.group(1))
                network = ipaddress.ip_network(f"{ip}/{mask.group(1)}", strict=False)
            except ValueError:
                continue
            _append_candidate(candidates, name.group(1).strip(), ip, network)
    elif shutil.which("ip"):
        output = _run(["ip", "-o", "-4", "addr", "show", "scope", "global"], 3)
        for line in output.splitlines():
            match = re.match(r"\s*\d+:\s+([^ ]+)\s+inet\s+([0-9.]+/\d+)", line)
            if not match:
                continue
            try:
                interface = match.group(1).split("@", 1)[0]
                ip_interface = ipaddress.ip_interface(match.group(2))
                _append_candidate(candidates, interface, ip_interface.ip, ip_interface.network)
            except ValueError:
                continue
    elif shutil.which("ifconfig"):
        output = _run(["ifconfig"], 3)
        current = ""
        for line in output.splitlines():
            header = re.match(r"^([a-zA-Z0-9_.-]+):", line)
            if header:
                current = header.group(1)
            match = re.search(r"\binet\s+([0-9.]+)\s+netmask\s+(0x[0-9a-fA-F]+|[0-9.]+)", line)
            if not (current and match):
                continue
            try:
                ip = ipaddress.ip_address(match.group(1))
                mask_text = match.group(2)
                mask = str(ipaddress.IPv4Address(int(mask_text, 16))) if mask_text.startswith("0x") else mask_text
                network = ipaddress.ip_network(f"{ip}/{mask}", strict=False)
                _append_candidate(candidates, current, ip, network)
            except ValueError:
                continue
    return candidates


def _default_gateway() -> str | None:
    system = platform.system().lower()
    if system == "windows":
        output = _run(["route", "print", "-4"], 2)
        for line in output.splitlines():
            match = re.match(r"\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d{1,3}(?:\.\d{1,3}){3})", line)
            if match:
                return match.group(1)
    elif system == "darwin":
        output = _run(["route", "-n", "get", "default"], 2)
        match = re.search(r"gateway:\s*(\d{1,3}(?:\.\d{1,3}){3})", output)
        if match:
            return match.group(1)
    else:
        output = _run(["ip", "route", "show", "default"], 2)
        match = re.search(r"\bdefault\s+via\s+(\d{1,3}(?:\.\d{1,3}){3})", output)
        if match:
            return match.group(1)
    return None


def _arp_table() -> dict[str, str]:
    output = ""
    if shutil.which("ip"):
        output = _run(["ip", "neigh"], 2)
    if not output.strip() and shutil.which("arp"):
        output = _run(["arp", "-a"], 2)
    result: dict[str, str] = {}
    for line in output.splitlines():
        ip_match = re.search(r"\b(\d{1,3}(?:\.\d{1,3}){3})\b", line)
        mac_match = re.search(r"\b([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}\b", line)
        if not ip_match:
            continue
        ip = ip_match.group(1)
        try:
            if not ipaddress.ip_address(ip).is_private:
                continue
        except ValueError:
            continue
        mac = mac_match.group(0).replace("-", ":").lower() if mac_match else ""
        if mac and mac != "00:00:00:00:00:00":
            result[ip] = mac
    return result


async def _ping(ip: str, semaphore: asyncio.Semaphore) -> bool:
    system = platform.system().lower()
    if system == "windows":
        args = ["ping", "-n", "1", "-w", "700", ip]
    elif system == "darwin":
        args = ["ping", "-c", "1", "-W", "900", ip]
    else:
        args = ["ping", "-c", "1", "-W", "1", ip]
    async with semaphore:
        try:
            proc = await asyncio.create_subprocess_exec(*args, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            await asyncio.wait_for(proc.wait(), timeout=2.0)
            return proc.returncode == 0
        except (FileNotFoundError, asyncio.TimeoutError, OSError):
            return False


async def scan_local_network() -> dict[str, Any]:
    global _LAST_SCAN
    context = get_network_context()
    network = ipaddress.ip_network(context["cidr"], strict=False)
    hosts = [str(ip) for ip in network.hosts() if str(ip) != context["ip"]]
    semaphore = asyncio.Semaphore(48)
    ping_results = await asyncio.gather(*[_ping(ip, semaphore) for ip in hosts])
    # Read neighbor cache after probing: ping may have populated ARP entries even when ICMP is blocked.
    arp = _arp_table()
    devices: list[dict[str, Any]] = [{
        "ip": context["ip"], "mac": arp.get(context["ip"], ""), "name": "Este dispositivo", "status": "Este dispositivo", "is_self": True
    }]
    for ip, alive in zip(hosts, ping_results):
        if alive or ip in arp:
            devices.append({
                "ip": ip,
                "mac": arp.get(ip, ""),
                "name": "Dispositivo na rede",
                "status": "Online" if alive else "Visto na tabela ARP",
                "is_self": False,
            })
    devices.sort(key=lambda d: tuple(int(part) for part in d["ip"].split(".")))
    result = {
        **context,
        "scanned_at": __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"),
        "device_count": len(devices),
        "devices": devices,
        "scan_note": "A descoberta usa ping e a tabela ARP. Alguns aparelhos podem ocultar respostas; MAC/fabricante pode não estar disponível em redes segmentadas ou em Android sem permissões adicionais."
    }
    _LAST_SCAN = result
    return result


def scan_device_ports(target_ip: str) -> dict[str, Any]:
    if not _LAST_SCAN:
        raise ValueError("Faça primeiro uma varredura da rede local.")
    try:
        target = ipaddress.ip_address(target_ip)
        network = ipaddress.ip_network(_LAST_SCAN["cidr"], strict=False)
    except ValueError:
        raise ValueError("Endereço IP inválido.")
    if target not in network or target_ip not in {d["ip"] for d in _LAST_SCAN["devices"]}:
        raise ValueError("Por segurança, só posso verificar portas de um dispositivo encontrado na sua rede local.")
    open_ports: list[dict[str, Any]] = []
    for port in COMMON_PORTS:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.28)
        try:
            if sock.connect_ex((target_ip, port)) == 0:
                open_ports.append({"port": port, "service": _service_name(port), "state": "open"})
        finally:
            sock.close()
    return {"ip": target_ip, "checked_ports": COMMON_PORTS, "open_ports": open_ports}


def _service_name(port: int) -> str:
    try:
        return socket.getservbyport(port, "tcp").upper()
    except OSError:
        return {1883: "MQTT", 5000: "APP", 8000: "HTTP-ALT", 8080: "HTTP-ALT", 8443: "HTTPS-ALT", 9000: "APP", 9100: "PRINTER"}.get(port, "TCP")


def validate_local_target(ip_text: str) -> str:
    if not _LAST_SCAN:
        raise ValueError("Faça primeiro uma varredura da rede local.")
    ip = ipaddress.ip_address(ip_text)
    network = ipaddress.ip_network(_LAST_SCAN["cidr"], strict=False)
    if ip not in network:
        raise ValueError("O destino precisa pertencer à rede local que acabou de ser verificada.")
    return str(ip)


def get_last_scan() -> dict[str, Any] | None:
    return _LAST_SCAN
