from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Iterable


@dataclass(frozen=True)
class AutoTuneProfile:
    context: str
    confidence: float
    temperature: float
    max_output_tokens: int
    reasoning_effort: str
    instruction: str
    scores: dict[str, int]


_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "code": (
        re.compile(r"\b(python|javascript|typescript|html|css|sql|api|bug|erro|debug|função|classe|compile|terminal|apk|app|aplicativo|jogo|game|programa|servidor|banco de dados|framework|biblioteca|dependência)\b", re.I),
        re.compile(r"```[\s\S]*?```"),
        re.compile(r"\b(crie|corrija|implemente|desenvolva|construa|teste)\b.{0,70}\b(app|aplicativo|site|programa|código|codigo|jogo|api|sistema|projeto|função|funcao)\b", re.I),
    ),
    "creative": (
        re.compile(r"\b(história|roteiro|personagem|poema|música|imagem|vídeo|design|criativo|arte|ilustração|animação|thumbnail|miniatura|logo|identidade visual)\b", re.I),
        re.compile(r"\b(imagine|ilustre|desenhe|componha|invente|gere uma imagem|crie uma imagem|crie um vídeo|crie um audio|crie um áudio)\b", re.I),
    ),
    "analytical": (
        re.compile(r"\b(analise|análise|compare|pesquise|investigue|estude|verifique|avalie|explique|resuma|relatório|dados|evidências|referências|fontes|pesquisa profunda)\b", re.I),
        re.compile(r"\b(vantagens|desvantagens|diferenças|causas|consequências|impactos|alternativas)\b", re.I),
    ),
    "conversational": (
        re.compile(r"\b(oi|olá|obrigado|valeu|bom dia|boa tarde|boa noite|tudo bem|como vai)\b", re.I),
    ),
}

_PROFILES = {
    "code": (0.20, 1800, "high", "Priorize correção, código completo, compatibilidade e testes. Explique dependências e não afirme que executou algo que não foi testado."),
    "creative": (0.90, 1600, "medium", "Priorize originalidade, clareza e acabamento. Respeite exatamente o formato e as restrições solicitadas."),
    "analytical": (0.35, 2000, "high", "Raciocine com rigor, diferencie fatos de inferências, cite fontes quando houver pesquisa e destaque incertezas."),
    "conversational": (0.65, 900, "low", "Responda de maneira natural, direta e contextualizada, sem excesso de formalidade."),
}


def classify_context(message: str, history: Iterable[dict[str, str]] = ()) -> AutoTuneProfile:
    """Low-cost AutoTune port inspired by G0DM0D3; keyword scoring, no extra model call."""
    scores = {key: 0 for key in _PATTERNS}
    text = str(message or "")[:12000]
    for context, patterns in _PATTERNS.items():
        for pattern in patterns:
            if pattern.search(text):
                scores[context] += 3
    # Use at most four recent turns, with a lower weight than the current request.
    recent = list(history)[-4:]
    for item in recent:
        content = str(item.get("content", ""))[:2000]
        for context, patterns in _PATTERNS.items():
            if any(pattern.search(content) for pattern in patterns):
                scores[context] += 1
    total = sum(scores.values())
    if total == 0:
        context, confidence = "conversational", 0.5
    else:
        context = max(scores, key=scores.get)
        confidence = scores[context] / total
    temperature, max_tokens, effort, instruction = _PROFILES[context]
    return AutoTuneProfile(context, round(confidence, 3), temperature, max_tokens, effort, instruction, scores)


def profile_to_dict(profile: AutoTuneProfile) -> dict[str, object]:
    return asdict(profile)
