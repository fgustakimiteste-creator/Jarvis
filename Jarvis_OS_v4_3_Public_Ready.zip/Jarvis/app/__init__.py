"""JARVIS shared application package."""
