# JARVIS OS v4.1 — agente pessoal multiplataforma

JARVIS OS v4.1 é uma aplicação Python com interface web responsiva e inicialização simplificada para Windows. O PC pode hospedar o núcleo e o Android pode controlá-lo pelo Chrome, na mesma rede Wi-Fi, sem Termux no celular. Também permanece disponível a execução direta em Android via Termux. **Esta entrega não é um APK Android independente.**

## O que está implementado

### Assistente e agente
- Chat com Gemini pelo SDK `google-genai` quando `GEMINI_API_KEY` estiver configurada.
- Modo local com comandos permitidos mesmo sem chave de IA.
- Memória persistente SQLite: listar, salvar, excluir uma memória ou apagar todas.
- Histórico de conversas salvo e opção de reiniciar a conversa preservando as memórias.
- Roteamento de comandos explícitos para ferramentas: abrir sites/atalhos, pesquisar na web, ler páginas públicas e descobrir a rede local.
- Voz no navegador: reconhecimento de fala e síntese de resposta quando o browser oferece suporte. O reconhecimento por microfone pode exigir HTTPS ou localhost; alguns navegadores bloqueiam o microfone quando o celular acessa o IP HTTP do PC.

### Navegação pela internet
- Pesquisa pública pelo DuckDuckGo HTML.
- Extração de texto de páginas públicas HTTP/HTTPS para leitura e resumo via Gemini.
- Resultados com links para abrir em uma nova aba.
- Proteções contra acesso a localhost, IPs privados, endereços reservados, credenciais embutidas e redirecionamentos para redes internas.
- O leitor não faz login, não envia formulários, não compra, não publica nem executa transações automaticamente.

### Scanner e diagnóstico da rede local
- Detecta interfaces IPv4 privadas no dispositivo que hospeda o JARVIS.
- Varre somente a sub-rede privada local detectada (limitada a 256 endereços por execução).
- Usa respostas de ping e tabela ARP para encontrar dispositivos; mostra IP, MAC quando disponível, status e interface.
- Verifica uma lista fixa de portas TCP comuns somente para um dispositivo que apareceu na última varredura e pertence à mesma sub-rede.
- Identifica o gateway quando o sistema operacional disponibiliza essa informação e permite abrir seu painel administrativo no navegador.
- Monitoramento manual em intervalos de 60 segundos enquanto a interface permanece aberta, com aviso de possíveis entradas/saídas.
- Exportação do inventário encontrado em CSV.

**Limitações importantes do scanner:** a descoberta não é infalível. Alguns equipamentos bloqueiam ping, isolam clientes Wi-Fi ou não aparecem na tabela ARP. Itens vistos apenas na tabela ARP são marcados como possivelmente vistos, pois uma entrada antiga não garante que o dispositivo ainda esteja online. O Android/Termux pode expor menos informações de rede que o Windows/Linux. O reconhecimento de fabricante/modelo não é inventado: quando não existe base local para isso, o campo MAC ou fabricante fica indisponível.

### Controle do roteador
- O JARVIS identifica o gateway e abre a página de administração.
- Bloquear/pausar um cliente depende do fabricante, modelo, firmware e permissões administrativas do roteador. Não existe uma API universal; por isso a v4.1 não finge que um botão genérico desconectou o dispositivo.
- Para implementar bloqueio real, precisamos conhecer o modelo exato do roteador e escolher uma integração oficial/administrativa compatível. O bloqueio só deve ser feito em uma rede que você administra. Informe a marca e o modelo impressos na etiqueta ou exibidos no aplicativo do provedor.

## Escopo de segurança em relação ao StrykerOSS

StrykerOSS é uma suíte de pentest para Android. O JARVIS adota apenas funções defensivas e administrativas adequadas ao uso doméstico: descoberta de hosts, inventário local, diagnóstico de portas e leitura de informações públicas.

Esta versão **não implementa** desautenticação/deauth Wi-Fi, captura ou quebra de handshakes, brute force, exploração de vulnerabilidades, payloads HID, roubo de credenciais ou execução de exploits. Esses módulos podem derrubar conexões ou comprometer dispositivos. Também não existe execução livre de shell pela IA.

## Requisitos

- Python 3.11 ou 3.12 recomendado.
- Windows 10/11 ou Linux/macOS; Android pode funcionar como cliente web sem Termux, ou executar o backend diretamente via Termux.
- `ping` e o utilitário de rede do sistema (`ip`/`ipconfig`) para descoberta LAN. `psutil` é opcional e melhora métricas de CPU/RAM no status do sistema.
- `GEMINI_API_KEY` opcional. Sem chave, as ferramentas locais e o scanner continuam disponíveis; respostas generativas ficam indisponíveis.

## Instalação no Windows

1. Instale Python 3.11/3.12 e marque **Add Python to PATH**.
2. Extraia o ZIP.
3. Para uso somente no PC, execute `start_windows.bat`.
4. Para usar o PC como servidor e controlar pelo Android sem Termux, execute `start_windows_pc_android.bat`. Esse launcher cria um token forte se necessário, configura `JARVIS_HOST=0.0.0.0`, instala as dependências e exibe os endereços e o token de acesso.
5. No Android conectado ao mesmo Wi-Fi, abra no Chrome o endereço LAN exibido pelo launcher e informe o token.

O Windows Firewall pode pedir permissão. Permita o Python apenas em redes privadas. Se não aparecer a solicitação, crie uma regra de entrada para a porta configurada (por padrão 8787), limitada ao perfil **Privado**.

### Usar no Android sem Termux

O Android funciona como cliente web: não precisa instalar Python, Termux ou dependências no celular. O backend, a memória SQLite, a IA e o scanner de rede rodam no PC. O PC precisa permanecer ligado, com o JARVIS aberto, e os dois dispositivos devem estar na mesma rede local. No Chrome, o menu pode oferecer **Adicionar à tela inicial** para criar um atalho. Esse atalho não é um APK independente e não permite usar o JARVIS quando o PC estiver desligado.

Para executar tudo somente no Android, sem PC e sem Termux, é necessário desenvolver e compilar um aplicativo Android nativo com núcleo local integrado. A versão 4.1 não é esse APK.

## Instalação no Android (Termux)

```bash
pkg update && pkg upgrade
pkg install python git termux-api iproute2 iputils
```

Entre na pasta `JARVIS` e execute:

```bash
chmod +x start_termux.sh
./start_termux.sh
```

Acesse `http://127.0.0.1:8787` no Chrome. Microfone e voz dependem do navegador e de suas permissões. O scanner no Android pode ter menos visibilidade dependendo da versão e permissões do sistema.

## Configuração manual PC + Android

O launcher `start_windows_pc_android.bat` faz automaticamente a configuração descrita nesta seção. Para configurar manualmente:

1. No PC, abra `.env` e defina `JARVIS_HOST=0.0.0.0`.
2. Defina um token longo e aleatório em `JARVIS_TOKEN`.
3. Reinicie o JARVIS. Permita a porta 8787 apenas na rede privada do firewall.
4. Descubra o IPv4 do PC com `ipconfig`.
5. No Android, acesse `http://IP_DO_PC:8787` e informe o token.

Não encaminhe a porta 8787 para a internet. Para acesso externo, prefira uma VPN privada e mantenha autenticação forte/HTTPS.

## Configuração da IA

Edite `.env`:

```env
JARVIS_HOST=127.0.0.1
JARVIS_PORT=8787
JARVIS_TOKEN=
GEMINI_API_KEY=sua_chave
GEMINI_MODEL=gemini-3.8-flash
JARVIS_VOICE_REPLY=false
```

A chave é lida apenas pelo backend. Nunca a coloque no `static/app.js` nem compartilhe o `.env`.

## Comandos de exemplo

- `Jarvis, abra o YouTube`
- `Jarvis, pesquise na internet segurança de roteadores domésticos`
- `Jarvis, leia esta página https://example.com/artigo`
- `Jarvis, escaneie minha rede e mostre quem está conectado`
- `Jarvis, status do sistema`
- `Jarvis, lembre que prefiro respostas diretas`
- `Jarvis, o que você lembra?`

## Testes

Dentro da pasta do projeto:

```bash
python -m compileall app tests
python -m pytest -q
```

## Estrutura

```text
JARVIS/
├── app/
│   ├── agent.py           # roteamento de comandos e ferramentas
│   ├── assistant.py       # Gemini + contexto de memória/histórico
│   ├── config.py          # configuração .env
│   ├── database.py        # histórico e memória SQLite
│   ├── main.py            # API FastAPI
│   ├── network_tools.py   # descoberta LAN e diagnóstico TCP restrito
│   ├── platform_tools.py  # atalhos locais seguros
│   └── web_tools.py       # pesquisa e leitura pública com proteção SSRF
├── static/
│   ├── index.html         # painel multiplataforma
│   ├── style.css          # tema, animações e responsividade
│   └── app.js             # interações e integração da interface
├── tests/
├── tools/
│   └── prepare_lan.py     # prepara acesso PC + Android com token forte
├── data/                  # criado automaticamente
├── .env.example
├── INICIAR_SEM_TERMUX.txt
├── start_windows_pc_android.bat
└── start_*.sh / .bat
```
