@echo off
setlocal EnableExtensions
cd /d "%~dp0"

 title JARVIS OS - PC + Android
 echo.
 echo  ================================================
 echo           J A R V I S   O S   4.1
 echo         Inicializacao PC + Android
 echo  ================================================
 echo.

if not exist .venv (
    echo [1/4] Preparando ambiente Python...
    where py >nul 2>nul
    if not errorlevel 1 (
        py -3.12 -m venv .venv 2>nul
        if errorlevel 1 py -3.11 -m venv .venv 2>nul
    ) else (
        python -c "import sys; raise SystemExit(0 if sys.version_info[:2] in ((3,11),(3,12)) else 1)" >nul 2>nul
        if errorlevel 1 (
            echo ERRO: instale Python 3.11 ou 3.12 e marque Add Python to PATH.
            pause
            exit /b 1
        )
        python -m venv .venv
    )
    if errorlevel 1 (
        echo ERRO: nao foi possivel criar o ambiente virtual.
        pause
        exit /b 1
    )
) else (
    echo [1/4] Ambiente Python encontrado.
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo ERRO: nao foi possivel ativar o ambiente virtual.
    pause
    exit /b 1
)

if not exist .env copy .env.example .env >nul

echo [2/4] Instalando ou atualizando dependencias...
python -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo ERRO: falha ao instalar dependencias. Verifique a internet e tente novamente.
    pause
    exit /b 1
)

echo [3/4] Configurando acesso seguro pela rede local...
python tools\prepare_lan.py --machine > .lan_launch.tmp
if errorlevel 1 (
    echo ERRO: nao foi possivel preparar a configuracao da rede.
    pause
    del .lan_launch.tmp >nul 2>nul
    exit /b 1
)
for /f "usebackq tokens=1,* delims==" %%A in (".lan_launch.tmp") do set "%%A=%%B"
del .lan_launch.tmp >nul 2>nul
if not defined LAN_PORT set "LAN_PORT=8787"
if not defined LAN_IP set "LAN_IP=IP_NAO_DETECTADO"
if not defined JARVIS_TOKEN (
    echo ERRO: token de acesso nao foi gerado.
    pause
    exit /b 1
)

echo.
echo  [4/4] Inicializando o servidor JARVIS...
echo.
echo  -----------------------------------------------
echo  NO PC:      http://127.0.0.1:%LAN_PORT%
if /i not "%LAN_IP%"=="IP_NAO_DETECTADO" echo  NO ANDROID: http://%LAN_IP%:%LAN_PORT%
echo  TOKEN:      %JARVIS_TOKEN%
echo  -----------------------------------------------
echo.
echo  No Android, use o Chrome conectado ao MESMO Wi-Fi.
echo  Digite o endereco acima e informe o token quando pedido.
echo  Se o Firewall perguntar, permita acesso em redes PRIVADAS.
echo  Mantenha esta janela aberta enquanto usar o JARVIS.
echo.
echo  Para parar o servidor, pressione Ctrl+C.
echo.
python -m app.main
if errorlevel 1 (
    echo.
    echo O JARVIS foi encerrado com erro. Leia a mensagem acima.
)
pause
