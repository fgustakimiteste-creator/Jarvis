@echo off
setlocal
cd /d "%~dp0"
if not exist .venv (
  where py >nul 2>nul
  if not errorlevel 1 (
    py -3.12 -m venv .venv
    if errorlevel 1 py -3.11 -m venv .venv
  ) else (
    python -c "import sys; assert sys.version_info[:2] in ((3,11),(3,12)), 'Use Python 3.11 ou 3.12'" >nul 2>nul
    if errorlevel 1 (
      echo Instale Python 3.11 ou 3.12. O Python 3.14 pode ter incompatibilidade com dependencias.
      pause
      exit /b 1
    )
    python -m venv .venv
  )
  if errorlevel 1 (
    echo Nao foi possivel criar o ambiente Python recomendado.
    echo Instale Python 3.11 ou 3.12 e tente novamente.
    pause
    exit /b 1
  )
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
python -m app.main
pause
