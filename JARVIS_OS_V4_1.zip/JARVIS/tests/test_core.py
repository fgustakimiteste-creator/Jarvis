from __future__ import annotations

import ipaddress

import pytest

from app import platform_tools, network_tools, web_tools, agent


def test_open_website_rejects_non_http_schemes():
    with pytest.raises(ValueError):
        platform_tools.open_website("javascript:alert(1)")
    with pytest.raises(ValueError):
        platform_tools.open_website("file:///etc/passwd")


def test_open_website_rejects_embedded_credentials():
    with pytest.raises(ValueError):
        platform_tools.open_website("https://user:password@example.com")


def test_search_command_delegates_to_safe_search(monkeypatch):
    seen = {}
    monkeypatch.setattr(platform_tools, "search_web", lambda query: seen.setdefault("query", query) or "ok")
    result = platform_tools.handle_local_command("Jarvis, pesquise inteligência artificial")
    assert result == "inteligência artificial"
    assert seen["query"] == "inteligência artificial"


def test_unknown_text_is_not_executed_as_a_command():
    assert platform_tools.handle_local_command("execute rm -rf /") is None


def test_app_allowlist_rejects_arbitrary_program(monkeypatch):
    monkeypatch.setattr(platform_tools, "is_termux", lambda: False)
    result = platform_tools.open_application("powershell com parâmetros")
    assert "lista segura" in result


def test_known_site_command_accepts_article_and_does_not_shell(monkeypatch):
    seen = {}
    monkeypatch.setattr(platform_tools, "open_website", lambda url: seen.setdefault("url", url) or "ok")
    result = platform_tools.handle_local_command("Jarvis, abra o YouTube")
    assert result == "https://www.youtube.com"
    assert seen["url"] == "https://www.youtube.com"


def test_unknown_application_is_rejected_without_launching(monkeypatch):
    monkeypatch.setattr(platform_tools, "is_termux", lambda: False)
    result = platform_tools.handle_local_command("Jarvis, abra o PowerShell")
    assert result is None


def test_web_agent_detects_explicit_search_intent():
    assert agent._search_query("Jarvis, pesquise na internet segurança de roteadores") == "segurança de roteadores"
    assert agent._search_query("busque sobre astronomia") == "astronomia"
    assert agent._search_query("converse comigo") is None


def test_web_agent_detects_public_page_read_request():
    assert agent._page_url("Leia esta página https://example.com/artigo") == "https://example.com/artigo"
    assert agent._page_url("Abra o YouTube") is None


def test_web_reader_rejects_private_and_local_addresses(monkeypatch):
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://127.0.0.1:8787")
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://192.168.1.1")
    with pytest.raises(ValueError):
        web_tools._assert_public_url("http://router.local")


def test_search_url_unwrap_only_keeps_http_targets():
    assert web_tools._unwrap_search_url("https://example.com/path") == "https://example.com/path"
    assert web_tools._unwrap_search_url("javascript:alert(1)") == ""


def test_network_port_scan_requires_host_from_last_private_scan(monkeypatch):
    monkeypatch.setattr(network_tools, "_LAST_SCAN", {
        "cidr": "192.168.1.0/24",
        "devices": [{"ip": "192.168.1.25", "is_self": False}],
    })
    with pytest.raises(ValueError):
        network_tools.scan_device_ports("8.8.8.8")
    with pytest.raises(ValueError):
        network_tools.scan_device_ports("192.168.1.26")


def test_network_port_scan_checks_only_fixed_common_ports(monkeypatch):
    monkeypatch.setattr(network_tools, "_LAST_SCAN", {
        "cidr": "192.168.1.0/24",
        "devices": [{"ip": "192.168.1.25", "is_self": False}],
    })
    calls = []
    class FakeSocket:
        def settimeout(self, _): pass
        def connect_ex(self, target): calls.append(target); return 1
        def close(self): pass
    monkeypatch.setattr(network_tools.socket, "socket", lambda *_: FakeSocket())
    result = network_tools.scan_device_ports("192.168.1.25")
    assert calls
    assert set(port for _, port in calls) == set(network_tools.COMMON_PORTS)
    assert result["open_ports"] == []


def test_memory_crud_helpers(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from app import database
    monkeypatch.setattr(database, "settings", SimpleNamespace(database_path=tmp_path / "test.db"))
    database.init_db()
    memory_id = database.save_memory("Prefiro respostas diretas")
    assert database.delete_memory(memory_id) is True
    assert database.delete_memory(memory_id) is False
    database.save_memory("Outra memória")
    database.clear_memories()
    assert database.list_memories() == []


def test_local_network_scan_builds_inventory_from_lan_only(monkeypatch):
    async def fake_ping(ip, semaphore):
        return ip == "192.168.50.20"
    monkeypatch.setattr(network_tools, "get_network_context", lambda: {
        "interface": "wlan0", "ip": "192.168.50.10", "cidr": "192.168.50.0/24", "gateway": "192.168.50.1", "router_url": "http://192.168.50.1"
    })
    monkeypatch.setattr(network_tools, "_arp_table", lambda: {"192.168.50.30": "aa:bb:cc:dd:ee:ff"})
    monkeypatch.setattr(network_tools, "_ping", fake_ping)
    import asyncio
    result = asyncio.run(network_tools.scan_local_network())
    ips = {device["ip"] for device in result["devices"]}
    assert "192.168.50.10" in ips
    assert "192.168.50.20" in ips
    assert "192.168.50.30" in ips
    assert result["cidr"] == "192.168.50.0/24"


def test_search_parser_handles_relative_duckduckgo_result_links():
    from urllib.parse import quote
    target = "https://example.org/article"
    relative = "/l/?uddg=" + quote(target, safe="")
    assert web_tools._unwrap_search_url(relative) == target


def test_public_page_parser_removes_navigation_and_script_text():
    parser = web_tools._TextParser()
    parser.feed("<html><head><title>Title</title><script>secret_code()</script></head><body><nav>Menu</nav><h1>Heading</h1><p>Visible article text</p></body></html>")
    parsed = " ".join(parser.parts)
    assert "Visible article text" in parsed
    assert "secret_code" not in parsed
    assert "Menu" not in parsed


def test_explicit_disconnect_request_never_claims_device_was_blocked(monkeypatch):
    from app import agent
    monkeypatch.setattr(agent, "add_message", lambda *args: None)
    monkeypatch.setattr(agent, "get_network_context", lambda: {"gateway": "192.168.1.1"})
    reply, mode, payload = agent.process_user_message("Jarvis, desconecte o aparelho 192.168.1.25 do Wi-Fi")
    assert mode == "local"
    assert payload is None
    assert "Nenhum dispositivo foi desconectado" in reply
    assert "192.168.1.1" in reply
