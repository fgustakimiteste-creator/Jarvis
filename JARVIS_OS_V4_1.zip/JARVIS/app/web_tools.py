from __future__ import annotations

import html
import ipaddress
import re
import socket
from html.parser import HTMLParser
from urllib.parse import parse_qs, quote_plus, unquote, urljoin, urlparse

import httpx

USER_AGENT = "JARVIS-OS/4.1 (personal assistant; public web lookup)"


class _SearchParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.results: list[dict[str, str]] = []
        self._active = False
        self._title = ""
        self._href = ""
        self._snippet = ""
        self._in_snippet = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        classes = (values.get("class") or "").split()
        if tag == "a" and "result__a" in classes:
            self._active, self._title = True, ""
            self._href = values.get("href") or ""
        if "result__snippet" in classes:
            self._in_snippet = True
            self._snippet = ""

    def handle_data(self, data: str) -> None:
        if self._active:
            self._title += data
        if self._in_snippet:
            self._snippet += data

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self._active:
            self._active = False
            href = _unwrap_search_url(self._href)
            if self._title.strip() and href:
                self.results.append({"title": html.unescape(self._title).strip(), "url": href, "snippet": ""})
        if self._in_snippet and tag in {"div", "td"}:
            self._in_snippet = False
            snippet = re.sub(r"\s+", " ", html.unescape(self._snippet)).strip()
            for item in self.results[-1:]:
                if not item["snippet"]:
                    item["snippet"] = snippet[:500]


def _unwrap_search_url(href: str) -> str:
    value = html.unescape(href.strip())
    if value.startswith("/"):
        value = urljoin("https://duckduckgo.com", value)
    parsed = urlparse(value)
    if parsed.hostname and "duckduckgo.com" in parsed.hostname:
        query = parse_qs(parsed.query)
        value = query.get("uddg", [""])[0]
    value = unquote(value)
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return ""
    return value


def _assert_public_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Só posso consultar endereços públicos HTTP ou HTTPS.")
    host = parsed.hostname.rstrip(".").lower()
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal", ".lan", ".home")):
        raise ValueError("Por segurança, a navegação do agente não acessa endereços locais ou internos.")
    try:
        addresses = [ipaddress.ip_address(host)]
    except ValueError:
        try:
            resolved = socket.getaddrinfo(host, parsed.port or (443 if parsed.scheme == "https" else 80), type=socket.SOCK_STREAM)
        except OSError as exc:
            raise ValueError("Não consegui localizar o endereço informado.") from exc
        addresses = []
        for row in resolved:
            try:
                addresses.append(ipaddress.ip_address(row[4][0].split("%", 1)[0]))
            except ValueError:
                continue
    if not addresses or any(not addr.is_global for addr in addresses):
        raise ValueError("Por segurança, o agente só consulta sites públicos. Endereços privados, locais ou reservados são bloqueados.")
    return url


def _fetch_public(url: str, max_bytes: int = 1_500_000) -> tuple[str, str, str]:
    current = _assert_public_url(url)
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.1"}
    with httpx.Client(timeout=12.0, follow_redirects=False, headers=headers) as client:
        for _ in range(6):
            current = _assert_public_url(current)
            response = client.get(current)
            if response.status_code in {301, 302, 303, 307, 308}:
                location = response.headers.get("location")
                if not location:
                    raise ValueError("O site enviou um redirecionamento sem destino.")
                current = urljoin(current, location)
                continue
            response.raise_for_status()
            content_type = response.headers.get("content-type", "")
            if not any(kind in content_type for kind in ("text/html", "text/plain", "application/xhtml")):
                raise ValueError("Esse tipo de arquivo não é exibido pelo leitor de páginas do JARVIS.")
            content = response.content[:max_bytes].decode(response.encoding or "utf-8", errors="replace")
            return current, content_type, content
    raise ValueError("O site excedeu o limite de redirecionamentos.")


class _TextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.title = ""
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript", "svg", "nav", "footer", "header", "form"}:
            self._skip += 1
        if tag == "title":
            self._in_title = True
        if tag in {"p", "div", "br", "h1", "h2", "h3", "li", "article", "section"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript", "svg", "nav", "footer", "header", "form"} and self._skip:
            self._skip -= 1
        if tag == "title":
            self._in_title = False

    def handle_data(self, data: str) -> None:
        clean = re.sub(r"\s+", " ", data).strip()
        if not clean:
            return
        if self._in_title:
            self.title += clean + " "
        if not self._skip:
            self.parts.append(clean)


def search_public_web(query: str, limit: int = 7) -> dict[str, object]:
    clean = " ".join(query.split()).strip()
    if len(clean) < 2:
        raise ValueError("Digite o que devo pesquisar na internet.")
    url = "https://html.duckduckgo.com/html/?q=" + quote_plus(clean)
    _, _, content = _fetch_public(url, max_bytes=2_000_000)
    parser = _SearchParser()
    parser.feed(content)
    # Remove duplicate URLs and cap results.
    dedup: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in parser.results:
        if item["url"] not in seen:
            seen.add(item["url"])
            dedup.append(item)
        if len(dedup) >= max(1, min(limit, 10)):
            break
    return {"query": clean, "results": dedup, "count": len(dedup)}


def read_public_page(url: str) -> dict[str, str]:
    final_url, content_type, content = _fetch_public(url)
    if "text/plain" in content_type:
        text = content
        title = urlparse(final_url).hostname or "Página"
    else:
        parser = _TextParser()
        parser.feed(content)
        title = parser.title.strip() or (urlparse(final_url).hostname or "Página")
        text = " ".join(" ".join(parser.parts).split())
    return {"url": final_url, "title": title[:250], "text": text[:16000]}
