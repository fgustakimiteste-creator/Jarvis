from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


def _connect() -> sqlite3.Connection:
    settings.database_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(settings.database_path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    with _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(id DESC);
            CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(id DESC);
            """
        )


def add_message(role: str, content: str) -> None:
    if role not in {"user", "assistant"}:
        raise ValueError("Papel de mensagem inválido")
    with _connect() as conn:
        conn.execute(
            "INSERT INTO messages(role, content, created_at) VALUES (?, ?, ?)",
            (role, content[:12000], datetime.now(timezone.utc).isoformat()),
        )


def recent_messages(limit: int = 16) -> list[dict[str, str]]:
    limit = max(1, min(int(limit), 40))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT role, content, created_at FROM messages ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in reversed(rows)]


def save_memory(content: str) -> int:
    clean = " ".join(content.strip().split())
    if not clean:
        raise ValueError("A memória não pode ficar vazia")
    with _connect() as conn:
        cursor = conn.execute(
            "INSERT INTO memories(content, created_at) VALUES (?, ?)",
            (clean[:2000], datetime.now(timezone.utc).isoformat()),
        )
        return int(cursor.lastrowid)


def list_memories(limit: int = 30) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 100))
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, content, created_at FROM memories ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def relevant_memories(query: str, limit: int = 6) -> list[str]:
    """Small, dependency-free memory retrieval using word overlap."""
    memories = list_memories(100)
    words = {w.lower() for w in query.split() if len(w) > 3}
    scored: list[tuple[int, int, str]] = []
    for item in memories:
        text = item["content"]
        content_words = {w.lower().strip(".,!?;:") for w in text.split() if len(w) > 3}
        score = len(words & content_words)
        if score:
            scored.append((score, item["id"], text))
    scored.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)
    if not scored:
        return [item["content"] for item in memories[: min(3, limit)]]
    return [entry[2] for entry in scored[:limit]]


def clear_conversation() -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM messages")


def delete_memory(memory_id: int) -> bool:
    with _connect() as conn:
        cursor = conn.execute("DELETE FROM memories WHERE id = ?", (int(memory_id),))
        return cursor.rowcount > 0


def clear_memories() -> None:
    with _connect() as conn:
        conn.execute("DELETE FROM memories")
