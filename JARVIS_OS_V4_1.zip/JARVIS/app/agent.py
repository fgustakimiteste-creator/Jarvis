from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

from .assistant import ask_gemini
from .config import settings
from .database import add_message
from .network_tools import scan_local_network, get_network_context
from .platform_tools import handle_local_command, open_website
from .web_tools import read_public_page, search_public_web


def _search_query(message: str) -> str | None:
    patterns = [
        r"^(?:jarvis[, ]*)?(?:pesquise|pesquisar|pesquisa|busque|procure)(?:\s+na\s+internet|\s+na\s+web)?\s+(?:sobre\s+)?(.+)$",
        r"^(?:jarvis[, ]*)?(?:encontre|localize)\s+(?:na\s+internet|na\s+web)\s+(.+)$",
    ]
    for pattern in patterns:
        match = re.match(pattern, message.strip(), re.I)
        if match:
            return match.group(1).strip()
    return None


def _page_url(message: str) -> str | None:
    match = re.search(r"https?://[^\s]+", message, re.I)
    if match and re.search(r"\b(leia|resuma|analise|analisa|explique|abra a página|leia a página)\b", message, re.I):
        return match.group(0).rstrip(".,);]")
    return None


def _network_requested(message: str) -> bool:
    lower = message.lower()
    return any(term in lower for term in (
        "escaneie minha rede", "escaneia minha rede", "varra minha rede", "verifique minha rede",
        "quem está conectado", "quem esta conectado", "quem está no wi-fi", "quem esta no wi-fi",
        "dispositivos conectados", "scan na rede", "scanner de rede", "escaneie o wi-fi", "escaneia o wi-fi"
    ))


def _format_scan(scan: dict[str, Any]) -> str:
    rows = [f"Encontrei {scan['device_count']} dispositivo(s) na rede {scan['cidr']}.", f"Interface: {scan['interface']} · IP deste dispositivo: {scan['ip']}"]
    if scan.get("gateway"):
        rows.append(f"Roteador/gateway: {scan['gateway']}")
    for device in scan["devices"][:40]:
        mac = f" · MAC {device['mac']}" if device.get("mac") else ""
        rows.append(f"• {device['ip']} — {device['name']} — {device['status']}{mac}")
    rows.append("A varredura é de descoberta local. Faça a gestão de acesso pelo painel do seu próprio roteador; o JARVIS não derruba dispositivos com ataques Wi-Fi.")
    return "\n".join(rows)


def process_user_message(message: str) -> tuple[str, str, dict[str, Any] | None]:
    """Route clear tool intents first; fall back to local commands and Gemini chat."""
    add_message("user", message)
    try:
        if _network_requested(message):
            scan = __import__("asyncio").run(scan_local_network())
            answer = _format_scan(scan)
            mode = "network"
            payload = {"network": scan}
        elif re.search(r"^(?:jarvis[, ]*)?(?:por favor[, ]*)?(?:desconecte|desconectar|bloqueie|bloquear|pause(?: a internet)?|tire do wi-?fi)\b", message.strip(), re.I):
            try:
                context = get_network_context()
                gateway_note = f" O painel do roteador deve estar em http://{context['gateway']}." if context.get("gateway") else ""
            except Exception:
                gateway_note = ""
            answer = ("Ainda não posso bloquear ou desconectar um aparelho diretamente: isso depende de uma integração compatível com a marca/modelo do seu roteador e da sua autorização administrativa. "
                      "Nenhum dispositivo foi desconectado. Abra o painel do roteador e use a função de controle de acesso." + gateway_note)
            mode, payload = "local", None
        else:
            query = _search_query(message)
            page_url = _page_url(message)
            if query:
                result = search_public_web(query)
                if result["results"]:
                    context = "\n".join(f"Título: {r['title']}\nURL: {r['url']}\nResumo: {r['snippet']}" for r in result["results"])
                    if settings.gemini_api_key:
                        answer = ask_gemini(message, extra_context="RESULTADOS ATUAIS DA PESQUISA PÚBLICA:\n" + context)
                    else:
                        answer = "Encontrei estes resultados. Configure GEMINI_API_KEY para receber um resumo gerado pela IA:\n\n" + "\n\n".join(f"{i+1}. {r['title']}\n{r['snippet']}\n{r['url']}" for i, r in enumerate(result["results"][:6]))
                    answer += "\n\nFontes encontradas:\n" + "\n".join(f"• {r['title']} — {r['url']}" for r in result["results"][:6])
                else:
                    answer = "Não encontrei resultados nessa pesquisa. Tente reformular os termos."
                mode, payload = "web", {"search": result}
            elif page_url:
                page = read_public_page(page_url)
                if settings.gemini_api_key:
                    answer = ask_gemini(message, extra_context=f"CONTEÚDO DA PÁGINA PÚBLICA\nTítulo: {page['title']}\nURL: {page['url']}\nConteúdo:\n{page['text']}")
                else:
                    answer = f"Consegui extrair o texto de **{page['title']}**, mas preciso de GEMINI_API_KEY para gerar um resumo.\n\n{page['text'][:1800]}"
                answer += f"\n\nPágina consultada: {page['url']}"
                mode, payload = "web", {"page": {"title": page["title"], "url": page["url"]}}
            else:
                answer = handle_local_command(message)
                mode, payload = ("local", None) if answer is not None else ("ai", None)
                if answer is None:
                    answer = ask_gemini(message)
        add_message("assistant", answer)
        return answer, mode, payload
    except (ValueError, RuntimeError) as exc:
        answer = str(exc)
        add_message("assistant", answer)
        return answer, "local", None
    except Exception as exc:
        answer = f"Não consegui concluir essa ação ({type(exc).__name__}). Verifique sua conexão e tente novamente."
        add_message("assistant", answer)
        return answer, "error", None
