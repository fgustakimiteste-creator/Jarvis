from __future__ import annotations

import hmac
import ipaddress
import logging
import webbrowser
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .agent import process_user_message
from .config import ROOT_DIR, settings
from .database import add_message, clear_conversation, delete_memory, init_db, list_memories, recent_messages, save_memory
from .network_tools import get_last_scan, get_network_context, scan_device_ports, scan_local_network
from .platform_tools import open_website
from .web_tools import read_public_page, search_public_web

logging.basicConfig(level=logging.INFO, format="%(asctime)s | JARVIS | %(levelname)s | %(message)s")
logger = logging.getLogger("jarvis")
app = FastAPI(title="JARVIS OS", version="4.1.0", docs_url="/api/docs")
STATIC_DIR = ROOT_DIR / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


class MemoryRequest(BaseModel):
    content: str = Field(min_length=1, max_length=2000)


class SearchRequest(BaseModel):
    query: str = Field(min_length=2, max_length=400)


class ReadRequest(BaseModel):
    url: str = Field(min_length=8, max_length=2000)


class PortScanRequest(BaseModel):
    ip: str = Field(min_length=7, max_length=45)


class RouterBlockRequest(BaseModel):
    ip: str = Field(min_length=7, max_length=45)
    confirm: bool = False


def require_token(x_jarvis_token: str | None = Header(default=None)) -> None:
    configured = settings.api_token
    if configured and not hmac.compare_digest(x_jarvis_token or "", configured):
        raise HTTPException(status_code=401, detail="Token do JARVIS ausente ou incorreto.")


@app.on_event("startup")
def startup() -> None:
    init_db()
    logger.info("Banco de dados inicializado em %s", settings.database_path)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/status")
def status(_: None = Depends(require_token)) -> dict[str, Any]:
    try:
        context = get_network_context()
        network_available = True
    except Exception:
        context, network_available = {}, False
    return {
        "ok": True, "name": "JARVIS", "version": app.version,
        "ai_configured": bool(settings.gemini_api_key),
        "model": settings.gemini_model if settings.gemini_api_key else None,
        "token_required": bool(settings.api_token), "voice_reply_default": settings.voice_reply_default,
        "platform": __import__("platform").platform(), "network_available": network_available,
        "network": context,
        "router_control": False,
        "features": {"chat": True, "memory": True, "voice_browser": True, "public_web_search": True,
                     "public_page_reader": True, "local_network_discovery": network_available,
                     "lan_port_diagnostics": True, "router_blocking": False}
    }


@app.get("/api/history")
def history(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"messages": recent_messages(80)}


@app.delete("/api/history")
def delete_history(_: None = Depends(require_token)) -> dict[str, bool]:
    clear_conversation()
    return {"ok": True}


@app.get("/api/memories")
def memories(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"memories": list_memories(100)}


@app.post("/api/memories")
def create_memory(payload: MemoryRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    memory_id = save_memory(payload.content)
    return {"ok": True, "id": memory_id, "message": "Memória salva."}


@app.delete("/api/memories/{memory_id}")
def remove_memory(memory_id: int, _: None = Depends(require_token)) -> dict[str, bool]:
    return {"ok": delete_memory(memory_id)}


@app.delete("/api/memories")
def remove_all_memories(_: None = Depends(require_token)) -> dict[str, bool]:
    from .database import clear_memories
    clear_memories()
    return {"ok": True}


@app.post("/api/chat")
def chat(payload: ChatRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    answer, mode, data = process_user_message(payload.message.strip())
    return {"reply": answer, "mode": mode, "data": data}


@app.get("/api/network/overview")
def network_overview(_: None = Depends(require_token)) -> dict[str, Any]:
    try:
        context = get_network_context()
        return {"ok": True, **context, "last_scan": get_last_scan()}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/network/scan")
async def network_scan(_: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return await scan_local_network()
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/api/network/ports")
def network_ports(payload: PortScanRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return scan_device_ports(payload.ip)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/network/block")
def network_block(payload: RouterBlockRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    if not payload.confirm:
        raise HTTPException(status_code=400, detail="A ação exige confirmação explícita.")
    # No universal router API exists. Never pretend that changing the PC's firewall blocks another LAN client.
    raise HTTPException(status_code=501, detail=(
        "Bloqueio real não está habilitado: cada roteador usa uma API diferente. "
        "O dispositivo não foi desconectado. Abra o painel do seu roteador e gerencie o acesso por lá."
    ))


@app.post("/api/network/router-panel")
def router_panel(_: None = Depends(require_token)) -> dict[str, Any]:
    try:
        context = get_network_context()
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    gateway = context.get("gateway")
    if not gateway:
        raise HTTPException(status_code=404, detail="Não consegui identificar o gateway do roteador.")
    url = f"http://{gateway}"
    opened = open_website(url)
    return {"ok": True, "url": url, "message": opened}


@app.post("/api/web/search")
def web_search(payload: SearchRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return search_public_web(payload.query)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Pesquisa web falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="Não consegui consultar a pesquisa pública. Verifique a conexão.")


@app.post("/api/web/read")
def web_read(payload: ReadRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    try:
        return read_public_page(payload.url)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.warning("Leitura de página falhou: %s", type(exc).__name__)
        raise HTTPException(status_code=502, detail="Não consegui abrir o conteúdo desse site.")


@app.post("/api/web/open")
def web_open(payload: ReadRequest, _: None = Depends(require_token)) -> dict[str, Any]:
    # Open only a URL explicitly supplied by the user from the server device.
    parsed = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(payload.url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Use um endereço público HTTP ou HTTPS.")
    return {"ok": True, "message": open_website(payload.url)}


if __name__ == "__main__":
    import ipaddress
    import uvicorn
    host = settings.host
    try:
        is_loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        is_loopback = host.lower() == "localhost"
    if not is_loopback and not settings.api_token:
        raise SystemExit("SEGURANÇA: ao expor o JARVIS na rede local, configure JARVIS_TOKEN no .env antes de iniciar.")
    uvicorn.run("app.main:app", host=host, port=settings.port, reload=False)
