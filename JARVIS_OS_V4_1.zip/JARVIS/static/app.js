(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = {
    sending: false,
    scanning: false,
    voiceReply: localStorage.getItem('jarvisVoiceReply') === 'true',
    recognition: null,
    accessToken: sessionStorage.getItem('jarvisToken') || '',
    network: null,
    memories: [],
    currentPage: 'dashboard',
    monitorTimer: null,
    previousDeviceIps: null,
  };

  function showToast(message) {
    const toast = $('toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('show'), 3000);
  }

  function setMode(value) { $('modeLabel').textContent = String(value || 'AGUARDANDO COMANDO').toUpperCase(); }

  async function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (!(options.body instanceof FormData) && options.method && options.method !== 'GET') headers.set('Content-Type', 'application/json');
    if (state.accessToken) headers.set('X-Jarvis-Token', state.accessToken);
    const response = await fetch(path, { ...options, headers });
    if (response.status === 401) {
      state.accessToken = '';
      sessionStorage.removeItem('jarvisToken');
      throw new Error('TOKEN_REQUIRED');
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || `Erro HTTP ${response.status}`);
    return data;
  }

  async function ensureAccess() {
    try { await api('/api/status'); return true; }
    catch (error) {
      if (error.message !== 'TOKEN_REQUIRED') throw error;
      const token = window.prompt('Este JARVIS exige um token. Informe o JARVIS_TOKEN configurado no computador:');
      if (!token) return false;
      state.accessToken = token.trim();
      sessionStorage.setItem('jarvisToken', state.accessToken);
      try { await api('/api/status'); return true; }
      catch { state.accessToken = ''; sessionStorage.removeItem('jarvisToken'); showToast('Token incorreto.'); return false; }
    }
  }

  function navigate(page) {
    const allowed = ['dashboard', 'assistant', 'network', 'web', 'memory', 'settings'];
    if (!allowed.includes(page)) return;
    state.currentPage = page;
    document.querySelectorAll('.page').forEach(el => el.classList.toggle('active', el.id === `page-${page}`));
    document.querySelectorAll('[data-page]').forEach(el => el.classList.toggle('active', el.dataset.page === page));
    $('pageScroll').scrollTop = 0;
    if (page === 'network') loadNetworkOverview();
    if (page === 'memory') loadMemories();
    if (page === 'assistant') loadHistory();
  }

  function addMessage(role, text) {
    $('welcome').hidden = true;
    const row = document.createElement('article'); row.className = `message ${role}`;
    const avatar = document.createElement('div'); avatar.className = 'avatar'; avatar.textContent = role === 'assistant' ? 'J' : 'EU';
    const wrap = document.createElement('div'); wrap.className = 'bubble-wrap';
    const label = document.createElement('div'); label.className = 'bubble-label'; label.textContent = role === 'assistant' ? 'JARVIS' : 'VOCÊ';
    const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text;
    wrap.append(label, bubble); row.append(avatar, wrap); $('messages').append(row);
    $('conversation').scrollTop = $('conversation').scrollHeight;
    return row;
  }

  function showTyping() {
    const row = addMessage('assistant', ''); row.classList.add('typing');
    const bubble = row.querySelector('.bubble'); bubble.textContent = 'Processando •••';
    return row;
  }

  function speak(text) {
    if (!state.voiceReply || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(String(text).replace(/https?:\/\/\S+/g, 'link'));
    utterance.lang = 'pt-BR'; utterance.rate = 1.02; utterance.pitch = .94;
    window.speechSynthesis.speak(utterance);
  }

  function updateVoiceUI() {
    $('voiceToggle').style.color = state.voiceReply ? 'var(--cyan)' : '';
    $('voiceSetting').setAttribute('aria-pressed', String(state.voiceReply));
  }

  async function send(textOverride) {
    const input = $('messageInput');
    const message = String(textOverride ?? input.value).trim();
    if (!message || state.sending) return;
    input.value = ''; input.style.height = 'auto';
    addMessage('user', message);
    state.sending = true; $('sendButton').disabled = true; setMode('PROCESSANDO');
    const typing = showTyping();
    try {
      const result = await api('/api/chat', { method: 'POST', body: JSON.stringify({ message }) });
      typing.remove();
      addMessage('assistant', result.reply || 'Não recebi uma resposta.');
      const labels = { local: 'COMANDO LOCAL', ai: 'RESPOSTA DA IA', web: 'AGENTE WEB', network: 'SCANNER DE REDE', error: 'FALHA' };
      setMode(labels[result.mode] || 'CONCLUÍDO');
      if (result.data?.network) { state.network = result.data.network; renderNetwork(state.network); }
      if (result.data?.search) { renderWebResults(result.data.search); $('searchCount').textContent = `${result.data.search.count} RESULTADOS`; }
      speak(result.reply || '');
    } catch (error) {
      typing.remove();
      if (error.message === 'TOKEN_REQUIRED') addMessage('assistant', 'Acesso protegido. Abra Configurações e informe o token do servidor.');
      else addMessage('assistant', `Não consegui concluir: ${error.message}`);
      setMode('FALHA DE CONEXÃO');
    } finally {
      state.sending = false; $('sendButton').disabled = false; input.focus(); $('conversation').scrollTop = $('conversation').scrollHeight;
    }
  }

  async function loadHistory() {
    if ($('messages').dataset.loaded === 'true') return;
    try {
      const data = await api('/api/history');
      if (data.messages?.length) data.messages.forEach(item => addMessage(item.role === 'assistant' ? 'assistant' : 'user', item.content));
      $('messages').dataset.loaded = 'true';
    } catch (error) { if (error.message !== 'TOKEN_REQUIRED') console.warn(error); }
  }

  async function checkStatus() {
    try {
      const status = await api('/api/status');
      $('connectionText').textContent = 'NÚCLEO CONECTADO';
      $('sidePulse').style.background = 'var(--mint)';
      $('aiState').textContent = status.ai_configured ? `Gemini · ${status.model}` : 'Modo local · IA não configurada';
      $('dashAi').textContent = status.ai_configured ? 'Conectado' : 'Modo local';
      $('dashAi').className = status.ai_configured ? 'good' : 'warn';
      $('dashNetwork').textContent = status.network_available ? 'Interface detectada' : 'Não detectada';
      $('systemPill').innerHTML = '<i></i> Núcleo ativo';
      $('systemPill').style.color = 'var(--mint)';
      $('chatModel').textContent = status.ai_configured ? status.model.toUpperCase() : 'LOCAL MODE';
      $('authState').textContent = status.token_required ? 'Token obrigatório' : 'Somente local';
      $('authState').className = status.token_required ? 'warn' : 'good';
      if (status.network) {
        state.network = { ...status.network };
        $('networkCidr').textContent = status.network.cidr || '—';
        $('networkInterface').textContent = status.network.interface || 'Interface não identificada';
        $('networkGateway').textContent = status.network.gateway || '—';
        $('routerAddress').textContent = status.network.gateway ? `http://${status.network.gateway}` : 'Gateway ainda não identificado';
      }
      $('dashNetwork').textContent = status.network_available ? (status.network?.cidr || 'Disponível') : 'Não detectada';
      $('dashVoice').textContent = ('speechSynthesis' in window) ? 'Disponível no navegador' : 'Não suportada';
    } catch (error) {
      $('connectionText').textContent = error.message === 'TOKEN_REQUIRED' ? 'ACESSO PROTEGIDO' : 'NÚCLEO INDISPONÍVEL';
      $('aiState').textContent = 'Aguardando conexão';
      $('systemPill').textContent = 'Sem conexão';
      $('systemPill').style.color = 'var(--amber)';
      if (error.message !== 'TOKEN_REQUIRED') showToast('Não foi possível conectar ao núcleo.');
    }
  }

  function renderNetwork(data) {
    if (!data) return;
    state.network = data;
    $('deviceCount').textContent = data.device_count ?? data.devices?.length ?? '—';
    $('networkCidr').textContent = data.cidr || '—';
    $('networkInterface').textContent = `${data.interface || 'Interface'} · IP ${data.ip || '—'}`;
    $('networkGateway').textContent = data.gateway || '—';
    $('routerAddress').textContent = data.gateway ? `http://${data.gateway}` : 'Gateway ainda não identificado';
    $('networkScanTime').textContent = data.scanned_at ? new Date(data.scanned_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '—';
    $('networkScanStatus').textContent = data.scanned_at ? 'Varredura concluída' : 'Aguardando primeira execução';
    $('networkNote').textContent = data.scan_note || 'A varredura usa ping e a tabela ARP do dispositivo que executa o JARVIS.';
    $('networkIndicator').style.display = 'block';
    const rows = $('deviceRows'); rows.replaceChildren();
    const filter = $('deviceFilter').value.trim().toLowerCase();
    const devices = (data.devices || []).filter(item => `${item.ip} ${item.mac} ${item.name}`.toLowerCase().includes(filter));
    if (!devices.length) {
      const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 5; td.className = 'empty-row'; td.textContent = 'Nenhum dispositivo corresponde ao filtro.'; tr.append(td); rows.append(tr);
    }
    devices.forEach((device, index) => {
      const tr = document.createElement('tr');
      const name = document.createElement('td'); name.innerHTML = '<div class="device-name"><span class="device-glyph">⌘</span><span><b></b><small></small></span></div>';
      name.querySelector('b').textContent = device.is_self ? 'Este dispositivo' : `Dispositivo ${index}`;
      name.querySelector('small').textContent = device.is_self ? 'HOST JARVIS' : 'HOST DESCOBERTO';
      const ip = document.createElement('td'); ip.textContent = device.ip;
      const mac = document.createElement('td'); mac.textContent = device.mac || 'Não identificado';
      const status = document.createElement('td'); const dot = document.createElement('span'); dot.className = `state-dot${device.status === 'Online' || device.is_self ? '' : ' maybe'}`; status.append(dot, document.createTextNode(device.status || 'Visto'));
      const action = document.createElement('td');
      if (!device.is_self) {
        const button = document.createElement('button'); button.className = 'device-action'; button.textContent = 'Portas'; button.dataset.ports = device.ip; action.append(button);
        const manage = document.createElement('button'); manage.className = 'device-action'; manage.textContent = 'Roteador'; manage.style.marginLeft = '5px'; manage.addEventListener('click', openRouterPanel); action.append(manage);
      } else action.textContent = '—';
      tr.append(name, ip, mac, status, action); rows.append(tr);
    });
    const select = $('portTarget'); const selected = select.value; select.replaceChildren();
    const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Selecione um dispositivo...'; select.append(placeholder);
    (data.devices || []).filter(device => !device.is_self).forEach(device => {
      const option = document.createElement('option'); option.value = device.ip; option.textContent = `${device.ip}${device.mac ? ` · ${device.mac}` : ''}`; select.append(option);
    });
    if ([...select.options].some(opt => opt.value === selected)) select.value = selected;
  }

  async function loadNetworkOverview() {
    try {
      const overview = await api('/api/network/overview');
      const last = overview.last_scan;
      if (last) renderNetwork(last);
      else {
        $('networkCidr').textContent = overview.cidr || '—';
        $('networkInterface').textContent = `${overview.interface || 'Interface'} · IP ${overview.ip || '—'}`;
        $('networkGateway').textContent = overview.gateway || '—';
        $('routerAddress').textContent = overview.gateway ? `http://${overview.gateway}` : 'Gateway ainda não identificado';
      }
    } catch (error) { $('networkScanStatus').textContent = error.message; }
  }

  async function runNetworkScan(options = {}) {
    if (state.scanning) return;
    state.scanning = true; $('networkScanBtn').disabled = true; $('networkScanBtn').textContent = 'Verificando...'; $('networkScanStatus').textContent = 'Varredura em andamento';
    try {
      const data = await api('/api/network/scan', { method: 'POST' });
      const current = new Set((data.devices || []).map(device => device.ip));
      if (state.previousDeviceIps && options.monitor) {
        const joined = [...current].filter(ip => !state.previousDeviceIps.has(ip));
        const left = [...state.previousDeviceIps].filter(ip => !current.has(ip));
        if (joined.length || left.length) showToast(`Alteração na rede · ${joined.length} entrou(aram), ${left.length} saiu(íram).`);
      }
      state.previousDeviceIps = current;
      renderNetwork(data); if (!options.quiet) showToast(`${data.device_count} dispositivo(s) encontrado(s).`); setMode('REDE VERIFICADA');
    } catch (error) { showToast(error.message); $('networkScanStatus').textContent = 'Falha na varredura'; }
    finally { state.scanning = false; $('networkScanBtn').disabled = false; $('networkScanBtn').innerHTML = '<span class="btn-icon">⌁</span> Iniciar varredura'; }
  }

  function openRouterPanel() {
    const gateway = state.network?.gateway;
    if (!gateway) return showToast('O gateway ainda não foi identificado. Faça uma varredura.');
    window.open(`http://${gateway}`, '_blank', 'noopener,noreferrer');
  }

  function toggleNetworkMonitoring() {
    if (state.monitorTimer) {
      clearInterval(state.monitorTimer); state.monitorTimer = null;
      $('monitorNetworkBtn').textContent = '◉ Monitorar'; showToast('Monitoramento interrompido.'); return;
    }
    if (!state.network?.cidr) return showToast('Faça uma varredura antes de iniciar o monitoramento.');
    state.previousDeviceIps = new Set((state.network.devices || []).map(device => device.ip));
    $('monitorNetworkBtn').textContent = '■ Parar monitoramento';
    showToast('Monitoramento ativo nesta tela: nova verificação a cada 60 segundos.');
    state.monitorTimer = setInterval(() => runNetworkScan({ quiet: true, monitor: true }), 60000);
  }

  function exportNetworkCsv() {
    if (!state.network?.devices?.length) return showToast('Faça uma varredura antes de exportar.');
    const lines = [['IP', 'MAC', 'Nome', 'Estado'], ...state.network.devices.map(d => [d.ip, d.mac || '', d.name || '', d.status || ''])];
    const csv = '\uFEFF' + lines.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(';')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' }); const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url; link.download = 'jarvis-network-inventory.csv'; link.click(); URL.revokeObjectURL(url);
    showToast('Inventário exportado em CSV.');
  }

  async function runPortScan(ip) {
    if (!ip) { showToast('Selecione um dispositivo encontrado na rede.'); return; }
    $('portScanBtn').disabled = true; $('portResults').textContent = `Verificando portas de ${ip}...`;
    try {
      const result = await api('/api/network/ports', { method: 'POST', body: JSON.stringify({ ip }) });
      $('portResults').textContent = result.open_ports.length
        ? `Portas abertas em ${ip}:\n` + result.open_ports.map(p => `• ${p.port}/TCP — ${p.service}`).join('\n')
        : `Nenhuma das ${result.checked_ports.length} portas testadas respondeu em ${ip}. Isso não prova que o dispositivo não tenha outros serviços.`;
    } catch (error) { $('portResults').textContent = error.message; }
    finally { $('portScanBtn').disabled = false; }
  }

  function renderWebResults(data) {
    const container = $('webResults'); container.replaceChildren();
    const results = data.results || [];
    $('searchCount').textContent = `${results.length} RESULTADOS`;
    if (!results.length) {
      const empty = document.createElement('div'); empty.className = 'empty-state'; empty.innerHTML = '<span>⌕</span><b>Nenhum resultado</b><small>Tente outra expressão de pesquisa.</small>'; container.append(empty); return;
    }
    results.forEach(result => {
      const card = document.createElement('article'); card.className = 'web-result';
      const title = document.createElement('h4'); title.textContent = result.title;
      const snippet = document.createElement('p'); snippet.textContent = result.snippet || 'Sem descrição disponível.';
      const url = document.createElement('a'); url.href = result.url; url.textContent = result.url; url.target = '_blank'; url.rel = 'noopener noreferrer';
      const actions = document.createElement('div'); actions.className = 'result-actions';
      const read = document.createElement('button'); read.textContent = 'Ler página'; read.addEventListener('click', () => readPage(result.url));
      const open = document.createElement('button'); open.textContent = 'Abrir no navegador'; open.addEventListener('click', () => { window.open(result.url, '_blank', 'noopener,noreferrer'); });
      actions.append(read, open); card.append(title, snippet, url, actions); container.append(card);
    });
  }

  async function runWebSearch(query) {
    const clean = String(query || '').trim();
    if (!clean) { showToast('Digite o que deseja pesquisar.'); return; }
    $('webResults').innerHTML = '<div class="empty-state"><span>◌</span><b>Pesquisando...</b><small>Consultando a pesquisa pública.</small></div>';
    $('searchCount').textContent = 'PESQUISANDO';
    try {
      const result = await api('/api/web/search', { method: 'POST', body: JSON.stringify({ query: clean }) });
      renderWebResults(result); showToast(`${result.count} resultado(s) carregado(s).`);
    } catch (error) { $('webResults').textContent = error.message; $('searchCount').textContent = 'ERRO'; }
  }

  async function readPage(url) {
    $('pageContent').textContent = 'Lendo página pública...';
    try {
      const page = await api('/api/web/read', { method: 'POST', body: JSON.stringify({ url }) });
      $('pageUrl').value = page.url;
      const heading = document.createElement('h4'); heading.textContent = page.title;
      const body = document.createElement('div'); body.textContent = page.text;
      $('pageContent').replaceChildren(heading, body);
      navigate('web');
    } catch (error) { $('pageContent').textContent = error.message; }
  }

  async function loadMemories() {
    try {
      const data = await api('/api/memories'); state.memories = data.memories || [];
      renderMemories();
    } catch (error) { $('memoryList').textContent = error.message; }
  }

  function renderMemories() {
    const container = $('memoryList'); container.replaceChildren();
    $('memoryCount').textContent = `${state.memories.length} ITENS`;
    if (!state.memories.length) {
      const empty = document.createElement('div'); empty.className = 'empty-state'; empty.innerHTML = '<span>◈</span><b>Nenhuma memória salva</b><small>Use o formulário ao lado ou diga “Jarvis, lembre que...” no chat.</small>'; container.append(empty); return;
    }
    state.memories.forEach(memory => {
      const item = document.createElement('article'); item.className = 'memory-item';
      const icon = document.createElement('i'); icon.textContent = '◈';
      const body = document.createElement('div'); const text = document.createElement('p'); text.textContent = memory.content;
      const date = document.createElement('small'); date.textContent = memory.created_at ? new Date(memory.created_at).toLocaleString('pt-BR') : `MEMÓRIA #${memory.id}`;
      body.append(text, date);
      const remove = document.createElement('button'); remove.type = 'button'; remove.title = 'Excluir esta memória'; remove.textContent = '×'; remove.addEventListener('click', () => removeMemory(memory.id));
      item.append(icon, body, remove); container.append(item);
    });
  }

  async function removeMemory(id) {
    if (!window.confirm('Excluir esta memória?')) return;
    try { await api(`/api/memories/${id}`, { method: 'DELETE' }); state.memories = state.memories.filter(item => item.id !== id); renderMemories(); showToast('Memória excluída.'); }
    catch (error) { showToast(error.message); }
  }

  function newChat() {
    if (!window.confirm('Apagar o histórico da conversa? As memórias salvas continuarão.')) return;
    api('/api/history', { method: 'DELETE' }).then(() => {
      $('messages').replaceChildren(); $('messages').dataset.loaded = 'true'; $('welcome').hidden = false; showToast('Conversa reiniciada. As memórias foram preservadas.');
    }).catch(error => showToast(error.message));
  }

  function routeAction(action) {
    if (action === 'assistant') navigate('assistant');
    if (action === 'network') navigate('network');
    if (action === 'web') navigate('web');
    if (action === 'memory') navigate('memory');
    if (action === 'scan') { navigate('network'); runNetworkScan(); }
    if (action === 'search') { navigate('web'); $('webQuery').focus(); }
    if (action === 'newchat') { navigate('assistant'); newChat(); }
    if (action === 'status') { navigate('assistant'); send('Jarvis, status do sistema'); }
  }

  function setupSpeech() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      $('micButton').disabled = true; $('micButton').title = 'Reconhecimento de voz não suportado neste navegador';
      $('micButton').addEventListener('click', () => showToast('Use Chrome ou Edge atualizado para usar o microfone.'));
      return;
    }
    state.recognition = new SpeechRecognition(); state.recognition.lang = 'pt-BR'; state.recognition.interimResults = false; state.recognition.continuous = false;
    state.recognition.onstart = () => { $('micButton').classList.add('listening'); showToast('Estou ouvindo...'); };
    state.recognition.onend = () => $('micButton').classList.remove('listening');
    state.recognition.onerror = event => { $('micButton').classList.remove('listening'); showToast(event.error === 'not-allowed' ? 'Permita o microfone no navegador.' : 'Não consegui captar a fala.'); };
    state.recognition.onresult = event => { const phrase = event.results[0][0].transcript; $('messageInput').value = phrase; send(phrase); };
    $('micButton').addEventListener('click', () => { try { state.recognition.start(); } catch { try { state.recognition.stop(); } catch {} } });
  }

  // Navigation
  document.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.page)));
  document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => routeAction(button.dataset.action)));
  document.querySelectorAll('[data-prompt]').forEach(button => button.addEventListener('click', () => { navigate('assistant'); send(button.dataset.prompt); }));

  // Chat
  $('sendButton').addEventListener('click', () => send());
  $('messageInput').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send(); } });
  $('messageInput').addEventListener('input', () => { $('messageInput').style.height = 'auto'; $('messageInput').style.height = Math.min($('messageInput').scrollHeight, 120) + 'px'; });
  $('newChat').addEventListener('click', newChat);

  // Voice
  $('voiceToggle').addEventListener('click', () => { state.voiceReply = !state.voiceReply; localStorage.setItem('jarvisVoiceReply', String(state.voiceReply)); updateVoiceUI(); showToast(state.voiceReply ? 'Respostas faladas ativadas.' : 'Respostas faladas desativadas.'); if (state.voiceReply) speak('Respostas por voz ativadas.'); });
  $('voiceSetting').addEventListener('click', () => { state.voiceReply = !state.voiceReply; localStorage.setItem('jarvisVoiceReply', String(state.voiceReply)); updateVoiceUI(); showToast(state.voiceReply ? 'Respostas faladas ativadas.' : 'Respostas faladas desativadas.'); });
  $('testVoiceBtn').addEventListener('click', () => { if (!('speechSynthesis' in window)) return showToast('Este navegador não oferece síntese de voz.'); const u = new SpeechSynthesisUtterance('Teste de áudio do JARVIS. Sistema de voz pronto.'); u.lang = 'pt-BR'; window.speechSynthesis.speak(u); });
  setupSpeech(); updateVoiceUI();

  // Network
  $('networkScanBtn').addEventListener('click', runNetworkScan);
  $('refreshNetworkBtn').addEventListener('click', runNetworkScan);
  $('deviceFilter').addEventListener('input', () => { if (state.network) renderNetwork(state.network); });
  $('deviceRows').addEventListener('click', event => { const button = event.target.closest('[data-ports]'); if (!button) return; $('portTarget').value = button.dataset.ports; runPortScan(button.dataset.ports); });
  $('portScanBtn').addEventListener('click', () => runPortScan($('portTarget').value));
  $('routerPanelBtn').addEventListener('click', openRouterPanel);
  $('monitorNetworkBtn').addEventListener('click', toggleNetworkMonitoring);
  $('exportNetworkBtn').addEventListener('click', exportNetworkCsv);

  // Public web navigation
  $('webSearchForm').addEventListener('submit', event => { event.preventDefault(); runWebSearch($('webQuery').value); });
  $('readPageForm').addEventListener('submit', event => { event.preventDefault(); readPage($('pageUrl').value.trim()); });

  // Memory
  $('memoryForm').addEventListener('submit', async event => {
    event.preventDefault(); const content = $('memoryInput').value.trim(); if (!content) return showToast('Digite uma informação para salvar.');
    try { await api('/api/memories', { method: 'POST', body: JSON.stringify({ content }) }); $('memoryInput').value = ''; await loadMemories(); showToast('Memória salva no dispositivo.'); }
    catch (error) { showToast(error.message); }
  });
  $('clearMemoriesBtn').addEventListener('click', async () => {
    if (!window.confirm('Apagar permanentemente todas as memórias salvas?')) return;
    try { await api('/api/memories', { method: 'DELETE' }); state.memories = []; renderMemories(); showToast('Todas as memórias foram apagadas.'); }
    catch (error) { showToast(error.message); }
  });

  // Settings
  $('topSettings').addEventListener('click', () => navigate('settings'));
  $('toggleToken').addEventListener('click', () => { const field = $('tokenInput'); field.type = field.type === 'password' ? 'text' : 'password'; $('toggleToken').textContent = field.type === 'password' ? 'Mostrar' : 'Ocultar'; });
  $('saveTokenBtn').addEventListener('click', async () => {
    state.accessToken = $('tokenInput').value.trim();
    if (state.accessToken) sessionStorage.setItem('jarvisToken', state.accessToken); else sessionStorage.removeItem('jarvisToken');
    try { await api('/api/status'); $('tokenFeedback').textContent = 'Token validado. Núcleo conectado.'; showToast('Token validado.'); await checkStatus(); }
    catch (error) { $('tokenFeedback').textContent = error.message === 'TOKEN_REQUIRED' ? 'Token incorreto.' : error.message; showToast('Não foi possível validar o token.'); }
  });

  // Clock / boot
  function updateClock() { $('localClock').textContent = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }); }
  updateClock(); setInterval(updateClock, 30000);
  (async () => { const allowed = await ensureAccess().catch(error => { showToast(error.message); return false; }); if (allowed) { $('tokenInput').value = state.accessToken; await checkStatus(); await loadHistory(); } })();
})();
